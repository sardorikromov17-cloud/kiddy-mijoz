#!/usr/bin/env bash
cd "$(dirname "$0")"
node setup/ornatish.mjs
