# Kiddy Toys mijozlar ilovasi — ishga tushirish

Ishga tushirish taxminan 30–40 daqiqa oladi. Ko'p ishni o'rnatish yordamchisi o'zi qiladi, siz faqat savollarga javob berasiz.

## Oldindan tayyorlab qo'ying

1. Node.js — https://nodejs.org (LTS versiyasini o'rnating).
2. Supabase akkaunti va loyiha — https://supabase.com (bepul). Loyiha ochishda qo'ygan baza parolini eslab qoling.
3. iBox API kaliti (token) — XABIBIY SHOWROOM SOTUV (filial 10) uchun. iBox'dagi "API kalitlar" bo'limida yangi kalit yarating (nomi: Kiddy mijoz ilova) va uni darhol nusxalab oling — keyin u yashiriladi. Bo'limni topa olmasangiz, iBox qo'llab-quvvatlashidan "integratsiya API tokeni" so'rang.
4. Telegram bot — Telegram'da @BotFather → /newbot → nom va username bering, bergan tokenni saqlang.
5. Menejerlar guruhi — Telegram'da guruh oching, menejerlarni va botni qo'shing, guruhga /start yozing.
6. GitHub akkaunti — https://github.com (bepul).

## O'rnatish

1. `kiddy-mijoz-ilova.zip` ni oching (Extract).
2. Windows: ochilgan papkadagi `ORNATISH.bat` faylini ikki marta bosing.
   Mac/Linux: terminalda `./ornatish.sh`.
3. Yordamchi so'ragan narsalarni kiriting:
   - Supabase Project ID (loyiha manzilidagi `https://XXXX.supabase.co` dagi XXXX)
   - iBox token; filial (10), narx turi (Standart narx), ombor (XABIBIY SHOWROOM SKLAD) va valyuta (UZS) oldindan tanlangan turadi — Enter bosib o'tasiz
   - Telegram bot tokeni
   - ismingiz va telefoningiz (admin panelga shu raqam bilan kirasiz)
   - GitHub username

Yordamchi o'zi bajaradigan ishlar:
- bazani yaratadi va sozlamalarni yozadi;
- serverni yuklaydi;
- Telegram botni ulaydi;
- iBox'dan tovar va mijozlarni yuklaydi;
- har 5 daqiqalik avtomatik yangilanishni yoqadi.

Oxirida ilova va admin panel havolalarini chiqaradi.

Biror qadamda xato bo'lsa, yordamchi nima qilishni aytadi. Uni to'xtatib, qayta ishga tushirsangiz bo'ladi — javoblaringiz eslab qolinadi.

## Internetga qo'yish (GitHub)

Kompyuteringizda `git` va `gh` (GitHub CLI) bo'lsa, yordamchi buni ham o'zi qiladi. Bo'lmasa, qo'lda:

1. github.com → New repository → nomi `kiddy-mijoz` → Create.
2. "uploading an existing file" havolasini bosing va papkadagi hamma narsani sudrab tashlang. Yashirin `.github` papkasini ham qo'shing.
3. Settings → Pages → Source: GitHub Actions.
4. Android ilova uchun: Settings → Secrets and variables → Actions → `android-imzo-kaliti.zip` ichidagi `GITHUB_SECRETS.txt` dagi 4 ta qiymatni qo'shing.

5–10 daqiqadan keyin tayyor bo'ladi:
- Mijozlar ilovasi: `https://USERNAME.github.io/kiddy-mijoz/`
- Admin panel: `https://USERNAME.github.io/kiddy-mijoz/admin/`
- Android ilova: `https://github.com/USERNAME/kiddy-mijoz/releases/latest/download/kiddy-toys.apk`

## Birinchi tekshiruv

1. Botga /start yozing va "Raqamimni yuborish" ni bosing.
2. Admin panelni oching va telefoningiz bilan kiring (kod Telegram'ga keladi).
3. Karobka soni iBox'dagi "karobka" o'lchov birligidan avtomatik olinadi (tovarlarning ~95% ida bor). Tovarlar bo'limida "Karobka soni yo'q" filtrini ochib, qolganlarini to'ldiring.
4. O'zingiz yoki bitta ishonchli mijoz bilan sinov buyurtmasi bering va u iBox'da M-1 raqami bilan paydo bo'lganini tekshiring.
5. Hammasi joyida bo'lsa, ilova havolasini mijozlarga yuboring.

## Mijozlarga yuboriladigan matn (nusxalab olishingiz mumkin)

> Assalomu alaykum! Endi Kiddy Toys'ga buyurtmani telefondan berishingiz mumkin.
> Android: https://github.com/USERNAME/kiddy-mijoz/releases/latest/download/kiddy-toys.apk
> iPhone: https://USERNAME.github.io/kiddy-mijoz/ → Safari'da oching → "Ulashish" → "Bosh ekranga qo'shish".
> Birinchi kirishda Telegram botimizga raqamingizni yuborasiz — kirish kodi va buyurtma xabarlari shu yerga keladi.

## Keyin yoqiladigan narsalar

- Narxlar: iBox'dagi "Standart narx". Dollardagi tovarlar ilovada kurs bo'yicha so'mda ko'rinadi, yonida asl narx ($) ham turadi. Kurs admin panel → Sozlamalar'da turadi (boshida 1 USD = 12 300 so'm). iBox'da kurs o'zgarsa, shu yerda ham o'zgartiring — dollarli narxlar darhol qayta hisoblanadi. Buyurtma iBox'ga so'mda, "kutilmoqda" holatida tushadi — menejer tasdiqlaydi.
- Oldi-berdi (qarz): iBox hujjatlaridan (sotuv, to'lov, qaytarish) so'm va dollar alohida hisoblanadi, akt-sverka PDF ham ikki valyutada chiqadi. Sotuv "Yangi", "Yuborilgan", "Yakunlangan" holatida qarzga qo'shiladi; to'lov va qaytarish faqat yakunlanganda. Yoqishdan oldin: admin panel → Mijozlar'da har mijozga boshlang'ich qoldiq (so'm va dollar) va sanani kiriting, 2–3 mijozni iBox bilan solishtiring, keyin Sozlamalar'da yoqing.
- Katalog: ilovada tovarlar iBox'dagi guruh (O'g'il bolalar uchun, Qizlar uchun…), kategoriya va brend bo'yicha ajratiladi. Keraksiz bo'limni admin panel → Katalog bo'limlari'da yashirasiz.
- Qidiruv: lotin/kirill (машина = mashina), apostrofsiz (qogirchoq), xato yozilsa "Balki: …" variantlari, yozayotganda takliflar. Sinonimlarni admin panel → Qidiruv va sinonimlar'da qo'shasiz va u yerda "mijoz nima ko'radi"ni sinab ko'rasiz. Topilmagan so'zlar ro'yxati ham shu yerda.
- Admin panel alohida: ilova manzili + /admin/ (masalan https://USERNAME.github.io/kiddy-mijoz/admin/). Telefonda ochib "Bosh ekranga qo'shish" qilsangiz, alohida ilova bo'lib turadi.

Batafsil texnik ma'lumot va qo'lda o'rnatish — `README.md`.
