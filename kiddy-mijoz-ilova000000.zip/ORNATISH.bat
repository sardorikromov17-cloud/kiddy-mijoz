@echo off
chcp 65001 >nul
title Kiddy Toys - o'rnatish
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js topilmadi. https://nodejs.org saytidan LTS versiyani o'rnating, so'ng qayta ishga tushiring.
  start https://nodejs.org
  pause
  exit /b 1
)
node setup\ornatish.mjs
pause
