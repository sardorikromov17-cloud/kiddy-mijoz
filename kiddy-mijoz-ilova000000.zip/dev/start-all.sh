#!/usr/bin/env bash
# Mahalliy sinov muhitini to'liq ishga tushiradi (dasturchi uchun).
# Talab: Postgres 54322-portda, deno, python3.
set -e
cd "$(dirname "$0")/.."
export NO_COLOR=1
set -a; . dev/.env.test; set +a
pkill -f mock-ibox.ts 2>/dev/null || true
pkill -f mock-telegram.ts 2>/dev/null || true
pkill -f "dev/serve.ts" 2>/dev/null || true
pkill -f "http.server 8090" 2>/dev/null || true
sleep 1
(deno run -A dev/mock-ibox.ts > /tmp/mock.log 2>&1 &)
(deno run -A dev/mock-telegram.ts > /tmp/tgmock.log 2>&1 &)
(PORT=8001 deno run -A dev/serve.ts supabase/functions/ibox-sync/index.ts > /tmp/sync.log 2>&1 &)
(PORT=8002 deno run -A dev/serve.ts supabase/functions/api/index.ts > /tmp/api.log 2>&1 &)
(PORT=8003 deno run -A dev/serve.ts supabase/functions/tg-bot/index.ts > /tmp/bot.log 2>&1 &)
(PORT=8004 deno run -A dev/serve.ts supabase/functions/admin/index.ts > /tmp/admin.log 2>&1 &)
(python3 -m http.server 8090 -d web > /tmp/web.log 2>&1 &)
for i in $(seq 1 30); do
  curl -s -o /dev/null localhost:8002/functions/v1/api/config && curl -s -o /dev/null localhost:8004 && break
  sleep 1
done
echo "tayyor: ilova http://localhost:8090  admin http://localhost:8090/admin/"
