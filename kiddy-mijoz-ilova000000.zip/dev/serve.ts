// Edge Function'ni mahalliy kompyuterda kerakli portda ishga tushirish:
//   PORT=8001 deno run -A dev/serve.ts supabase/functions/api/index.ts
const port = Number(Deno.env.get("PORT") ?? 8000);
const original = Deno.serve.bind(Deno);
// deno-lint-ignore no-explicit-any
(Deno as any).serve = (a: any, b?: any) => {
  const handler = typeof a === "function" ? a : b;
  return original({ port, onListen: () => console.log(`listening :${port}`) }, handler);
};
await import(new URL(Deno.args[0], `file://${Deno.cwd()}/`).href);
