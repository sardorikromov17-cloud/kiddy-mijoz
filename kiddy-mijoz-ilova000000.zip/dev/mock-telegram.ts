// Sinov uchun soxta Telegram Bot API (port 8788). Yuborilgan xabarlarni GET /_sent orqali ko'rish mumkin.
const sent: any[] = [];
let nextId = 1000;
Deno.serve({ port: 8788 }, async (req) => {
  const url = new URL(req.url);
  if (url.pathname === "/_sent") return Response.json(sent);
  if (url.pathname === "/_reset") { sent.length = 0; return Response.json({ ok: true }); }
  const m = url.pathname.match(/^\/bot[^/]+\/(\w+)$/);
  if (!m) return Response.json({ ok: false, description: "not found" }, { status: 404 });
  const ct = req.headers.get("content-type") ?? "";
  let body: any = {};
  if (ct.includes("json")) body = await req.json();
  else if (ct.includes("form")) { const f = await req.formData(); for (const [k, v] of f) body[k] = typeof v === "string" ? v : `[file ${v.size} bytes]`; }
  if (m[1] === "getMe") return Response.json({ ok: true, result: { id: 1, is_bot: true, username: "KiddyToysTestBot" } });
  if (m[1] === "getUpdates") return Response.json({ ok: true, result: [{ update_id: 1, my_chat_member: { chat: { id: -100777, type: "supergroup", title: "Kiddy — mijozlar" } } }] });
  const id = nextId++;
  sent.push({ method: m[1], message_id: id, ...body });
  return Response.json({ ok: true, result: { message_id: id, chat: { id: body.chat_id } } });
});
