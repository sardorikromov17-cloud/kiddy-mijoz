# Mijoz ilovasining barcha ekranlarini suratga oladi (dasturchi uchun).
# python3 dev/audit.py [kenglik] [balandlik]  → /tmp/audit/*.png
import asyncio, re, sys, os, subprocess
from playwright.async_api import async_playwright

W = int(sys.argv[1]) if len(sys.argv) > 1 else 390
H = int(sys.argv[2]) if len(sys.argv) > 2 else 844
OUT = f"/tmp/audit/{W}"
os.makedirs(OUT, exist_ok=True)
CFG = 'window.KIDDY_CONFIG={API_URL:"http://localhost:8002/functions/v1/api"};'
APP = "http://localhost:8090/"

async def main():
    subprocess.run(["psql", "-h", "localhost", "-p", "54322", "-U", "postgres", "-qc", "delete from mijoz.login_codes"], check=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": W, "height": H}, device_scale_factor=2)
        pg = await ctx.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.route("**/config.js", lambda r: r.fulfill(body=CFG, content_type="application/javascript"))
        shot = lambda name, full=False: pg.screenshot(path=f"{OUT}/{name}.png", full_page=full)

        await pg.goto(APP); await pg.wait_for_selector("#tel"); await shot("01-login")
        await pg.fill("#tel", "90 123 45 67"); await pg.click("text=Kod olish"); await pg.wait_for_selector("#code")
        await shot("02-code")
        code = re.search(r"kod (\d{4})", await pg.inner_text(".note.warn")).group(1)
        await pg.fill("#code", code)
        await pg.wait_for_selector(".hero, .debt-card"); await pg.wait_for_timeout(800)
        await pg.evaluate("localStorage.setItem('kt_cart','{}')")
        await shot("03-home", True)
        for name, url, sel in [
            ("04-catalog", "#/katalog", ".prow2"),
            ("05-search-empty", "#/katalog?q=samolyotxyz", ".empty"),
            ("06-product-box", "#/tovar/101", "#nq"),
            ("07-product-nostock", "#/tovar/106", "#nq"),
            ("08-scanner", "#/skaner", "#manual"),
        ]:
            await pg.goto(APP + url); await pg.wait_for_selector(sel); await pg.wait_for_timeout(500); await shot(name, True)
        # savat
        await pg.evaluate("""localStorage.setItem('kt_cart', JSON.stringify({
          101:{id:101,name:'Radio boshqaruvli mashina',price:185000,qty:24,unit:'dona',box_qty:12,mode:'box'},
          102:{id:102,name:'Inertsion mashina, 4 xil',price:24000,qty:50,unit:'dona',box_qty:48,mode:'box'},
          106:{id:106,name:'Gapiradigan qo`g`irchoq',price:89000,qty:3,unit:'dona',mode:'unit'}}))""")
        await pg.goto(APP + "#/savat"); await pg.wait_for_selector(".prow2"); await pg.wait_for_timeout(500); await shot("09-cart", True)
        await pg.evaluate("localStorage.setItem('kt_cart','{}')")
        await pg.goto(APP + "#/savat"); await pg.wait_for_timeout(500); await shot("10-cart-empty")
        for name, url, sel in [
            ("11-cab-orders", "#/kabinet", ".card"),
            ("12-cab-ledger", "#/kabinet?tab=ledger", ".debt-card"),
            ("13-cab-complaints", "#/kabinet?tab=complaints", "a.btn"),
            ("14-complaint-form", "#/murojaat", "#reason"),
            ("15-chat", "#/chat", ".bubble, .empty"),
        ]:
            await pg.goto(APP + url); await pg.wait_for_selector(sel); await pg.wait_for_timeout(600); await shot(name, True)
        await pg.goto(APP + "#/kabinet"); await pg.wait_for_selector("a.card")
        await pg.click("a.card >> nth=0"); await pg.wait_for_selector(".prow"); await pg.wait_for_timeout(400); await shot("16-order", True)
        print("errors:", errs)
        await b.close()

asyncio.run(main())
