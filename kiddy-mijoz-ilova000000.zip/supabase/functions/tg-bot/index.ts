// Telegram bot webhook.
//  • Shaxsiy chat: mijoz/menejer raqamini (kontaktini) yuborib ulanadi; ulangan mijoz yozgan xabar menejerlarga boradi.
//  • Menejerlar guruhi: mijoz xabari yoki shikoyatiga "Reply" qilinsa — javob mijozga (ilova chatiga va Telegram'ga) boradi.
//  • Istalgan guruhda /id — guruh raqamini ko'rsatadi (MANAGER_CHAT_ID sozlash uchun).
import { db } from "../_shared/db.ts";
import { config } from "../_shared/config.ts";
import { phoneKey } from "../_shared/ibox.ts";
import { escapeHtml, sendMessage, tg } from "../_shared/telegram.ts";
import { fmt, notifyClient, notifyManagers } from "../_shared/notify.ts";
import { clientLedger } from "../_shared/ledger.ts";
import { getSettings } from "../_shared/settings.ts";

// ---------- Mijoz menyusi ----------
const BTN = {
  shop: "🛍 Buyurtma berish", orders: "📦 Buyurtmalarim", debt: "💰 Hisob-kitob",
  news: "📰 Yangiliklar", promo: "🔥 Aksiya va arzonlashganlar", manager: "👨‍💼 Menejer",
};
const app = (path = "") => { const b = config.appUrl(); return b ? b + (path ? "#" + path : "") : ""; };
function clientMenu() {
  const shop = app() ? { text: BTN.shop, web_app: { url: app("/") } } : { text: BTN.shop };
  return { reply_markup: { keyboard: [[shop], [{ text: BTN.orders }, { text: BTN.debt }], [{ text: BTN.news }, { text: BTN.promo }], [{ text: BTN.manager }]],
    resize_keyboard: true, is_persistent: true } };
}
const openBtn = (text: string, path: string) => app() ? { reply_markup: { inline_keyboard: [[{ text, web_app: { url: app(path) } }]] } } : {};
const STATUS_UZ: Record<string, string> = { new: "Qabul qilindi", sent: "Menejerga yuborildi", accepted: "Tasdiqlandi", shipped: "Yo'lda", delivered: "Yetkazildi", cancelled: "Bekor qilindi", failed: "Menejerga yuborildi" };

async function linkedClient(chatId: number) {
  const [c] = await db()`select id, name, phone from mijoz.clients where tg_chat_id = ${chatId} and active order by id limit 1`;
  return c ?? null;
}

async function cmdOrders(chatId: number, client: any) {
  const rows = await db()`select id, no, status, total::float8 total, created_at from mijoz.orders where client_id = ${client.id} order by created_at desc limit 5`;
  if (!rows.length) return sendMessage(chatId, "Hali buyurtma yo'q. Birinchi buyurtmani ilovadan bering 👇", openBtn("🛍 Katalogni ochish", "/katalog"));
  const lines = rows.map((o: any) => `№${o.no} · ${new Date(o.created_at).toLocaleDateString("ru-RU")} · ${fmt(o.total)} so'm\n   ${STATUS_UZ[o.status] ?? o.status}`);
  return sendMessage(chatId, `📦 <b>So'nggi buyurtmalar</b>\n\n${lines.join("\n")}`, openBtn("Barchasini ko'rish", "/kabinet"));
}

async function cmdDebt(chatId: number, client: any) {
  const s = await getSettings();
  if (!s.ledger_enabled) return sendMessage(chatId, "Hisob-kitob (oldi-berdi) bo'limi hozircha yoqilmagan. Savollar bo'lsa, menejerga yozing.");
  const l = await clientLedger(Number(client.id));
  if (!l) return;
  const parts = l.parts && Math.abs(l.parts.usd) >= 0.01 ? `\nSo'mda: ${fmt(l.parts.uzs)} · dollarda: $${l.parts.usd}` : "";
  const head = l.debt > 0 ? `Joriy qarzingiz: <b>${fmt(l.debt)} so'm</b>` : l.advance > 0 ? `Sizning haqingiz (avans): <b>${fmt(l.advance)} so'm</b>` : "Qarzdorlik yo'q ✅";
  const overdue = l.overdue > 0 ? `\n⏰ Muddati o'tgan: ${fmt(l.overdue)} so'm` : "";
  return sendMessage(chatId, `💰 <b>Hisob-kitob</b>\n\n${head}${parts}${overdue}\n\nAkt-sverkani ilovadan PDF qilib olishingiz mumkin.`, openBtn("Oldi-berdini ko'rish", "/kabinet?tab=ledger"));
}

async function cmdNews(chatId: number) {
  const rows = await db()`select id, title, published_at from mijoz.posts where published and published_at <= now() order by pinned desc, published_at desc limit 5`;
  if (!rows.length) return sendMessage(chatId, "Hozircha yangilik yo'q.");
  const kb = rows.map((p: any) => [app() ? { text: "📰 " + String(p.title).slice(0, 60), web_app: { url: app(`/yangilik/${p.id}`) } } : { text: p.title, callback_data: "x" }]);
  return sendMessage(chatId, "📰 <b>So'nggi yangiliklar</b>", { reply_markup: { inline_keyboard: kb } });
}

async function cmdPromo(chatId: number) {
  const rows = await db()`select name, price::float8 price, price_prev::float8 prev from mijoz.products
    where active and coalesce(stock,0) > 0 and price < price_prev and price_changed_at > now() - interval '14 days'
    order by (1 - price / price_prev) desc limit 8`;
  const [{ n }] = await db()`select count(*)::int n from mijoz.products where active and promo_label is not null`;
  const lines = rows.map((p: any) => `• ${escapeHtml(p.name)} — <b>${fmt(p.price)}</b> <s>${fmt(p.prev)}</s> (−${Math.round((1 - p.price / p.prev) * 100)}%)`);
  const text = `🔥 <b>Aksiya va arzonlashganlar</b>\n\n${lines.length ? "📉 Narxi tushganlar:\n" + lines.join("\n") : "Hozircha narxi tushgan tovar yo'q."}${n ? `\n\nAksiyadagi tovarlar: ${n} ta` : ""}`;
  return sendMessage(chatId, text, openBtn("Ilovada ko'rish", "/katalog?special=cheaper"));
}

/** Botda tovar qidirish: "?" bilan boshlangan xabar yoki /qidir */
async function cmdSearch(chatId: number, q: string) {
  q = q.trim().slice(0, 60);
  if (q.length < 2) return sendMessage(chatId, "Qidirish uchun so'z yozing, masalan: <code>?kukla</code>");
  const rows = await db()`select id, name, price::float8 price, stock::float8 stock from mijoz.products
    where active and (lower(sku) = ${q.toLowerCase()} or ${q} = any(barcodes) or search_norm like ${"%" + q.toLowerCase().replace(/['`ʻʼ‘’]/g, "") + "%"})
    order by (coalesce(stock,0) > 0) desc, length(name) limit 8`;
  if (!rows.length) return sendMessage(chatId, `«${escapeHtml(q)}» bo'yicha topilmadi. Ilovadagi qidiruv sinonim va xatolarni ham tushunadi 👇`, openBtn("🔍 Ilovada qidirish", `/katalog?q=${encodeURIComponent(q)}`));
  const kb = rows.map((p: any) => [app()
    ? { text: `${String(p.name).slice(0, 40)} · ${p.price ? fmt(p.price) : "—"}${(p.stock ?? 0) > 0 ? "" : " (yo'q)"}`, web_app: { url: app(`/tovar/${p.id}`) } }
    : { text: p.name, callback_data: "x" }]);
  return sendMessage(chatId, `🔍 «${escapeHtml(q)}» bo'yicha:`, { reply_markup: { inline_keyboard: kb } });
}

const contactKeyboard = {
  reply_markup: { keyboard: [[{ text: "📱 Raqamimni yuborish", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true },
};

async function downloadPhoto(fileId: string): Promise<string | null> {
  try {
    const f = await tg("getFile", { file_id: fileId });
    const res = await fetch(`${config.tgApiBase()}/file/bot${config.tgToken()}/${f.file_path}`);
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > 3 * 1024 * 1024) return null;
    const [row] = await db()`insert into mijoz.files (mime, bytes, size, owner) values ('image/jpeg', ${bytes}, ${bytes.length}, 'telegram') returning id`;
    return row.id;
  } catch (e) { console.error("photo", e); return null; }
}

async function handleContact(msg: any) {
  const chatId = msg.chat.id;
  if (msg.contact.user_id !== msg.from?.id) {
    await sendMessage(chatId, "Iltimos, pastdagi tugma orqali <b>o'zingizning</b> raqamingizni yuboring.", contactKeyboard);
    return;
  }
  const key = phoneKey(msg.contact.phone_number);
  const sql = db();
  const [admin] = key ? await sql`select name from mijoz.admins where phone_key = ${key} and active` : [];
  if (admin) await sql`update mijoz.admins set tg_chat_id = ${chatId} where phone_key = ${key}`;
  const clients = key ? await sql`select id, name from mijoz.clients where phone_key = ${key} and active and not in_black_list order by id` : [];
  if (clients.length) {
    await sql.begin(async (tx: any) => {
      await tx`update mijoz.clients set tg_chat_id = null where tg_chat_id = ${chatId}`;
      await tx`update mijoz.clients set tg_chat_id = ${chatId} where phone_key = ${key} and active`;
    });
  }
  const parts: string[] = [];
  if (clients.length) parts.push(`✅ Siz ${clients.map((c: any) => (/[«"]/.test(c.name) ? escapeHtml(c.name) : `«${escapeHtml(c.name)}»`)).join(", ")} sifatida ulandingiz.\n\n🛍 «Buyurtma berish» tugmasi ilovani shu yerda ochadi — kod kerak emas. Telefondagi ilovaga kirish kodi, buyurtma holati va menejer javoblari ham shu yerga keladi.\n\n🔍 Tovar qidirish: <code>?nomi</code> deb yozing.`);
  if (admin) parts.push(`🛠 Admin sifatida ulandingiz (${escapeHtml(admin.name)}). Admin panelga kirish kodi shu yerga keladi.`);
  if (!parts.length) {
    const mgr = config.managerPhone();
    parts.push("Bu raqam mijozlar bazasida topilmadi." + (mgr ? `\nMenejerga murojaat qiling: ${escapeHtml(mgr)}` : ""));
  }
  await sendMessage(chatId, parts.join("\n\n"), clients.length ? clientMenu() : { reply_markup: { remove_keyboard: true } });
  if (clients.length && app()) {
    // Chat pastidagi "Menyu" tugmasi ham ilovani ochadi
    await tg("setChatMenuButton", { chat_id: chatId, menu_button: { type: "web_app", text: "Buyurtma", web_app: { url: app("/") } } }).catch(() => {});
  }
}

/** Menejerlar guruhida mijoz xabariga berilgan javob */
async function handleManagerReply(msg: any) {
  const sql = db();
  const replyTo = msg.reply_to_message?.message_id;
  if (!replyTo) return;
  const [m] = await sql`select client_id from mijoz.messages where tg_message_id = ${replyTo} limit 1`;
  const [c] = m ? [] : await sql`select client_id, id from mijoz.complaints where tg_message_id = ${replyTo} limit 1`;
  const clientId = m?.client_id ?? c?.client_id;
  if (!clientId) return; // boshqa xabarga javob — e'tibor bermaymiz
  const text = (msg.text ?? msg.caption ?? "").trim().slice(0, 2000);
  const photo = msg.photo?.length ? await downloadPhoto(msg.photo[msg.photo.length - 1].file_id) : null;
  if (!text && !photo) return;
  const author = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(" ") || "Menejer";
  await sql`insert into mijoz.messages (client_id, direction, text, file_id, author) values (${clientId}, 'out', ${text || null}, ${photo}, ${author})`;
  const delivered = await notifyClient(Number(clientId),
    `💬 <b>Menejer javobi</b>${c ? ` (so'rov #${c.id})` : ""}:\n${escapeHtml(text || "[rasm]")}`,
    { text: "Chatni ochish", path: "/chat" });
  await tg("setMessageReaction", { chat_id: msg.chat.id, message_id: msg.message_id, reaction: [{ type: "emoji", emoji: delivered ? "👍" : "👀" }] }).catch(() => {});
}

/** Ulangan mijoz botga to'g'ridan-to'g'ri yozsa — menejerlarga yuboramiz */
async function handleClientText(msg: any) {
  const sql = db();
  const [client] = await sql`select id, name, phone from mijoz.clients where tg_chat_id = ${msg.chat.id} and active order by id limit 1`;
  const t = String(msg.text ?? "").trim();
  if (client) {
    if (t === BTN.orders || /^\/buyurtmalar/.test(t)) return void await cmdOrders(msg.chat.id, client);
    if (t === BTN.debt || /^\/(qarz|hisob)/.test(t)) return void await cmdDebt(msg.chat.id, client);
    if (t === BTN.news || /^\/yangiliklar/.test(t)) return void await cmdNews(msg.chat.id);
    if (t === BTN.promo || /^\/aksiya/.test(t)) return void await cmdPromo(msg.chat.id);
    if (t === BTN.shop || /^\/katalog/.test(t)) return void await sendMessage(msg.chat.id, "Katalogni oching 👇", openBtn("🛍 Katalog", "/katalog"));
    if (t === BTN.manager || /^\/menejer/.test(t)) {
      const mgr = config.managerPhone();
      return void await sendMessage(msg.chat.id, `👨‍💼 Savolingizni shu yerga yozing — menejer javob beradi.${mgr ? `\nTelefon: ${escapeHtml(mgr)}` : ""}`, clientMenu());
    }
    if (t.startsWith("?") || /^\/(qidir|q)\b/.test(t)) return void await cmdSearch(msg.chat.id, t.replace(/^\?|^\/(qidir|q)\b/, ""));
  }
  if (!client) {
    await sendMessage(msg.chat.id, "Assalomu alaykum! Bu <b>Kiddy Toys</b> buyurtma ilovasining boti.\n\nIlovaga kirish kodlari va buyurtma xabarlarini olish uchun raqamingizni yuboring 👇", contactKeyboard);
    return;
  }
  const text = (msg.text ?? msg.caption ?? "").trim().slice(0, 2000);
  const photo = msg.photo?.length ? await downloadPhoto(msg.photo[msg.photo.length - 1].file_id) : null;
  if (!text && !photo) return;
  const [row] = await sql`insert into mijoz.messages (client_id, direction, text, file_id) values (${client.id}, 'in', ${text || null}, ${photo}) returning id`;
  const tgId = await notifyManagers(
    `💬 <b>${escapeHtml(client.name)}</b> (${escapeHtml(client.phone ?? "")}) · Telegram orqali\n${text ? escapeHtml(text) : "[rasm]"}\n\n<i>Javob berish uchun shu xabarga "Reply" qiling.</i>`,
    photo ? [photo] : []);
  if (tgId) await sql`update mijoz.messages set tg_message_id = ${tgId} where id = ${row.id}`;
  await sendMessage(msg.chat.id, tgId ? "✉️ Xabaringiz menejerga yuborildi. Javob shu yerga va ilovadagi chatga keladi." : "Xabaringiz saqlandi, menejer tez orada javob beradi.");
}

Deno.serve(async (req) => {
  const secret = config.tgWebhookSecret();
  if (!secret || req.headers.get("x-telegram-bot-api-secret-token") !== secret) return new Response("forbidden", { status: 403 });
  const update = await req.json().catch(() => null);
  const msg = update?.message;
  if (!msg?.chat?.id) return new Response("ok");
  try {
    const isGroup = msg.chat.type === "group" || msg.chat.type === "supergroup";
    const text: string = msg.text ?? "";
    if (isGroup && /^\/id(@\w+)?$/.test(text)) {
      await sendMessage(msg.chat.id, `Bu guruh raqami: <code>${msg.chat.id}</code>\nUni Supabase Secrets'dagi MANAGER_CHAT_ID ga yozing.`);
    } else if (isGroup) {
      if (String(msg.chat.id) === config.managerChatId()) await handleManagerReply(msg);
    } else if (msg.chat.type === "private") {
      if (msg.contact) await handleContact(msg);
      else if (/^\/start/.test(text)) {
        const c = await linkedClient(msg.chat.id);
        if (c) await sendMessage(msg.chat.id, `Assalomu alaykum, <b>${escapeHtml(c.name)}</b>! 👋\n\nPastdagi menyudan foydalaning yoki «🛍 Buyurtma berish» ni bosing.`, clientMenu());
        else await sendMessage(msg.chat.id, "Assalomu alaykum! Bu <b>Kiddy Toys</b> buyurtma ilovasining boti.\n\nIlovaga kirish kodlari, buyurtma holati va menejer javoblarini olish uchun raqamingizni yuboring 👇", contactKeyboard);
      } else if (msg.web_app_data) {
        // Mini App'dan kelgan ma'lumot (hozircha faqat tasdiq)
        await sendMessage(msg.chat.id, "✅ Qabul qilindi.", clientMenu());
      } else await handleClientText(msg);
    }
  } catch (e) {
    console.error(e);
  }
  return new Response("ok");
});
