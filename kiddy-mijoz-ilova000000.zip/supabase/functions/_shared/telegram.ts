import { config } from "./config.ts";

export async function tg(method: string, payload: Record<string, unknown>): Promise<any> {
  const token = config.tgToken();
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN sozlanmagan");
  const res = await fetch(`${config.tgApiBase()}/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15_000),
  });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(`Telegram ${method}: ${data.description ?? res.status}`);
  return data.result;
}

export function sendMessage(chatId: number | string, text: string, extra: Record<string, unknown> = {}) {
  return tg("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", ...extra });
}

export const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/** Fayl (masalan PDF) yuborish */
export async function sendDocument(chatId: number | string, bytes: Uint8Array, filename: string, caption = "") {
  const token = config.tgToken();
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN sozlanmagan");
  const form = new FormData();
  form.append("chat_id", String(chatId));
  if (caption) { form.append("caption", caption); form.append("parse_mode", "HTML"); }
  form.append("document", new Blob([bytes as BlobPart], { type: "application/pdf" }), filename);
  const res = await fetch(`${config.tgApiBase()}/bot${token}/sendDocument`, { method: "POST", body: form, signal: AbortSignal.timeout(30_000) });
  const data = await res.json().catch(() => ({}));
  if (!data.ok) throw new Error(`Telegram sendDocument: ${data.description ?? res.status}`);
  return data.result;
}
