import { db } from "./db.ts";

export type Settings = {
  min_order_sum: number;
  ledger_enabled: boolean;
  block_over_limit: boolean;
  new_arrivals_notify: boolean;
  overdue_reminder: boolean;
  new_days: number;
  default_mode: "box" | "unit";
  usd_rate: number;
  usd_rate_auto: boolean;
  show_usd: boolean;
  catalog_view: "media" | "list";
  catalog_tabs: "folder" | "group" | "category" | "none";
};

const DEFAULTS: Settings = {
  min_order_sum: 0, ledger_enabled: false, block_over_limit: true,
  new_arrivals_notify: true, overdue_reminder: true, new_days: 14, default_mode: "box",
  usd_rate: 12300, usd_rate_auto: false, show_usd: true,
  catalog_view: "media", catalog_tabs: "folder",
};
const ENUMS: Record<string, string[]> = {
  default_mode: ["box", "unit"], catalog_view: ["media", "list"], catalog_tabs: ["folder", "group", "category", "none"],
};

export async function getSettings(): Promise<Settings> {
  const rows = await db()`select key, value from mijoz.settings`;
  const s: any = { ...DEFAULTS };
  for (const r of rows) if (r.key in DEFAULTS) s[r.key] = r.value;
  return s as Settings;
}

export async function setSettings(patch: Partial<Settings>) {
  const sql = db();
  for (const [k, v] of Object.entries(patch)) {
    if (!(k in DEFAULTS)) continue;
    if (k === "usd_rate" && !(Number(String(v).replace(/\s/g, "").replace(",", ".")) > 0)) continue;
    const def = (DEFAULTS as any)[k];
    const val = ENUMS[k] ? (ENUMS[k].includes(String(v)) ? String(v) : def)
      : typeof def === "number" ? Math.max(0, Number(String(v).replace(/\s/g, "").replace(",", ".")) || 0) : !!v;
    await sql`insert into mijoz.settings (key, value, updated_at) values (${k}, ${sql.json(val)}, now())
      on conflict (key) do update set value = excluded.value, updated_at = now()`;
  }
}
