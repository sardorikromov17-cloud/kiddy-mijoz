// Akt-sverka (solishtirma dalolatnoma) PDF.
// DejaVu shrifti o'zbekcha harflarni (oʻ, gʻ, «») to'g'ri chiqaradi.
import { PDFDocument, rgb, type PDFFont, type PDFPage } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";
import type { LedgerEntry } from "./ledger.ts";

const fmtCur = (n: number, cur: "UZS" | "USD" = "UZS") => {
  const a = Math.abs(n);
  const s = cur === "USD"
    ? a.toFixed(2).replace(/\.00$/, "").replace(/\B(?=(\d{3})+(?!\d))/g, " ")
    : Math.round(a).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return (n < 0 ? "−" : "") + (cur === "USD" ? "$" : "") + s;
};
const dmy = (iso: string | null) => (iso ? iso.slice(0, 10).split("-").reverse().join(".") : "");

let fontCache: { regular: Uint8Array; bold: Uint8Array } | null = null;
async function fonts() {
  if (!fontCache) {
    fontCache = {
      regular: await Deno.readFile(new URL("./fonts/DejaVuSans.ttf", import.meta.url)),
      bold: await Deno.readFile(new URL("./fonts/DejaVuSans-Bold.ttf", import.meta.url)),
    };
  }
  return fontCache;
}

export async function aktPdf(opts: {
  company: string;
  client: { name: string; code?: string | null; phone?: string | null };
  from: string | null; to: string;
  // Har valyuta uchun alohida jadval (iBox'dagidek so'm va dollar alohida)
  sections: { cur: "UZS" | "USD"; opening: number; closing: number; debit: number; credit: number; entries: LedgerEntry[] }[];
}): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.registerFontkit(fontkit);
  const f = await fonts();
  const R = await doc.embedFont(f.regular, { subset: true });
  const B = await doc.embedFont(f.bold, { subset: true });
  doc.setTitle(`Akt-sverka — ${opts.client.name}`);
  doc.setAuthor(opts.company);

  const W = 595.28, H = 841.89, M = 40;
  const ink = rgb(0.09, 0.13, 0.26), muted = rgb(0.36, 0.39, 0.5), line = rgb(0.85, 0.87, 0.92), soft = rgb(0.95, 0.96, 0.98);
  const cols = [
    { t: "Sana", w: 62, a: "l" }, { t: "Hujjat", w: 128, a: "l" }, { t: "Raqam", w: 70, a: "l" },
    { t: "Debet (+)", w: 82, a: "r" }, { t: "Kredit (−)", w: 82, a: "r" }, { t: "Qoldiq", w: 91, a: "r" },
  ] as const;

  let page: PDFPage = doc.addPage([W, H]);
  let y = H - M;
  const text = (s: string, x: number, yy: number, size = 9, font: PDFFont = R, color = ink) =>
    page.drawText(s, { x, y: yy, size, font, color });
  const rtext = (s: string, xRight: number, yy: number, size = 9, font: PDFFont = R, color = ink) =>
    text(s, xRight - font.widthOfTextAtSize(s, size), yy, size, font, color);
  const fit = (s: string, w: number, size: number, font: PDFFont) => {
    let out = s;
    while (out.length > 1 && font.widthOfTextAtSize(out, size) > w - 6) out = out.slice(0, -2) + "…";
    return out;
  };

  const wrap = (s: string, w: number, size: number, font: PDFFont) => {
    const out: string[] = []; let cur = "";
    for (const word of s.split(" ")) {
      const t = cur ? cur + " " + word : word;
      if (font.widthOfTextAtSize(t, size) > w && cur) { out.push(cur); cur = word; } else cur = t;
    }
    if (cur) out.push(cur);
    return out;
  };
  const header = () => {
    page.drawRectangle({ x: M, y: y - 18, width: W - 2 * M, height: 18, color: soft });
    let x = M + 4;
    for (const c of cols) {
      if (c.a === "r") rtext(c.t, x + c.w - 8, y - 12, 8, B, muted); else text(c.t, x, y - 12, 8, B, muted);
      x += c.w;
    }
    y -= 32;
  };
  const row = (cells: string[], bold = false, fill?: ReturnType<typeof rgb>) => {
    if (y < M + 90) { page = doc.addPage([W, H]); y = H - M; header(); }
    if (fill) page.drawRectangle({ x: M, y: y - 5, width: W - 2 * M, height: 17, color: fill });
    let x = M + 4;
    cells.forEach((v, i) => {
      const c = cols[i], font = bold ? B : R, s = fit(v, c.w, 8.5, font);
      if (c.a === "r") rtext(s, x + c.w - 8, y, 8.5, font); else text(s, x, y, 8.5, font);
      x += c.w;
    });
    page.drawLine({ start: { x: M, y: y - 6 }, end: { x: W - M, y: y - 6 }, thickness: 0.5, color: line });
    y -= 17;
  };

  // Sarlavha
  text("SOLISHTIRMA DALOLATNOMA (AKT-SVERKA)", M, y, 14, B); y -= 20;
  text(`${opts.from ? dmy(opts.from) : "boshidan"} — ${dmy(opts.to)} davri uchun`, M, y, 10, R, muted); y -= 24;
  text("Sotuvchi:", M, y, 9, R, muted); text(opts.company, M + 70, y, 10, B); y -= 15;
  text("Xaridor:", M, y, 9, R, muted); text(opts.client.name, M + 70, y, 10, B);
  const extra = [opts.client.code && `kod: ${opts.client.code}`, opts.client.phone].filter(Boolean).join(" · ");
  if (extra) text(extra, M + 70 + B.widthOfTextAtSize(opts.client.name, 10) + 10, y, 9, R, muted);
  y -= 24;

  const results: string[] = [];
  for (const sec of opts.sections) {
    const f = (n: number) => fmtCur(n, sec.cur);
    const name = sec.cur === "USD" ? "dollar (USD)" : "so'm (UZS)";
    if (y < M + 160) { page = doc.addPage([W, H]); y = H - M; }
    text(`Valyuta: ${name}`, M, y, 10, B); y -= 14;
    header();
    row([opts.from ? dmy(opts.from) : "", "Davr boshiga qoldiq", "", "", "", f(sec.opening)], true, soft);
    for (const e of sec.entries) {
      row([dmy(e.date), e.title, e.number ?? "", e.amount > 0 ? f(e.amount) : "", e.amount < 0 ? f(-e.amount) : "", f(e.balance)]);
    }
    row(["", "Davr aylanmasi", "", f(sec.debit), f(sec.credit), ""], true);
    row([dmy(opts.to), "Davr oxiriga qoldiq", "", "", "", f(sec.closing)], true, soft);
    y -= 18;
    const unit = sec.cur === "USD" ? "" : " so'm";
    const where = opts.sections.length > 1 ? (sec.cur === "USD" ? "dollarda " : "so'mda ") : "";
    results.push(sec.closing > 0.009 ? `${where}qarzi ${f(sec.closing)}${unit}` : sec.closing < -0.009 ? `${where}haqi (avans) ${f(-sec.closing)}${unit}` : `${where || ""}qarzdorlik yo'q`);
  }

  const result = `${dmy(opts.to)} holatiga xaridorning ${results.join("; ")}`;
  for (const ln of wrap(result, W - 2 * M, 11, B)) { text(ln, M, y, 11, B); y -= 15; }
  y -= 1;
  text("Qoldiq musbat bo'lsa — xaridor qarzi, manfiy bo'lsa — xaridorning haqi.", M, y, 8, R, muted); y -= 40;

  text("Sotuvchi: ______________________", M, y, 10); text("Xaridor: ______________________", W / 2 + 10, y, 10); y -= 14;
  text(opts.company, M + 58, y, 8, R, muted); text(opts.client.name.slice(0, 40), W / 2 + 62, y, 8, R, muted);

  const pages = doc.getPages();
  pages.forEach((p, i) => {
    const s = `Kiddy Toys mijozlar ilovasi · ${new Date(Date.now() + 5 * 3600_000).toISOString().slice(0, 16).replace("T", " ")} · ${i + 1}/${pages.length}`;
    p.drawText(s, { x: M, y: 22, size: 7, font: R, color: muted });
  });
  return await doc.save();
}
