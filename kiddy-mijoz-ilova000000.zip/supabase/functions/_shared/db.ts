import postgres from "npm:postgres@3.4.5";
import { config } from "./config.ts";

// Bitta funksiya nusxasi uchun bitta ulanish havzasi
let _sql: ReturnType<typeof postgres> | null = null;

export function db() {
  if (!_sql) {
    _sql = postgres(config.dbUrl(), {
      max: 3,
      idle_timeout: 20,
      prepare: false, // Supabase pooler (transaction mode) bilan mos
      // bigint (iBox id'lari) JSON'ga oddiy son bo'lib chiqsin
      types: { bigint: { to: 20, from: [20], serialize: (x: unknown) => String(x), parse: (x: string) => Number(x) } },
      transform: { undefined: null },
    });
  }
  return _sql;
}

export async function getState(key: string): Promise<string | null> {
  const rows = await db()`select value from mijoz.sync_state where key = ${key}`;
  return rows.length ? (rows[0].value as string | null) : null;
}

export async function setState(key: string, value: string | null) {
  await db()`
    insert into mijoz.sync_state (key, value, updated_at) values (${key}, ${value}, now())
    on conflict (key) do update set value = excluded.value, updated_at = now()`;
}
