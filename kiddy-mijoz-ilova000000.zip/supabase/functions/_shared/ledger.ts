// Oldi-berdi hisob-kitobi: boshlang'ich qoldiq + iBox hujjatlari (jo'natma, to'lov, qaytarish).
// Musbat balans = mijoz qarzi, manfiy = mijozning haqi (avans).
import { db } from "./db.ts";

export const KIND_UZ: Record<string, string> = { shipment: "Tovar olindi", payment: "To'lov", return: "Qaytarish" };

export type Cur = "UZS" | "USD";
export type LedgerEntry = {
  id: string; date: string; kind: string; title: string; number: string | null;
  currency: Cur; amount: number; balance: number; // amount va balance — hujjat valyutasida
};
type Totals = { opening: number; debit: number; credit: number; closing: number };

const iso = (d: Date | string) => (typeof d === "string" ? d.slice(0, 10) : d.toISOString().slice(0, 10));
const r2 = (n: number) => Math.round(n * 100) / 100;

async function usdRate(): Promise<number> {
  const [r] = await db()`select mijoz.usd_rate()::float8 as r`;
  return Number(r?.r) || 12300;
}

/**
 * Mijozning oldi-berdisi. So'm va dollar alohida yuritiladi (iBox'dagidek);
 * "balance/debt/advance/overdue" — umumiy, so'mga o'girilgan ko'rinishi (dollar qismi kurs bo'yicha).
 */
export async function clientLedger(clientId: number, from?: string | null, to?: string | null) {
  const sql = db();
  const [c] = await sql`
    select id, name, phone, code, credit_days, credit_limit::float8 as credit_limit,
           opening_balance::float8 as opening_balance, opening_balance_usd::float8 as opening_usd, opening_balance_date,
           ibox_debt_uzs::float8 as ibox_uzs, ibox_debt_usd::float8 as ibox_usd, ibox_debt_base::float8 as ibox_base, ibox_debt_at
    from mijoz.clients where id = ${clientId}`;
  if (!c) return null;
  const rate = await usdRate();
  const startDate = c.opening_balance_date ? iso(c.opening_balance_date) : null;
  const rows = await sql`
    select id, doc_date, kind, currency, amount::float8 as amount, doc_number from mijoz.ledger
    where client_id = ${clientId} and amount <> 0 and (${startDate}::date is null or doc_date >= ${startDate}::date)
    order by doc_date, kind = 'shipment' desc, id`;

  // Butun tarix bo'yicha qoldiq — har valyutada alohida
  const open: Record<Cur, number> = { UZS: Number(c.opening_balance) || 0, USD: Number(c.opening_usd) || 0 };
  const bal: Record<Cur, number> = { ...open };
  const all: LedgerEntry[] = rows.map((r: any) => {
    const cur: Cur = r.currency === "USD" ? "USD" : "UZS";
    bal[cur] = r2(bal[cur] + r.amount);
    return { id: r.id, date: iso(r.doc_date), kind: r.kind, title: KIND_UZ[r.kind] ?? r.kind, number: r.doc_number,
      currency: cur, amount: r.amount, balance: bal[cur] };
  });

  // iBox "Qarzdorlar"dagi aniq qoldiq bo'lsa — asosiy raqam shu (hujjatlar tarixi baribir ko'rsatiladi)
  const exact = c.ibox_debt_at != null && c.ibox_base != null;
  const parts = exact ? { uzs: Number(c.ibox_uzs) || 0, usd: Number(c.ibox_usd) || 0 } : { uzs: bal.UZS, usd: bal.USD };
  const balance = Math.round(parts.uzs + parts.usd * rate);

  // Tanlangan davr — har valyuta bo'yicha
  const f = from ?? null, t = to ?? null;
  const entries = all.filter((e) => (!f || e.date >= f) && (!t || e.date <= t));
  const cur: Record<Cur, Totals> = {} as any;
  for (const k of ["UZS", "USD"] as Cur[]) {
    const mine = all.filter((e) => e.currency === k);
    const before = f ? mine.filter((e) => e.date < f) : [];
    const opening = before.length ? before[before.length - 1].balance : open[k];
    const inP = entries.filter((e) => e.currency === k);
    cur[k] = {
      opening, closing: inP.length ? inP[inP.length - 1].balance : opening,
      debit: r2(inP.filter((e) => e.amount > 0).reduce((s, e) => s + e.amount, 0)),
      credit: r2(inP.filter((e) => e.amount < 0).reduce((s, e) => s - e.amount, 0)),
    };
  }
  const toBase = (k: keyof Totals) => Math.round(cur.UZS[k] + cur.USD[k] * rate);
  const usdUsed = open.USD !== 0 || all.some((e) => e.currency === "USD") || Math.abs(parts.usd) > 0.009;

  // Muddati o'tgan qarz (so'mga o'girib): to'lovlar eng eski jo'natmalarni yopadi (FIFO)
  let overdue = 0, overdueSince: string | null = null;
  if (c.credit_days != null && balance > 0) {
    const lots: { date: string; left: number }[] = [];
    let credits = 0;
    const ob = open.UZS + open.USD * rate;
    if (ob > 0) lots.push({ date: startDate ?? "1970-01-01", left: ob }); else credits += -ob;
    for (const e of all) {
      const v = e.currency === "USD" ? e.amount * rate : e.amount;
      if (v > 0) lots.push({ date: e.date, left: v }); else credits += -v;
    }
    for (const l of lots) { const take = Math.min(l.left, credits); l.left -= take; credits -= take; }
    const limit = new Date(Date.now() - Number(c.credit_days) * 86400_000).toISOString().slice(0, 10);
    for (const l of lots) if (l.left > 0.009 && l.date < limit) { overdue += l.left; overdueSince ??= l.date; }
    overdue = Math.min(overdue, balance); // aniq qoldiq hujjatlardagidan kam bo'lsa
  }

  return {
    client: { id: c.id, name: c.name, phone: c.phone, code: c.code, credit_days: c.credit_days, credit_limit: c.credit_limit },
    rate, usd_used: usdUsed,
    balance, debt: Math.max(balance, 0), advance: Math.max(-balance, 0),
    parts: { uzs: r2(parts.uzs), usd: r2(parts.usd) },
    period: { from: f, to: t, opening: toBase("opening"), closing: toBase("closing"), debit: toBase("debit"), credit: toBase("credit"), cur },
    overdue: Math.round(overdue), overdue_since: overdue > 0 ? overdueSince : null,
    entries,
  };
}

export async function clientBalance(clientId: number): Promise<number> {
  const [r] = await db()`select balance::float8 as balance from mijoz.client_balance where client_id = ${clientId}`;
  return r ? Number(r.balance) : 0;
}
