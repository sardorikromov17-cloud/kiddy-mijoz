// Qisqa muddatli imzolangan havolalar (masalan, akt-sverka PDF'ini brauzerda ochish uchun)
import { config } from "./config.ts";

const enc = new TextEncoder();
async function key() {
  return await crypto.subtle.importKey("raw", enc.encode("link:" + config.syncSecret()), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}
const b64u = (b: ArrayBuffer) => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

export async function signPayload(payload: Record<string, unknown>, ttlSec = 300): Promise<string> {
  const body = b64u(enc.encode(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSec })).buffer as ArrayBuffer);
  const sig = b64u(await crypto.subtle.sign("HMAC", await key(), enc.encode(body)));
  return `${body}.${sig}`;
}

export async function verifyPayload(token: string): Promise<Record<string, any> | null> {
  const [body, sig] = String(token ?? "").split(".");
  if (!body || !sig) return null;
  const expected = b64u(await crypto.subtle.sign("HMAC", await key(), enc.encode(body)));
  if (expected.length !== sig.length) return null;
  let diff = 0;
  for (let i = 0; i < sig.length; i++) diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i);
  if (diff) return null;
  try {
    const p = JSON.parse(atob(body.replace(/-/g, "+").replace(/_/g, "/")));
    return p.exp > Date.now() / 1000 ? p : null;
  } catch { return null; }
}
