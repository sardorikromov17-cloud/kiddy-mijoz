// Barcha sozlamalar Supabase "Secrets" (muhit o'zgaruvchilari) orqali beriladi.
// Maxfiy qiymatlar (token, parol) kodga hech qachon yozilmaydi.

function env(name: string, fallback?: string): string {
  const v = Deno.env.get(name);
  if (v === undefined || v === "") {
    if (fallback !== undefined) return fallback;
    throw new Error(`Sozlama yo'q: ${name}`);
  }
  return v;
}

function envInt(name: string, fallback?: number): number | undefined {
  const v = Deno.env.get(name);
  if (!v) return fallback;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`${name} raqam bo'lishi kerak`);
  return n;
}

export const config = {
  // Supabase o'zi beradi
  dbUrl: () => env("SUPABASE_DB_URL"),

  // iBox
  iboxBaseUrl: () => env("IBOX_BASE_URL").replace(/\/+$/, ""), // Kiddy Toys: https://kiddytoys.ibox.io
  iboxToken: () => env("IBOX_TOKEN"),
  iboxFilialId: () => env("IBOX_FILIAL_ID"),
  iboxPriceTypeId: () => envInt("IBOX_PRICE_TYPE_ID"),       // ulgurji narx turi
  iboxWarehouseId: () => envInt("IBOX_WAREHOUSE_ID"),        // buyurtma qaysi ombordan
  iboxCurrencyId: () => envInt("IBOX_CURRENCY_ID", 1)!,      // so'm valyutasi id
  iboxReserve: () => (Deno.env.get("IBOX_RESERVE") ?? "0") === "1", // buyurtmada tovarni band qilish

  // Sinxronlash funksiyasini faqat cron chaqira olishi uchun
  syncSecret: () => env("SYNC_SECRET"),

  // Telegram bot (kirish kodlari va xabarlar)
  tgToken: () => Deno.env.get("TELEGRAM_BOT_TOKEN") ?? "",
  tgApiBase: () => (Deno.env.get("TELEGRAM_API_BASE") ?? "https://api.telegram.org").replace(/\/+$/, ""), // faqat sinov uchun o'zgartiriladi
  tgBotUsername: () => Deno.env.get("TELEGRAM_BOT_USERNAME") ?? "",
  tgWebhookSecret: () => Deno.env.get("TELEGRAM_WEBHOOK_SECRET") ?? "",

  // Ruxsat etilgan sayt manzillari (CORS), vergul bilan: https://ikromov.github.io
  allowedOrigins: () => (Deno.env.get("ALLOWED_ORIGINS") ?? "*").split(",").map((s) => s.trim()).filter(Boolean),

  // Faqat sinov uchun: kirish kodini javobda qaytaradi. Haqiqiy ishda HECH QACHON yoqmang.
  devMode: () => Deno.env.get("DEV_MODE") === "1",

  managerPhone: () => Deno.env.get("MANAGER_PHONE") ?? "",
  // Menejerlar Telegram guruhi: mijoz xabarlari va shikoyatlari shu yerga keladi, javob (reply) mijozga qaytadi
  managerChatId: () => Deno.env.get("MANAGER_CHAT_ID") ?? "",
  // Ilova manzili (xabarlardagi tugmalar uchun), masalan https://ikromov.github.io/kiddy-mijoz/
  appUrl: () => { const u = Deno.env.get("APP_URL") ?? ""; return u ? u.replace(/\/?$/, "/") : ""; },
};
