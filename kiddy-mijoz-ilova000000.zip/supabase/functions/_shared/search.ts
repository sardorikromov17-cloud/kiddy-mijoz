// Aqlli qidiruv: lotin/kirill, apostroflar, sinonimlar, xatoga chidamlilik.
// norm() — SQL'dagi mijoz.norm() bilan AYNAN bir xil bo'lishi shart.
import { db } from "./db.ts";

const MULTI: [string, string][] = [
  ["щ", "sh"], ["ш", "sh"], ["ч", "ch"], ["ю", "yu"], ["я", "ya"], ["ё", "yo"], ["ж", "j"], ["ц", "s"],
  ["х", "x"], ["ҳ", "h"], ["ъ", ""], ["ь", ""],
];
const FROM = "абвгдезийклмнопрстуфыэғқўі";
const TO = "abvgdeziyklmnoprstufiegqoi";

export function norm(t: unknown): string {
  let s = String(t ?? "").toLowerCase();
  for (const [a, b] of MULTI) s = s.split(a).join(b);
  s = [...s].map((ch) => { const i = FROM.indexOf(ch); return i >= 0 ? TO[i] : ch; }).join("");
  s = s.replace(/['`ʻʼ‘’"«»]/g, "");
  return s.replace(/[^a-z0-9]+/g, " ").trim();
}

let synCache: { at: number; map: Map<string, string[]> } = { at: 0, map: new Map() };
async function synonymMap(): Promise<Map<string, string[]>> {
  if (Date.now() - synCache.at < 60_000) return synCache.map;
  const rows = await db()`select words_norm from mijoz.synonyms`;
  const map = new Map<string, string[]>();
  for (const r of rows) {
    const ws: string[] = (r.words_norm ?? []).filter(Boolean);
    for (const w of ws) map.set(w, [...new Set([...(map.get(w) ?? []), ...ws])]);
  }
  synCache = { at: Date.now(), map };
  return map;
}
export function dropSynonymCache() { synCache.at = 0; }

const reEsc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export type Plan = {
  q: string;                 // normallashgan so'rov
  groups: string[][];        // har bir so'z uchun muqobillari (o'zi + sinonimlari)
  phrase: string[];          // ko'p so'zli sinonimlar ("temir yol") butun ibora sifatida
};

/** So'rovni so'zlarga bo'lib, har biriga sinonimlarni qo'shadi */
export async function plan(raw: string): Promise<Plan> {
  const q = norm(raw).slice(0, 100);
  const words = q.split(" ").filter(Boolean).slice(0, 6);
  const syn = await synonymMap();
  const groups: string[][] = [];
  const used = new Set<number>();
  const phrase: string[] = [];
  // Ikki so'zli sinonim iboralar ("radio boshqaruv", "temir yol")
  for (let i = 0; i + 1 < words.length; i++) {
    const two = `${words[i]} ${words[i + 1]}`;
    if (syn.has(two)) { groups.push(syn.get(two)!); used.add(i); used.add(i + 1); phrase.push(two); }
  }
  words.forEach((w, i) => {
    if (used.has(i)) return;
    const alts = new Set<string>([w]);
    for (const x of syn.get(w) ?? []) alts.add(x);
    // So'zning boshi sinonim bo'lsa ham (mashinalar → mashina)
    if (w.length >= 5) for (const [k, v] of syn) if (k.length >= 4 && w.startsWith(k)) v.forEach((x) => alts.add(x));
    groups.push([...alts]);
  });
  return { q, groups, phrase };
}

/**
 * SQL shart: har bir so'z guruhidan kamida bittasi tovar matnidagi biror so'zning BOSHIDA uchrasin.
 * "mash" → "mashina"; "top" "toplam"ni topmaydi, chunki sinonimlarda yo'q.
 */
export function matchCond(sql: any, p: Plan) {
  if (!p.groups.length) return sql`true`;
  return p.groups
    .map((alts) => {
      const re = "(^| )(" + alts.map(reEsc).join("|") + ")";
      return sql`p.search_norm ~ ${re}`;
    })
    .reduce((a: any, b: any) => sql`${a} and ${b}`);
}

/** Xatoli yozilgan so'zlar uchun yaqin variantlar ("mashna" → "mashina") */
export async function didYouMean(p: Plan, limit = 4): Promise<string[]> {
  const sql = db();
  const out: string[] = [];
  for (const alts of p.groups) {
    const w = alts[0];
    if (!w || w.length < 3 || /^\d+$/.test(w)) continue;
    const rows = await sql`
      select word from mijoz.search_vocab
      where word <> ${w} and extensions.similarity(word, ${w}) > 0.3
      order by extensions.similarity(word, ${w}) desc, n desc limit 3`;
    for (const r of rows) out.push(r.word);
  }
  // Bir so'zli so'rov bo'lsa — so'zning o'zi; ko'p so'zli bo'lsa — birinchi xato so'zni almashtirib butun ibora
  if (p.groups.length > 1 && out.length) {
    const words = p.groups.map((g) => g[0]);
    const fixed: string[] = [];
    for (const cand of out) {
      let best = -1, score = 0;
      words.forEach((w, i) => { const s = trigramSim(w, cand); if (s > score) { score = s; best = i; } });
      if (best >= 0) { const c = [...words]; c[best] = cand; fixed.push(c.join(" ")); }
    }
    return [...new Set(fixed)].slice(0, limit);
  }
  return [...new Set(out)].slice(0, limit);
}

/** Taxminiy o'xshash tovarlar (so'z topilmaganda) */
export function fuzzyCond(sql: any, p: Plan) {
  const words = p.groups.map((g) => g[0]).filter((w) => w.length >= 3);
  if (!words.length) return sql`false`;
  return words
    .map((w) => sql`extensions.word_similarity(${w}, p.search_norm) >= 0.45`)
    .reduce((a: any, b: any) => sql`${a} and ${b}`);
}
export function fuzzyOrder(sql: any, p: Plan) {
  const q = p.groups.map((g) => g[0]).join(" ");
  return sql`extensions.word_similarity(${q}, p.search_norm) desc`;
}

function trigrams(s: string) {
  const t = `  ${s} `; const set = new Set<string>();
  for (let i = 0; i < t.length - 2; i++) set.add(t.slice(i, i + 3));
  return set;
}
function trigramSim(a: string, b: string) {
  const A = trigrams(a), B = trigrams(b);
  let inter = 0; for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter || 1);
}
