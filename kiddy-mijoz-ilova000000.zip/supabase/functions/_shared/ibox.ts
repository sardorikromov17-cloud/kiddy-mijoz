// iBox Integration API (SMPro) bilan ishlash.
// Hujjat: https://docsify.smpro.uz/docs/
import { config } from "./config.ts";

export class IboxError extends Error {
  constructor(public status: number, message: string, public body?: unknown) {
    super(message);
  }
}

type Query = Record<string, string | number | boolean | (string | number)[] | undefined | null>;

function buildQuery(q: Query = {}): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(q)) {
    if (v === undefined || v === null || v === "") continue;
    if (Array.isArray(v)) v.forEach((x, i) => p.append(`${k}[${i}]`, String(x)));
    else if (typeof v === "boolean") p.append(k, v ? "1" : "0");
    else p.append(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function iboxRequest(
  method: "GET" | "POST",
  path: string,
  opts: { query?: Query; body?: unknown } = {},
): Promise<any> {
  // "/outlet/client/debtors" kabi "/" bilan boshlangan yo'l — iBox'ning oddiy API'si (integratsiya emas)
  const prefix = path.startsWith("/") ? "/api" : "/api/integration/";
  const url = `${config.iboxBaseUrl()}${prefix}${path.startsWith("/") ? path : path.replace(/^\/+/, "")}${buildQuery(opts.query)}`;
  let lastErr: unknown;
  for (let attempt = 0; attempt < 4; attempt++) {
    if (attempt) await sleep(800 * 2 ** (attempt - 1));
    let res: Response;
    try {
      res = await fetch(url, {
        method,
        headers: {
          "Authorization": `Bearer ${config.iboxToken()}`,
          "Filial-Id": config.iboxFilialId(),
          "Accept": "application/json",
          "Content-Type": "application/json",
        },
        body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
        signal: AbortSignal.timeout(30_000),
      });
    } catch (e) {
      lastErr = e; // tarmoq xatosi — qayta urinamiz
      continue;
    }
    const text = await res.text();
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* JSON emas */ }
    if (res.ok) return json;
    const msg = (json && (json.message || json.messages)) || text.slice(0, 300) || res.statusText;
    // 419 = "Too Many Attempts", 429, 5xx — biroz kutib qayta urinamiz. POST'ni qayta yubormaymiz (ikki marta buyurtma bo'lmasin).
    if ((res.status === 419 || res.status === 429 || res.status >= 500) && method === "GET") {
      lastErr = new IboxError(res.status, `iBox ${res.status}: ${msg}`, json);
      continue;
    }
    throw new IboxError(res.status, `iBox ${res.status}: ${msg}`, json);
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}

/** Keyset sahifalash: product/list va outlet/client/list */
/** Keyset sahifalash. Har sahifada rows.next — keyingi after_id (davom ettirish uchun saqlanadi), oxirgisida null */
export async function* iboxKeyset(path: string, query: Query, startAfter?: number | null): AsyncGenerator<any[] & { next: number | null }> {
  let after: number | undefined = startAfter ?? undefined;
  for (let guard = 0; guard < 10_000; guard++) {
    const res = await iboxRequest("GET", path, { query: { limit: 500, ...query, after_id: after } });
    const rows: any[] = Array.isArray(res?.data) ? res.data : [];
    const meta = res?.meta ?? {};
    const done = !meta.has_more || meta.next_after_id == null || Number(meta.next_after_id) === after;
    const next = done ? null : Number(meta.next_after_id);
    if (rows.length) yield Object.assign(rows, { next });
    if (done) return;
    after = next!;
  }
}

// Bitta so'rov uchun vaqt chegarasi (Supabase bepul tarifida funksiya ~150 soniya ishlaydi).
// Katta birinchi yuklash bo'laklarga bo'linadi va keyingi chaqiruvda davom etadi.
let deadline = Infinity;
export function setDeadline(ms: number) { deadline = Date.now() + ms; }
export function timeUp() { return Date.now() > deadline; }

/** Oddiy sahifalash (page/per_page): stock/selection va hujjat ro'yxatlari */
export async function* iboxPaged(path: string, query: Query, perPage = 100): AsyncGenerator<{ rows: any[]; raw: any }> {
  for (let page = 1; page <= 2000; page++) {
    const res = await iboxRequest("GET", path, { query: { ...query, per_page: perPage, page } });
    const rows: any[] = Array.isArray(res?.data) ? res.data
      : Array.isArray(res?.data?.data) ? res.data.data
      : Array.isArray(res?.data?.items) ? res.data.items : [];
    yield { rows, raw: res };
    // meta: {meta:{last_page}} yoki Laravel paginator ({last_page, data:[…]}) yoki {data:{last_page, data:[…]}}
    const meta = res?.meta ?? res?.data?.meta ?? (Array.isArray(res?.data) ? res : res?.data) ?? {};
    const last = Number(meta.last_page ?? meta.lastPage ?? NaN);
    if (Number.isFinite(last) ? page >= last : rows.length < perPage) return;
  }
}

// ---------- Javoblarni bizning jadvalga moslash ----------

const num = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(String(v).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export function phoneKey(phone: unknown): string | null {
  const d = String(phone ?? "").replace(/\D/g, "");
  return d.length >= 9 ? d.slice(-9) : null;
}

export function mapProduct(p: any) {
  return {
    id: Number(p.id),
    name: String(p.name ?? "").trim() || `#${p.id}`,
    sku: p.sku ?? null,
    comment: p.comment ?? null,
    type: p.type ?? null,
    active: p.active !== false,
    unit: p.storage_unit?.short_name ?? p.storage_unit?.name ?? null,
    category_id: p.product_category?.id ?? null,
    category_name: p.product_category?.name ?? null,
    group_id: p.product_group?.id ?? null,
    group_name: p.product_group?.name ?? null,
    brand_name: p.product_brand?.name ?? null,
    photo_url: p.photo_url ?? null,
    photos: Array.isArray(p.photos) ? p.photos : [],
    barcodes: extractBarcodes(p),
    box_qty_ibox: extractBoxQty(p),
    box_qty_suggest: suggestBoxQtyFromName(p.name),
    ibox_updated_at: p.updated_at ?? null,
  };
}

export function mapClient(c: any) {
  return {
    id: Number(c.id),
    name: String(c.name ?? "").trim() || `#${c.id}`,
    code: c.code ?? null,
    phone: c.main_phone ?? null,
    phone_key: phoneKey(c.main_phone),
    active: c.active !== false,
    in_black_list: !!c.in_black_list,
    category_name: c.outlet_category?.name ?? null,
    counter_party: c.counter_party ?? null,
    parent_id: c.parent?.id ?? null,
    credit_days: c.counter_party?.credit_days ?? null,
    ibox_updated_at: c.updated_at ?? null,
  };
}

/**
 * stock/selection javobining shakli hujjatda ko'rsatilmagan ("data": []).
 * Shuning uchun keng tarqalgan maydon nomlarini tekshiramiz. Birinchi qator
 * sync_state.stock_sample ga yoziladi — kerak bo'lsa moslashtirish oson.
 */
export function mapStock(s: any): { id: number; price: number | null; stock: number | null; box: number | null; currency: string | null; min_qty: number | null } | null {
  const id = num(s.product_id ?? s.product?.id ?? s.id);
  if (id === null) return null;
  const price = num(
    s.price ?? s.sale_price ?? s.selling_price ?? s.price_value ?? s.prices?.[0]?.price ?? s.price_type?.price ?? s.product_price?.price,
  );
  const stock = num(
    s.available ?? s.available_quantity ?? s.quantity ?? s.stock ?? s.balance ?? s.remainder ?? s.qty,
  );
  const currency = String(s.currency_code ?? s.currency?.code ?? (s.currency_id == 2 ? "USD" : s.currency_id == 1 ? "UZS" : "")).toUpperCase() || null;
  const minQty = num(s.minimum_sales_quantity);
  return { id, price, stock, box: extractBoxQty(s) ?? extractBoxQty(s.product), currency, min_qty: minQty && minQty > 0 ? minQty : null };
}

// ---------- Karobkadagi dona soni ----------
// iBox hujjatidagi product/list misolida bu maydon yo'q, lekin ko'p tizimlarda turli nom bilan keladi.
// Shuning uchun keng tarqalgan nomlarni va "o'lchov birliklari / qadoqlar" ro'yxatini tekshiramiz.
const BOX_KEYS = ["box_quantity", "quantity_in_box", "qty_in_box", "in_box", "box_qty", "box_count", "pack_quantity",
  "package_quantity", "units_in_package", "units_per_box", "pcs_in_box", "count_in_box", "block_quantity", "package_count",
  "packaging_quantity", "quantity_per_package", "box_size"];
const BOX_NAME = /kar[o0]b|^krb|короб|box|упак|pack|blok|блок|yashik|ящик|qop|мешок|паков/i;

/** Shtrix-kodlar: "4000,4001" satri, ["…"] yoki [{barcode:"…"}]; karobka shtrix-kodi (pack_quantities[].bar_code) ham qo'shiladi */
export function extractBarcodes(p: any): string[] {
  const out = new Set<string>();
  const add = (v: unknown) => { const s = String(v ?? "").trim(); if (s && s !== "null" && s.length < 64) out.add(s); };
  const b = p?.barcodes;
  if (typeof b === "string") b.split(/[,;\s]+/).forEach(add);
  else if (Array.isArray(b)) b.forEach((x: any) => add(typeof x === "object" && x ? (x.barcode ?? x.bar_code ?? x.code) : x));
  for (const q of Array.isArray(p?.pack_quantities) ? p.pack_quantities : []) add(q?.bar_code);
  return [...out];
}

function posInt(v: unknown): number | null {
  const n = typeof v === "number" ? v : Number(String(v ?? "").replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) && n > 1 && n < 100000 && Math.abs(n - Math.round(n)) < 1e-6 ? Math.round(n) : null;
}

export function extractBoxQty(p: any): number | null {
  if (!p || typeof p !== "object") return null;
  for (const k of BOX_KEYS) { const v = posInt(p[k]); if (v) return v; }
  // O'lchov birliklari / qadoqlar ro'yxati: [{name: "Karobka", coefficient: 24}, …]
  for (const listKey of ["pack_quantities", "units", "product_units", "packages", "packagings", "measures", "measure_units", "unit_coefficients", "storage_units", "conversions"]) {
    const list = p[listKey];
    if (!Array.isArray(list)) continue;
    for (const u of list) {
      const name = String(u?.name ?? u?.unit?.name ?? u?.short_name ?? u?.unit?.short_name ?? "");
      if (!BOX_NAME.test(name)) continue;
      const v = posInt(u?.coefficient ?? u?.ratio ?? u?.rate ?? u?.quantity ?? u?.count ?? u?.factor ?? u?.multiplier ?? u?.value);
      if (v) return v;
    }
  }
  // product ro'yxatidagi "pack": "4.0000 krb"
  if (typeof p.pack === "string") {
    const m = p.pack.match(/^\s*([\d.,]+)\s*(\S*)/);
    if (m && (!m[2] || BOX_NAME.test(m[2]) || /^krb|^kor/i.test(m[2]))) { const v = posInt(m[1]); if (v) return v; }
  }
  for (const objKey of ["package", "packaging", "box"]) {
    const o = p[objKey];
    if (o && typeof o === "object") {
      const v = posInt(o.quantity ?? o.coefficient ?? o.count ?? o.ratio);
      if (v) return v;
    }
  }
  return null;
}

/** Tovar nomidan taklif: "24 dona/karobka", "кор. 24", "1/24", "(24 шт)" — admin tasdiqlaguncha ishlatilmaydi */
export function suggestBoxQtyFromName(name: string): number | null {
  const s = String(name ?? "");
  const patterns = [
    /(\d{1,4})\s*(?:dona|ta|шт|pcs|pc)\.?\s*(?:\/|в|x|×|\s)\s*(?:kar[o0]b|короб|box|упак|блок|blok)/i,
    /(?:kar[o0]bka|karob|короб(?:ка)?|кор|box|упак(?:овка)?|блок|blok)\.?\s*[:=\-–]?\s*(\d{1,4})\s*(?:dona|ta|шт|pcs)?/i,
    /\b1\s*[\/x×]\s*(\d{1,4})\b/,
    /\((\d{1,4})\s*(?:dona|ta|шт|pcs)\.?\)/i,
  ];
  for (const re of patterns) {
    const m = s.match(re);
    const v = m ? posInt(m[1]) : null;
    if (v) return v;
  }
  return null;
}
