import { db } from "./db.ts";
import { config } from "./config.ts";
import { IboxError, iboxRequest } from "./ibox.ts";

/** Toshkent vaqti bo'yicha bugungi sana: YYYY-MM-DD */
export function todayTashkent(): string {
  return new Date(Date.now() + 5 * 3600_000).toISOString().slice(0, 10);
}

/**
 * Buyurtmani iBox'ga "kutilmoqda" (42) holatida yuboradi.
 * Bir buyurtma ikki marta ketmasligi uchun avval qatorni qulflaymiz.
 */
export async function sendOrderToIbox(orderId: string): Promise<{ ok: boolean; error?: string }> {
  const sql = db();
  return await sql.begin(async (tx: any) => {
    const [order] = await tx`
      select o.*, c.name as client_name from mijoz.orders o
      join mijoz.clients c on c.id = o.client_id
      where o.id = ${orderId} for update of o skip locked`;
    if (!order) return { ok: false, error: "locked_or_missing" };
    if (order.status !== "new" && order.status !== "failed") return { ok: true };

    const items = await tx`select product_id, qty, price::float8 as price, total::float8 as total, price_orig::float8 as price_orig, currency
      from mijoz.order_items where order_id = ${orderId} order by id`;
    // Buyurtma valyutasi: 1 = so'm (asosiy). Boshqasi tanlansa (dollar) — narxlar dollarda yuboriladi.
    const currencyId = config.iboxCurrencyId();
    const inUsd = currencyId !== 1;
    const rate = Number(order.usd_rate) || 12300;
    const r2 = (n: number) => Math.round(n * 100) / 100;
    const priceOf = (i: any) => inUsd
      ? r2(i.currency === "USD" && i.price_orig ? Number(i.price_orig) : Number(i.price) / rate)
      : Number(i.price);
    const warehouseId = config.iboxWarehouseId();
    const body = {
      number: `M-${order.no}`, // iBox'da ilova buyurtmalarini ajratib ko'rish uchun
      date: todayTashkent(),
      currency_id: currencyId,
      outlet_id: Number(order.client_id),
      status: "42", // 42 = pending (kutilmoqda), menejer iBox'da tasdiqlaydi
      is_reserved: config.iboxReserve(),
      comment: [`Mobil ilova №${order.no}`, order.comment].filter(Boolean).join(" · ").slice(0, 1000),
      order_details: items.map((i: any) => ({
        product_id: Number(i.product_id),
        quantity: Number(i.qty),
        price: priceOf(i),
        total: r2(priceOf(i) * Number(i.qty)),
        ...(warehouseId ? { warehouse_id: warehouseId } : {}),
      })),
    };

    try {
      const res = await iboxRequest("POST", "document/order", { body });
      const d = res?.data ?? {};
      await tx`
        update mijoz.orders set status = 'sent', ibox_id = ${d.id ?? null}, ibox_number = ${d.number != null ? String(d.number) : null},
          ibox_error = null, send_attempts = send_attempts + 1, sent_at = now()
        where id = ${orderId}`;
      return { ok: true };
    } catch (e) {
      const msg = e instanceof IboxError
        ? `${e.message}${e.body && (e.body as any).errors ? " " + JSON.stringify((e.body as any).errors).slice(0, 500) : ""}`
        : String((e as Error)?.message ?? e);
      await tx`
        update mijoz.orders set status = 'failed', ibox_error = ${msg.slice(0, 1000)}, send_attempts = send_attempts + 1
        where id = ${orderId}`;
      return { ok: false, error: msg };
    }
  });
}
