// Rasmlarni bazada saqlash (bannerlar, shikoyat rasmlari).
// Telefon rasmni yuborishdan oldin kichraytiradi (~200 KB), shuning uchun alohida Storage kerak emas.
import { db } from "./db.ts";
import { HttpError } from "./http.ts";

const MAX_BYTES = 3 * 1024 * 1024;
const ALLOWED = ["image/jpeg", "image/png", "image/webp"];

/** data:image/jpeg;base64,.... yoki toza base64 qabul qiladi */
export async function saveImage(dataUrl: string, owner: string): Promise<string> {
  const m = String(dataUrl ?? "").match(/^data:([\w/+.-]+);base64,(.+)$/s);
  if (!m) throw new HttpError(400, "bad_image", "Rasm formati noto'g'ri");
  const mime = m[1].toLowerCase();
  if (!ALLOWED.includes(mime)) throw new HttpError(400, "bad_image", "Faqat JPG, PNG yoki WEBP rasm");
  let bytes: Uint8Array;
  try { bytes = Uint8Array.from(atob(m[2]), (c) => c.charCodeAt(0)); }
  catch { throw new HttpError(400, "bad_image", "Rasm buzilgan"); }
  if (bytes.length > MAX_BYTES) throw new HttpError(413, "too_big", "Rasm juda katta (3 MB dan oshmasin)");
  // Fayl haqiqatan rasm ekanini birinchi baytlardan tekshiramiz
  const sig = [...bytes.slice(0, 12)];
  const isJpeg = sig[0] === 0xff && sig[1] === 0xd8;
  const isPng = sig[0] === 0x89 && sig[1] === 0x50 && sig[2] === 0x4e && sig[3] === 0x47;
  const isWebp = String.fromCharCode(...sig.slice(0, 4)) === "RIFF" && String.fromCharCode(...sig.slice(8, 12)) === "WEBP";
  if (!(isJpeg || isPng || isWebp)) throw new HttpError(400, "bad_image", "Bu rasm fayli emas");
  const [row] = await db()`
    insert into mijoz.files (mime, bytes, size, owner) values (${mime}, ${bytes}, ${bytes.length}, ${owner}) returning id`;
  return row.id as string;
}

export async function fileResponse(id: string, cors: Record<string, string>): Promise<Response> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response("not found", { status: 404, headers: cors });
  const [f] = await db()`select mime, bytes from mijoz.files where id = ${id}`;
  if (!f) return new Response("not found", { status: 404, headers: cors });
  return new Response(f.bytes, {
    headers: { ...cors, "Content-Type": f.mime, "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" },
  });
}
