-- iBox "Papkalar" (Mahsulotlar → papka belgisi): BASSEN, MASTER TOYS, KIDDY TOYS …
-- Integratsiya API tovar ro'yxatida papka bermaydi, shuning uchun har papka bo'yicha
-- stock/selection?product_folder_id=… dan tovarlar ro'yxati olinadi (sinxronlashda).
create table if not exists mijoz.folders (
  id        bigint primary key,
  parent_id bigint,
  name      text not null,
  sort      int not null default 0,
  synced_at timestamptz not null default now()
);
alter table mijoz.folders enable row level security;

alter table mijoz.products add column if not exists folder_id bigint;
create index if not exists products_folder_idx on mijoz.products (folder_id) where active;
