-- Kiddy Toys iBox'ining haqiqiy ma'lumotlariga moslash:
--  * tovar narxlari "Standart narx" turida ko'pincha dollarda (USD), ba'zilari so'mda;
--  * mijoz qarzi iBox'da so'm va dollarda alohida yuritiladi.
-- Ilova ichida hamma narx so'mda ko'rsatiladi (dollarli narx kurs bo'yicha o'giriladi),
-- asl narx va valyuta alohida saqlanadi.

alter table mijoz.products add column if not exists price_orig numeric(18,4);   -- iBox'dagi asl narx
alter table mijoz.products add column if not exists currency   text;            -- 'USD' | 'UZS'
alter table mijoz.products add column if not exists min_qty    numeric(18,3);   -- iBox: minimal sotuv miqdori

alter table mijoz.order_items add column if not exists price_orig numeric(18,4);
alter table mijoz.order_items add column if not exists currency   text;
alter table mijoz.orders      add column if not exists usd_rate   numeric(18,4);

-- iBox "Qarzdorlar" ro'yxatidagi aniq qoldiq (+ qarz, − haq), sinxronlashda yangilanadi
alter table mijoz.clients add column if not exists ibox_debt_uzs  numeric(18,2);
alter table mijoz.clients add column if not exists ibox_debt_usd  numeric(18,4);
alter table mijoz.clients add column if not exists ibox_debt_base numeric(18,2);  -- hammasi so'mga o'girilgan
alter table mijoz.clients add column if not exists ibox_debt_at   timestamptz;

insert into mijoz.settings (key, value) values
  ('usd_rate', '12300'),        -- 1 USD necha so'm (iBox'dagi kurs bilan avtomatik yangilanadi)
  ('usd_rate_auto', 'false'),   -- kursni iBox'dan olish (integratsiya API hozircha kurs bermaydi — admin panelda qo'lda)
  ('show_usd', 'true')          -- dollarli tovarlarda asl narxni ($) ham ko'rsatish
on conflict (key) do nothing;

-- Balans: iBox'dagi aniq qoldiq bo'lsa — o'sha, bo'lmasa hujjatlardan hisoblangani
create or replace view mijoz.client_balance as
  select c.id as client_id,
         coalesce(c.ibox_debt_base,
           c.opening_balance + coalesce(sum(l.amount) filter (
             where c.opening_balance_date is null or l.doc_date >= c.opening_balance_date), 0)) as balance
  from mijoz.clients c
  left join mijoz.ledger l on l.client_id = c.id
  group by c.id, c.opening_balance, c.ibox_debt_base;

-- ---------- Oldi-berdi valyutalar bo'yicha ----------
-- iBox hujjatlari (jo'natma, to'lov, qaytarish) o'z valyutasida keladi: amount shu valyutada saqlanadi.
alter table mijoz.ledger  add column if not exists currency text not null default 'UZS';
alter table mijoz.clients add column if not exists opening_balance_usd numeric(18,4) not null default 0;

create or replace function mijoz.usd_rate() returns numeric language sql stable as $$
  select coalesce((select (value #>> '{}')::numeric from mijoz.settings where key = 'usd_rate'), 12300)
$$;

-- Balans so'mda (dollar qismi kurs bo'yicha): limit va eslatmalar uchun
create or replace view mijoz.client_balance as
  select c.id as client_id,
         coalesce(c.ibox_debt_base,
           c.opening_balance + c.opening_balance_usd * mijoz.usd_rate()
           + coalesce(sum(case when l.currency = 'USD' then l.amount * mijoz.usd_rate() else l.amount end) filter (
               where c.opening_balance_date is null or l.doc_date >= c.opening_balance_date), 0)) as balance
  from mijoz.clients c
  left join mijoz.ledger l on l.client_id = c.id
  group by c.id, c.opening_balance, c.opening_balance_usd, c.ibox_debt_base;
