-- 3-bosqich: ulgurji savdo — karobka / dona

-- box_qty           — ilovada ishlatiladigan karobkadagi dona soni (avtomatik hisoblanadi)
-- box_qty_manual    — admin qo'lda kiritgani (eng ustun)
-- box_qty_ibox      — iBox ma'lumotidan topilgani
-- box_qty_suggest   — tovar nomidan topilgan taklif (admin tasdiqlamaguncha ishlatilmaydi)
alter table mijoz.products add column if not exists box_qty_manual  int;
alter table mijoz.products add column if not exists box_qty_ibox    int;
alter table mijoz.products add column if not exists box_qty_suggest int;
-- Avval qo'lda kiritilganlarni saqlab qolamiz
update mijoz.products set box_qty_manual = box_qty where box_qty is not null and box_qty_manual is null;

-- Buyurtma qatori: mijoz qaysi birlikda tanlagani (iBox'ga baribir dona yuboriladi)
alter table mijoz.order_items add column if not exists box_qty int;
alter table mijoz.order_items add column if not exists mode    text not null default 'unit' check (mode in ('unit','box'));

-- Ilova ochilganda qaysi birlik tanlangan turadi: 'box' (ulgurji) yoki 'unit'
insert into mijoz.settings (key, value) values ('default_mode', '"box"') on conflict (key) do nothing;
