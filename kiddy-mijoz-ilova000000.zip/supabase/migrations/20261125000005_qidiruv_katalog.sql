-- Aqlli qidiruv: lotin/kirill, apostrof farqlari, sinonimlar va xatoga chidamlilik (pg_trgm).
-- Katalog: guruh / kategoriya / brend bo'yicha ajratish.

create schema if not exists extensions;
create extension if not exists pg_trgm with schema extensions;

-- Matnni bir xil ko'rinishga keltirish: kichik harf, kirill → lotin, o' / g' / ʻ belgilarini olib tashlash.
-- DIQQAT: xuddi shu qoidalar supabase/functions/_shared/search.ts dagi norm() da ham bor — birga o'zgartiring.
create or replace function mijoz.norm(t text) returns text
language sql immutable parallel safe as $$
  select regexp_replace(regexp_replace(
    translate(
      replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(
        lower(coalesce(t, '')),
        'щ', 'sh'), 'ш', 'sh'), 'ч', 'ch'), 'ю', 'yu'), 'я', 'ya'), 'ё', 'yo'), 'ж', 'j'), 'ц', 's'),
        'х', 'x'), 'ҳ', 'h'), 'ъ', ''), 'ь', ''),
      'абвгдезийклмнопрстуфыэғқўі',
      'abvgdeziyklmnoprstufiegqoi'),
    '[''`ʻʼ‘’"«»]', '', 'g'),
    '[^a-z0-9]+', ' ', 'g')
$$;

alter table mijoz.products add column if not exists search_norm text
  generated always as (mijoz.norm(
    coalesce(name, '') || ' ' || coalesce(sku, '') || ' ' || coalesce(category_name, '') || ' ' ||
    coalesce(group_name, '') || ' ' || coalesce(brand_name, ''))) stored;
create index if not exists products_search_trgm on mijoz.products using gin (search_norm extensions.gin_trgm_ops);
create index if not exists products_group_idx on mijoz.products (group_id) where active;
create index if not exists products_brand_idx on mijoz.products (brand_name) where active;

-- Sinonimlar: bir qatordagi so'zlar bir-biriga teng hisoblanadi. Admin panelda tahrirlanadi.
create table if not exists mijoz.synonyms (
  id         bigserial primary key,
  words      text[] not null,            -- asl ko'rinishda (admin yozgandek)
  words_norm text[] not null,            -- mijoz.norm() dan o'tgan
  updated_at timestamptz not null default now()
);
create index if not exists synonyms_words_idx on mijoz.synonyms using gin (words_norm);
alter table mijoz.synonyms enable row level security;

-- Boshlang'ich lug'at (o'yinchoq do'koni uchun). Keyin admin panelda to'ldiriladi.
insert into mijoz.synonyms (words, words_norm)
select w, array(select distinct mijoz.norm(x) from unnest(w) x where mijoz.norm(x) <> '')
from (values
  (array['mashina','moshina','avto','avtomobil','машина','машинка','car']),
  (array['qo''g''irchoq','kukla','кукла','lol','barbi','barbie','qogirchoq']),
  (array['ayiq','ayiqcha','мишка','медведь','teddy']),
  (array['yumshoq','мягкий','мягкая','plush']),
  (array['konstruktor','конструктор','lego','лего','bloklar']),
  (array['koptok','мяч','myach','ball']),
  (array['velosiped','velik','велосипед','bike']),
  (array['samokat','самокат','scooter']),
  (array['kolyaska','коляска','arava']),
  (array['qurol','pistolet','avtomat','пистолет','автомат','gun']),
  (array['robot','робот','transformer','трансформер']),
  (array['vertolyot','вертолет','вертолёт','helicopter']),
  (array['samolyot','самолет','самолёт','samolet','plane']),
  (array['poyezd','poezd','поезд','temir yo''l','железная дорога']),
  (array['pultli','пульт','радиоуправляемый','radio']),
  (array['oshxona','кухня','kuxnya','idish','посуда']),
  (array['shifokor','doktor','доктор','vrach','врач']),
  (array['pazl','puzzle','пазл','boshqotirma']),
  (array['bo''yoq','kraska','краска','rang','plastilin','пластилин']),
  (array['chaqaloq','baby','малыш','погремушка','shiqildoq']),
  (array['qum','песок','pesochnitsa','песочница']),
  (array['suv','basseyn','бассейн','надувной','damlama']),
  (array['tryumo','trumo','трюмо','oyna','зеркало']),
  (array['stol','стол','stul','стул','mebel','мебель']),
  (array['elektromobil','elektro mashina','электромобиль','minadigan'])
) as v(w)
where not exists (select 1 from mijoz.synonyms);

-- Qidiruv so'zlari lug'ati ("Balki siz … ni qidirdingiz?" uchun). Sinxronlashda yangilanadi.
create table if not exists mijoz.search_vocab (
  word text primary key,
  n    int not null
);
create index if not exists search_vocab_trgm on mijoz.search_vocab using gin (word extensions.gin_trgm_ops);
alter table mijoz.search_vocab enable row level security;

create or replace function mijoz.refresh_vocab() returns int language plpgsql as $$
declare cnt int;
begin
  delete from mijoz.search_vocab;
  insert into mijoz.search_vocab (word, n)
    select w, count(*)::int from (
      select regexp_split_to_table(mijoz.norm(coalesce(name,'') || ' ' || coalesce(category_name,'') || ' ' ||
                                              coalesce(group_name,'') || ' ' || coalesce(brand_name,'')), '\s+') w
      from mijoz.products where active
    ) t
    where length(w) >= 3 and w !~ '^[0-9]+$'
    group by w;
  insert into mijoz.search_vocab (word, n)
    select distinct x, 1 from mijoz.synonyms, unnest(words_norm) x where length(x) >= 3
    on conflict (word) do nothing;
  get diagnostics cnt = row_count;
  return (select count(*) from mijoz.search_vocab);
end $$;

select mijoz.refresh_vocab();

-- Katalog bo'limlari: guruhlar va brendlar
create or replace view mijoz.product_groups as
  select group_id as id, group_name as name, count(*)::int as product_count
  from mijoz.products where active and group_id is not null
  group by group_id, group_name;

create or replace view mijoz.brands as
  select brand_name as name, count(*)::int as product_count
  from mijoz.products where active and brand_name is not null and brand_name <> ''
  group by brand_name;

-- Admin ilovada ko'rsatmaydigan bo'limlar (guruh / kategoriya / brend)
create table if not exists mijoz.hidden_sections (
  kind text not null check (kind in ('group','category','brand')),
  key  text not null,
  primary key (kind, key)
);
alter table mijoz.hidden_sections enable row level security;

create or replace function mijoz.is_hidden(g bigint, c bigint, b text) returns boolean
language sql stable as $$
  select exists (select 1 from mijoz.hidden_sections h
    where (h.kind = 'group' and h.key = g::text) or (h.kind = 'category' and h.key = c::text) or (h.kind = 'brand' and h.key = b))
$$;

create or replace view mijoz.product_groups as
  select group_id as id, group_name as name, count(*)::int as product_count
  from mijoz.products where active and group_id is not null and not mijoz.is_hidden(group_id, category_id, brand_name)
  group by group_id, group_name;

create or replace view mijoz.brands as
  select brand_name as name, count(*)::int as product_count
  from mijoz.products where active and brand_name is not null and brand_name <> '' and not mijoz.is_hidden(group_id, category_id, brand_name)
  group by brand_name;
