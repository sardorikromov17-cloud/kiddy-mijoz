-- Mijozlar uchun yangi imkoniyatlar:
--  * Yangiliklar lentasi (admin e'lon qiladi: yangi kolleksiya, aksiya, ish tartibi…)
--  * Arzonlashgan tovarlar (narx pasayganini sinxronlash o'zi aniqlaydi)

create table if not exists mijoz.posts (
  id           bigserial primary key,
  title        text not null,
  body         text,
  image_id     text,                      -- mijoz.files dagi rasm
  product_ids  bigint[] not null default '{}',
  pinned       boolean not null default false,
  published    boolean not null default true,
  published_at timestamptz not null default now(),
  views        int not null default 0,
  created_at   timestamptz not null default now()
);
create index if not exists posts_pub_idx on mijoz.posts (published, pinned desc, published_at desc);
alter table mijoz.posts enable row level security;

-- Narx o'zgarishi: oldingi narx va qachon o'zgargani
alter table mijoz.products add column if not exists price_prev numeric(18,2);
alter table mijoz.products add column if not exists price_changed_at timestamptz;
create index if not exists products_price_drop_idx on mijoz.products (price_changed_at desc)
  where active and price_prev is not null;

create or replace function mijoz.track_price() returns trigger language plpgsql as $$
begin
  -- Asl narx (iBox'dagi, o'z valyutasida) 0.5% dan ko'p o'zgarsa — narx o'zgardi.
  -- Faqat dollar kursi o'zgargani narx o'zgarishi hisoblanmaydi.
  -- Valyuta yoki narx turi almashganda (masalan dollar → so'm prays) bu narx o'zgarishi emas
  if coalesce(old.currency, '') <> coalesce(new.currency, '') then
    return new;
  end if;
  if old.price is not null and new.price is not null and (
       (old.price_orig is not null and new.price_orig is not null
          and abs(new.price_orig - old.price_orig) >= old.price_orig * 0.005)
    or ((old.price_orig is null or new.price_orig is null)
          and abs(new.price - old.price) >= greatest(1, old.price * 0.005))) then
    new.price_prev := old.price;
    new.price_changed_at := now();
  end if;
  return new;
end $$;

drop trigger if exists products_track_price on mijoz.products;
create trigger products_track_price before update of price, price_orig on mijoz.products
  for each row execute function mijoz.track_price();
