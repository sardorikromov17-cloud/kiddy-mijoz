-- Kiddy Toys — mijozlar buyurtma ilovasi: 1-bosqich (katalog, kirish, buyurtma)
-- Barcha jadvallar faqat Edge Function'lar orqali ishlatiladi (service role).
-- Brauzerdan (anon) to'g'ridan-to'g'ri kirish yopiq: RLS yoqilgan, siyosat yo'q.

create schema if not exists mijoz;

-- iBox'dan keladigan mijozlar (outlet/client/list)
create table if not exists mijoz.clients (
  id              bigint primary key,            -- iBox outlet id
  name            text not null,
  code            text,
  phone           text,                          -- iBox'dagi main_phone, qanday bo'lsa shunday
  phone_key       text,                          -- oxirgi 9 raqam: 901234567
  active          boolean not null default true,
  in_black_list   boolean not null default false,
  category_name   text,
  counter_party   jsonb,
  parent_id       bigint,
  credit_days     int,
  address         text,                          -- iBox ro'yxatda bermaydi, keyin qo'lda / iBox'dan
  tg_chat_id      bigint,                        -- Telegram botga ulangan chat
  ibox_updated_at timestamptz,
  synced_at       timestamptz not null default now()
);
create index if not exists clients_phone_key_idx on mijoz.clients (phone_key);
create index if not exists clients_tg_chat_idx on mijoz.clients (tg_chat_id) where tg_chat_id is not null;

-- iBox'dan keladigan tovarlar (product/list + stock/selection)
create table if not exists mijoz.products (
  id              bigint primary key,            -- iBox product id
  name            text not null,
  name_lc         text generated always as (lower(name)) stored,
  sku             text,
  comment         text,
  type            int,
  active          boolean not null default true,
  unit            text,
  category_id     bigint,
  category_name   text,
  group_id        bigint,
  group_name      text,
  brand_name      text,
  photo_url       text,
  photos          jsonb not null default '[]',
  barcodes        text[] not null default '{}',
  box_qty         int,                           -- karobkada nechta dona (iBox API bermaydi — qo'lda kiritiladi)
  price           numeric(18,2),                 -- stock/selection'dan
  stock           numeric(18,3),                 -- stock/selection'dan
  stock_synced_at timestamptz,
  ibox_updated_at timestamptz,
  synced_at       timestamptz not null default now()
);
create index if not exists products_barcodes_idx on mijoz.products using gin (barcodes);
create index if not exists products_category_idx on mijoz.products (category_id);
create index if not exists products_name_lc_idx on mijoz.products (name_lc text_pattern_ops);
create index if not exists products_sku_idx on mijoz.products (lower(sku));

-- Ilovadan berilgan buyurtmalar
create table if not exists mijoz.orders (
  id              uuid primary key default gen_random_uuid(),
  no              bigint generated always as identity,  -- ilovadagi tartib raqami
  client_id       bigint not null references mijoz.clients(id),
  status          text not null default 'new'
                  check (status in ('new','sent','failed','accepted','on_way','delivered','cancelled')),
  comment         text,
  total           numeric(18,2) not null default 0,
  units           numeric(18,3) not null default 0,
  ibox_id         bigint,
  ibox_number     text,
  ibox_error      text,
  send_attempts   int not null default 0,
  created_at      timestamptz not null default now(),
  sent_at         timestamptz
);
create index if not exists orders_client_idx on mijoz.orders (client_id, created_at desc);
create index if not exists orders_status_idx on mijoz.orders (status) where status in ('new','failed');

create table if not exists mijoz.order_items (
  id              bigint generated always as identity primary key,
  order_id        uuid not null references mijoz.orders(id) on delete cascade,
  product_id      bigint not null references mijoz.products(id),
  name            text not null,
  qty             numeric(18,3) not null check (qty > 0),
  price           numeric(18,2) not null,
  total           numeric(18,2) not null
);
create index if not exists order_items_order_idx on mijoz.order_items (order_id);

-- Kirish: bir martalik kodlar va sessiyalar (faqat xeshlar saqlanadi)
create table if not exists mijoz.login_codes (
  phone_key       text primary key,
  code_hash       text not null,
  attempts        int not null default 0,
  expires_at      timestamptz not null,
  created_at      timestamptz not null default now()
);

create table if not exists mijoz.sessions (
  token_hash      text primary key,
  client_id       bigint not null references mijoz.clients(id) on delete cascade,
  created_at      timestamptz not null default now(),
  last_seen_at    timestamptz not null default now(),
  expires_at      timestamptz not null
);
create index if not exists sessions_client_idx on mijoz.sessions (client_id);

-- Sinxronlash holati (changed_since kursorlari, oxirgi xato va h.k.)
create table if not exists mijoz.sync_state (
  key             text primary key,
  value           text,
  updated_at      timestamptz not null default now()
);

-- Kategoriyalar ro'yxati (tovarlardan yig'iladi)
create or replace view mijoz.categories as
  select category_id as id, category_name as name, count(*)::int as product_count
  from mijoz.products
  where active and category_id is not null
  group by category_id, category_name;

-- Brauzerdan to'g'ridan-to'g'ri kirishni yopamiz
alter table mijoz.clients     enable row level security;
alter table mijoz.products    enable row level security;
alter table mijoz.orders      enable row level security;
alter table mijoz.order_items enable row level security;
alter table mijoz.login_codes enable row level security;
alter table mijoz.sessions    enable row level security;
alter table mijoz.sync_state  enable row level security;
revoke all on schema mijoz from public;
