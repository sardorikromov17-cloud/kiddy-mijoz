-- 2-bosqich: aksiyalar, sevimlilar, "kelganda xabar ber", oldi-berdi, chat, shikoyatlar, admin panel

-- ---------- Sozlamalar (admin paneldan o'zgartiriladi) ----------
create table if not exists mijoz.settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);
insert into mijoz.settings (key, value) values
  ('min_order_sum',        '0'),        -- umumiy minimal buyurtma summasi (so'm), 0 = cheklov yo'q
  ('ledger_enabled',       'false'),    -- oldi-berdi bo'limini mijozlarga ko'rsatish
  ('block_over_limit',     'true'),     -- kredit limitidan oshsa buyurtmani to'xtatish
  ('new_arrivals_notify',  'true'),     -- yangi tovarlar haqida kuniga bir marta xabar
  ('overdue_reminder',     'true'),     -- muddati o'tgan qarz haqida haftada bir eslatma
  ('new_days',             '14')        -- necha kun "Yangi" belgisi turadi
on conflict (key) do nothing;

-- ---------- Mijozlar: limitlar va boshlang'ich qoldiq ----------
alter table mijoz.clients add column if not exists credit_limit          numeric(18,2);  -- null = limitsiz
alter table mijoz.clients add column if not exists min_order_sum         numeric(18,2);  -- null = umumiy sozlama
alter table mijoz.clients add column if not exists opening_balance       numeric(18,2) not null default 0; -- + qarz, − haq
alter table mijoz.clients add column if not exists opening_balance_date  date;           -- shu sanadan boshlab hisoblanadi
alter table mijoz.clients add column if not exists notify_news           boolean not null default true;
alter table mijoz.clients add column if not exists overdue_notified_at   timestamptz;

-- ---------- Tovarlar: aksiya belgisi va birinchi ko'ringan vaqt ----------
alter table mijoz.products add column if not exists promo_label    text;          -- masalan "-10%" yoki "Aksiya"
alter table mijoz.products add column if not exists promo_old_price numeric(18,2); -- chizilgan eski narx (ixtiyoriy)
alter table mijoz.products add column if not exists first_seen_at  timestamptz not null default now();
alter table mijoz.products add column if not exists prev_stock     numeric(18,3); -- "kelganda xabar ber" uchun
alter table mijoz.products add column if not exists announced_at   timestamptz;   -- yangi tovar xabari yuborilgan

-- ---------- Buyurtmalar: iBox holati ----------
alter table mijoz.orders add column if not exists ibox_status        int;
alter table mijoz.orders add column if not exists status_changed_at  timestamptz;
alter table mijoz.orders add column if not exists notified_status    text;
alter table mijoz.orders drop constraint if exists orders_status_check;
alter table mijoz.orders add constraint orders_status_check
  check (status in ('new','sent','failed','accepted','shipped','on_way','delivered','cancelled'));

-- ---------- Adminlar (menejerlar) ----------
create table if not exists mijoz.admins (
  phone_key   text primary key,          -- oxirgi 9 raqam
  name        text not null,
  tg_chat_id  bigint,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);
create table if not exists mijoz.admin_sessions (
  token_hash  text primary key,
  phone_key   text not null references mijoz.admins(phone_key) on delete cascade,
  created_at  timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  expires_at  timestamptz not null
);

-- ---------- Sevimlilar va "kelganda xabar ber" ----------
create table if not exists mijoz.favorites (
  client_id  bigint not null references mijoz.clients(id) on delete cascade,
  product_id bigint not null references mijoz.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (client_id, product_id)
);
create table if not exists mijoz.stock_alerts (
  client_id   bigint not null references mijoz.clients(id) on delete cascade,
  product_id  bigint not null references mijoz.products(id) on delete cascade,
  created_at  timestamptz not null default now(),
  notified_at timestamptz,
  primary key (client_id, product_id)
);

-- ---------- Fayllar (banner rasmlari, shikoyat rasmlari) ----------
create table if not exists mijoz.files (
  id         uuid primary key default gen_random_uuid(),
  mime       text not null,
  bytes      bytea not null,
  size       int not null,
  owner      text,                       -- 'client:1024' yoki 'admin:901234567'
  created_at timestamptz not null default now()
);

-- ---------- Aksiya bannerlari ----------
create table if not exists mijoz.banners (
  id          bigint generated always as identity primary key,
  title       text not null,
  subtitle    text,
  image_id    uuid references mijoz.files(id) on delete set null,
  color       text not null default '#3D4FE0',
  link_type   text not null default 'none' check (link_type in ('none','product','category','search')),
  link_value  text,
  active      boolean not null default true,
  sort        int not null default 0,
  starts_at   timestamptz,
  ends_at     timestamptz,
  created_at  timestamptz not null default now()
);

-- ---------- Chat: mijoz ↔ menejer ----------
create table if not exists mijoz.messages (
  id            bigint generated always as identity primary key,
  client_id     bigint not null references mijoz.clients(id) on delete cascade,
  direction     text not null check (direction in ('in','out')), -- in = mijozdan, out = menejerdan
  text          text,
  file_id       uuid references mijoz.files(id) on delete set null,
  author        text,                    -- menejer ismi
  tg_message_id bigint,                  -- menejerlar guruhidagi xabar (javobni bog'lash uchun)
  read_at       timestamptz,             -- mijoz menejer xabarini ko'rgan vaqt
  admin_read_at timestamptz,             -- admin mijoz xabarini ko'rgan vaqt
  created_at    timestamptz not null default now()
);
create index if not exists messages_client_idx on mijoz.messages (client_id, id desc);
create index if not exists messages_tg_idx on mijoz.messages (tg_message_id) where tg_message_id is not null;

-- ---------- Qaytarish va shikoyatlar ----------
create table if not exists mijoz.complaints (
  id          bigint generated always as identity primary key,
  client_id   bigint not null references mijoz.clients(id) on delete cascade,
  order_id    uuid references mijoz.orders(id) on delete set null,
  product_id  bigint references mijoz.products(id) on delete set null,
  kind        text not null default 'return' check (kind in ('return','complaint')),
  qty         numeric(18,3),
  reason      text not null,
  file_ids    uuid[] not null default '{}',
  status      text not null default 'new' check (status in ('new','accepted','rejected','done')),
  admin_note  text,
  tg_message_id bigint,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists complaints_client_idx on mijoz.complaints (client_id, created_at desc);

-- ---------- Oldi-berdi (iBox hujjatlaridan) ----------
-- amount > 0 qarzni oshiradi (jo'natma), amount < 0 kamaytiradi (to'lov, qaytarish)
create table if not exists mijoz.ledger (
  id          text primary key,            -- 'shipment:123', 'payment:45', 'return:7'
  client_id   bigint not null,
  doc_date    date not null,
  kind        text not null check (kind in ('shipment','payment','return')),
  amount      numeric(18,2) not null,
  doc_number  text,
  ibox_status int,
  comment     text,
  parent_ibox_id bigint,                   -- jo'natma qaysi buyurtmadan (buyurtma holati uchun)
  synced_at   timestamptz not null default now()
);
create index if not exists ledger_client_idx on mijoz.ledger (client_id, doc_date);

-- ---------- Qidiruv tahlili ----------
create table if not exists mijoz.search_log (
  id         bigint generated always as identity primary key,
  client_id  bigint,
  q          text not null,
  results    int not null,
  created_at timestamptz not null default now()
);
create index if not exists search_log_created_idx on mijoz.search_log (created_at desc);

-- ---------- Mijoz balansi (boshlang'ich qoldiq + hujjatlar) ----------
create or replace view mijoz.client_balance as
  select c.id as client_id,
         c.opening_balance + coalesce(sum(l.amount) filter (
           where c.opening_balance_date is null or l.doc_date >= c.opening_balance_date), 0) as balance
  from mijoz.clients c
  left join mijoz.ledger l on l.client_id = c.id
  group by c.id, c.opening_balance;

alter table mijoz.settings       enable row level security;
alter table mijoz.admins         enable row level security;
alter table mijoz.admin_sessions enable row level security;
alter table mijoz.favorites      enable row level security;
alter table mijoz.stock_alerts   enable row level security;
alter table mijoz.files          enable row level security;
alter table mijoz.banners        enable row level security;
alter table mijoz.messages       enable row level security;
alter table mijoz.complaints     enable row level security;
alter table mijoz.ledger         enable row level security;
alter table mijoz.search_log     enable row level security;

-- Birinchi adminni qo'shish (raqamni o'zingiznikiga almashtiring — oxirgi 9 raqam):
-- insert into mijoz.admins (phone_key, name) values ('901234567', 'Ikromov');
