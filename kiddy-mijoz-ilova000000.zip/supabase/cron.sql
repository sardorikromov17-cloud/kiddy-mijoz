-- iBox sinxronlashni har 5 daqiqada avtomatik ishga tushirish.
-- Funksiyalar o'rnatilgandan KEYIN Supabase → SQL Editor'da bir marta bajaring.
-- 1) Ikki joyni almashtiring:
--      LOYIHA_ID    → Supabase loyihangiz manzilidagi kod (https://LOYIHA_ID.supabase.co)
--      SYNC_SECRET  → Edge Function Secrets'ga yozgan SYNC_SECRET qiymatingiz
-- Maxfiy kalit Vault'da shifrlangan holda saqlanadi.

create extension if not exists pg_cron;
create extension if not exists pg_net;

select vault.create_secret('SYNC_SECRET', 'kiddy_sync_secret');
select vault.create_secret('https://LOYIHA_ID.supabase.co/functions/v1/ibox-sync', 'kiddy_sync_url');

select cron.schedule(
  'kiddy-ibox-sync',
  '*/5 * * * *',
  $$
  select net.http_post(
    url     := (select decrypted_secret from vault.decrypted_secrets where name = 'kiddy_sync_url'),
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name = 'kiddy_sync_secret')
    ),
    body    := '{}'::jsonb,
    timeout_milliseconds := 120000
  );
  $$
);

-- Tekshirish:  select * from cron.job_run_details order by start_time desc limit 5;
-- To'xtatish:  select cron.unschedule('kiddy-ibox-sync');
