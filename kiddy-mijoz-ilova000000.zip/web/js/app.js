import { api, ApiError, cart, session } from "./api.js";
import { isNativeApp, scanNative, startScanner } from "./scanner.js";

const $app = document.getElementById("app");
const $tabbar = document.getElementById("tabbar");
const $toast = document.getElementById("toast");

// ---------- yordamchilar ----------
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
const fmtQty = (n) => (Number.isInteger(+n) ? fmt(n) : String(+Number(n).toFixed(3)));
const som = (n) => `${fmt(n)} so'm`;
const TILES = ["var(--tile1)", "var(--tile2)", "var(--tile3)", "var(--tile4)"];
const tileFor = (id) => TILES[Math.abs(Number(id) || 0) % TILES.length];
const dateUz = (iso) => {
  const d = new Date(iso);
  const m = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"][d.getMonth()];
  return `${d.getDate()}-${m}, ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

const I = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a1 1 0 0 0 1 .8h9.6a1 1 0 0 0 1-.8L21 7H6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  scan: '<path d="M3 7V4h3M21 7V4h-3M3 17v3h3M21 17v3h-3M7 8v8M10.5 8v8M14 8v8M17 8v8"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  chev: '<path d="m7 10 5 5 5-5"/>',
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2M8 9h5M8 13h5M8 16h3"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M21 20H3"/>',
  flash: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  out: '<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l-5-5 5-5M5 12h11"/>',
  tg: '<path d="m21 4-18 7 6 2 2 6 3-4 5 4z"/><path d="m9 13 12-9"/>',
  heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a2 2 0 0 0 3.4 0"/>',
  ret: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  file: '<path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  cam: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
};
// iBox'dagi KATTA HARFLI nomlarni o'qishga qulay qilish: "O'G'IL BOLALAR UCHUN" → "O'g'il bolalar uchun"
const cap = (s) => {
  const t = String(s ?? "").trim();
  if (!t || t !== t.toUpperCase() || !/[A-ZА-Я]/.test(t)) return t;
  const l = t.toLowerCase();
  return l.charAt(0).toUpperCase() + l.slice(1);
};
const icon = (name, extra = "") => `<svg class="i" viewBox="0 0 24 24" aria-hidden="true" ${extra}>${I[name]}</svg>`;
// Vaqtinchalik logotip (asl logotip fayllari kelganda icons/ papkasi almashtiriladi)
const LOGO = (size = 44) => `<img src="icons/logo.svg" width="${size}" height="${size}" alt="Kiddy Toys">`;

function ph(p, cls = "") {
  const style = `background:${tileFor(p.id)}`;
  return p.photo_url
    ? `<div class="ph ${cls}" style="${style}"><img src="${esc(p.photo_url)}" alt="" loading="lazy"></div>`
    : `<div class="ph ${cls}" style="${style}">${icon("box")}</div>`;
}

let toastTimer;
function toast(text, bad = false) {
  $toast.textContent = text;
  $toast.className = "toast" + (bad ? " bad" : "");
  $toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($toast.hidden = true), 2600);
}
// Android telefonda brauzer orqali ochilgan bo'lsa — ilovani yuklab olishni taklif qilamiz
const apkUrl = (window.KIDDY_CONFIG || {}).ANDROID_APK_URL;
const showApkOffer = () => !!apkUrl && /android/i.test(navigator.userAgent) && !isNativeApp() && !window.Telegram?.WebApp?.initData;
const apkOffer = () => showApkOffer()
  ? `<a class="note" href="${esc(apkUrl)}" style="display:flex;align-items:center;gap:10px;color:var(--ink)">${icon("box")}<span><b>Android ilovasini yuklab oling</b><br>Tezroq skaner va qulayroq ishlash uchun</span></a>`
  : "";

const fail = (e) => toast(e instanceof ApiError ? e.message : "Xatolik yuz berdi", true);

// Tovarlar xotirasi (ro'yxatdan savatga qo'shish uchun)
const products = new Map();
const remember = (list) => list.forEach((p) => products.set(String(p.id), p));

const API_BASE = ((window.KIDDY_CONFIG || {}).API_URL || "").replace(/\/+$/, "");
const fileUrl = (rel) => (rel ? `${API_BASE}/${rel}` : "");
// Bosh sahifadan olinadigan sozlamalar (minimal summa, oldi-berdi yoqilganmi)
const homeInfo = { min_order_sum: 0, ledger_enabled: false, unread: 0, default_mode: "box" };

const badgesHtml = (p) => (p.is_new || p.promo_label || p.drop_pct)
  ? `<div class="badges">${p.promo_label ? `<span class="bdg promo">${esc(p.promo_label)}</span>` : ""}${p.drop_pct ? `<span class="bdg drop">−${p.drop_pct}%</span>` : ""}${p.is_new ? '<span class="bdg">Yangi</span>' : ""}</div>` : "";
// Qarz so'm va dollarda alohida yuritilsa: "shundan 1 200 000 so'm + $350"
const partsHtml = (pt) => {
  if (!pt || Math.abs(pt.usd) < 0.01) return "";
  const side = (n) => (n > 0 ? "qarz" : "haq");
  const usd = "$" + (Math.round(Math.abs(pt.usd) * 100) / 100).toLocaleString("en-US");
  return `<span class="lbl">${Math.abs(pt.uzs) >= 1 ? `so'mda ${fmt(Math.abs(pt.uzs))} ${side(pt.uzs)} · ` : ""}dollarda ${usd} ${side(pt.usd)}</span>`;
};
// Hujjat valyutasida: so'm — "1 250 000", dollar — "$1 250.50"
const money = (n, cur) => cur === "USD"
  ? (n < 0 ? "−" : "") + "$" + Math.abs(Math.round(Number(n) * 100) / 100).toFixed(2).replace(/\.00$/, "").replace(/\B(?=(\d{3})+(?!\d))/g, " ")
  : (n < 0 ? "−" : "") + fmt(Math.abs(n));
const usdFmt = (n) => "$" + (Math.round(Number(n) * 100) / 100).toFixed(2).replace(/\.00$/, "");
const priceHtml = (p, unit = false) => p.price
  ? `<span class="pwrap"><span class="price">${fmt(p.price)}${p.promo_old_price ? `<span class="old">${fmt(p.promo_old_price)}</span>` : p.drop_from ? `<span class="old">${fmt(p.drop_from)}</span>` : ""}${unit ? ` <small>so'm / ${esc(p.unit || "dona")}</small>` : ""}</span>`
    + (p.usd ? `<span class="usd" title="iBox'dagi narx dollarda, kurs bo'yicha so'mga o'girilgan">${usdFmt(p.usd)}${unit ? " / dona" : ""}</span>` : "") + "</span>"
    + (unit && p.box_qty > 1 ? `<span class="boxprice" title="1 karobka = ${p.box_qty} dona">1 kar.: <b>${fmt(p.price * p.box_qty)}</b></span>` : "")
  : `<span class="price" style="color:var(--muted)">Narx yo'q</span>`;

async function toggleFav(id, btn) {
  const p = products.get(String(id));
  if (!p) return;
  const on = !p.is_fav;
  p.is_fav = on;
  btn?.classList.toggle("on", on);
  btn?.setAttribute("aria-pressed", String(on));
  try { await api("/favorites", { method: "POST", body: { product_id: p.id, on } }); toast(on ? "Sevimlilarga qo'shildi" : "Sevimlilardan olib tashlandi"); }
  catch (e) { p.is_fav = !on; btn?.classList.toggle("on", !on); fail(e); }
}
const heartBtn = (p, extra = "") => `<button class="heart ${p.is_fav ? "on" : ""}" data-act="fav" data-id="${p.id}" aria-pressed="${!!p.is_fav}" aria-label="Sevimlilar" ${extra}>${icon("heart")}</button>`;

/** Rasmni telefonning o'zida kichraytiradi (internet tejaladi) */
function readImage(file, max = 1280) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => reject(new Error("Rasmni o'qib bo'lmadi"));
    img.src = URL.createObjectURL(file);
  });
}

// ---------- hodisalar ----------
let actions = {};
let cleanup = [];
$app.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (!el || !$app.contains(el)) return;
  const fn = actions[el.dataset.act];
  if (fn) { e.preventDefault(); fn(el, e); }
});
$app.addEventListener("submit", (e) => {
  const fn = actions[e.target.dataset.submit];
  if (fn) { e.preventDefault(); fn(e.target, e); }
});

// ---------- Miqdor: karobka / dona ----------
// Ulgurji savdo: karobkasi bor tovarda "Karobka | Dona" tanlovi. Karobka tanlansa, 1 = 1 karobka (masalan 24 dona).
const uiMode = new Map(); // savatga hali qo'shilmagan tovar uchun tanlangan birlik
const boxOf = (p) => (p && p.box_qty > 1 ? Number(p.box_qty) : 0);
function modeOf(p) {
  if (!boxOf(p)) return "unit";
  return cart.mode(p.id) || uiMode.get(String(p.id)) || (homeInfo.default_mode === "unit" ? "unit" : "box");
}
const stepOf = (p) => (modeOf(p) === "box" ? boxOf(p) : 1);
/** "3 karobka (72 dona)" / "3 kar. + 5 dona" / "15 dona" */
function qtyText(q, box, mode, short = false) {
  if (!box || mode !== "box") return `${fmtQty(q)} dona`;
  const b = Math.floor(q / box), r = q % box;
  if (short) return r ? `${b} kar. + ${r} dona` : `${b} kar.`;
  return r ? `${b} karobka + ${r} dona (${fmtQty(q)} dona)` : `${b} karobka (${fmtQty(q)} dona)`;
}
function modeToggle(p, size = "") {
  if (!boxOf(p)) return "";
  const m = modeOf(p);
  return `<div class="unitseg ${size}" role="group" aria-label="Birlik">
    <button class="${m === "box" ? "on" : ""}" data-act="mode" data-id="${p.id}" data-m="box" aria-pressed="${m === "box"}">Karobka</button>
    <button class="${m === "unit" ? "on" : ""}" data-act="mode" data-id="${p.id}" data-m="unit" aria-pressed="${m === "unit"}">Dona</button></div>`;
}

/** Miqdor boshqaruvi. full=true — katalog/savat qatori uchun (birlik tanlovi bilan) */
function ctrl(p, full = false) {
  if (!p.can_order) return `<button class="add" disabled aria-label="Narx qo'yilmagan">+</button>`;
  const q = cart.qty(p.id), box = boxOf(p), m = modeOf(p);
  const shown = m === "box" ? Math.floor(q / box) : q;
  const unitLbl = m === "box" ? "kar." : "dona";
  const body = !q
    ? `<button class="add ${full ? "wide" : ""}" data-act="inc" data-id="${p.id}" aria-label="Savatga qo'shish">+${full ? ` <small>1 ${unitLbl}</small>` : ""}</button>`
    : `<div class="step">
        <button data-act="dec" data-id="${p.id}" aria-label="Kamaytirish">−</button>
        <input class="q" data-qin="${p.id}" inputmode="numeric" value="${shown}" aria-label="Miqdor, ${unitLbl}">
        <button class="plus" data-act="inc" data-id="${p.id}" aria-label="Ko'paytirish">+</button></div>
       ${full || box ? `<span class="qhint">${m === "box" ? `${shown} kar.${q % box ? ` + ${q % box} dona` : ""} = ${fmtQty(q)} dona` : box ? `= ${(q / box).toFixed(1).replace(".0", "")} kar.` : `${fmtQty(q)} dona`}</span>` : ""}`;
  return `<div class="qctl">${full ? modeToggle(p) : ""}${body}</div>`;
}
function refreshCtrls() {
  $app.querySelectorAll("[data-ctrl]").forEach((el) => {
    const p = products.get(el.dataset.ctrl);
    // Mijoz hozir raqam yozayotgan maydonni yangilamaymiz (yozgani o'chib ketmasin)
    const typing = document.activeElement?.tagName === "INPUT" && el.contains(document.activeElement);
    if (p && !typing) el.innerHTML = ctrl(p, el.dataset.v === "1");
  });
  renderTabbar();
  const fb = document.getElementById("floatbar");
  if (fb) {
    const n = cart.count(), b = cart.boxes();
    fb.hidden = !n;
    fb.innerHTML = `<span>${b ? `${b} kar. · ` : `${fmtQty(n)} dona · `}${som(cart.total())}</span><span>Savat →</span>`;
  }
}
cart.onChange(refreshCtrls);

function changeQty(p, delta) {
  const box = boxOf(p), m = modeOf(p);
  if (m === "box" && box) {
    // karobka rejimida butun karobkalarga yaxlitlaymiz
    const boxes = Math.max(0, Math.floor(cart.qty(p.id) / box) + delta);
    cart.set(p, boxes * box, "box");
  } else cart.set(p, cart.qty(p.id) + delta, m);
}
const stepActions = {
  inc: (el) => { const p = products.get(el.dataset.id); if (p) changeQty(p, 1); },
  dec: (el) => { const p = products.get(el.dataset.id); if (p) changeQty(p, -1); },
  mode: (el) => {
    const p = products.get(el.dataset.id);
    if (!p) return;
    uiMode.set(String(p.id), el.dataset.m);
    const q = cart.qty(p.id);
    if (q) {
      // Dona → karobka: butun karobkaga yaxlitlaymiz (kamida 1 karobka)
      if (el.dataset.m === "box") cart.set(p, Math.max(1, Math.round(q / boxOf(p))) * boxOf(p), "box");
      else cart.setMode(p, "unit");
    } else refreshCtrls();
  },
  fav: (el) => toggleFav(el.dataset.id, el),
};
// Raqamni qo'lda yozish: karobka rejimida 3 = 3 karobka
$app.addEventListener("change", (e) => {
  const el = e.target.closest("[data-qin]");
  if (!el) return;
  const p = products.get(el.dataset.qin);
  if (!p) return;
  const n = Math.max(0, parseInt(String(el.value).replace(/\D/g, ""), 10) || 0);
  el.blur();
  cart.set(p, n * stepOf(p), modeOf(p));
});
const pcard = (p) => `
  <div class="pcard">${badgesHtml(p)}<a href="#/tovar/${p.id}" style="color:inherit;display:flex;flex-direction:column;gap:6px">${ph(p)}<span class="nm">${esc(p.name)}</span></a>
    ${boxOf(p) ? `<span class="meta">${boxOf(p)} dona / karobka</span>` : ""}
    <div class="row between">${priceHtml(p)}<span data-ctrl="${p.id}">${ctrl(p)}</span></div></div>`;

// ---------- pastki menyu ----------
let currentTab = "";
function renderTabbar() {
  if (!currentTab) { $tabbar.hidden = true; return; }
  const n = cart.items().length; // ulgurji: savatdagi tovar turlari soni
  const t = (id, href, ic, label, badge = "") =>
    `<a href="${href}" class="${currentTab === id ? "on" : ""}" ${currentTab === id ? 'aria-current="page"' : ""}>${icon(ic)}${label}${badge}</a>`;
  $tabbar.innerHTML =
    t("home", "#/", "home", "Bosh sahifa") +
    t("katalog", "#/katalog", "grid", "Katalog") +
    t("savat", "#/savat", "cart", "Savat", n ? `<span class="badge">${n > 99 ? "99+" : n}</span>` : "") +
    t("kabinet", "#/kabinet", "user", "Kabinet");
  $tabbar.hidden = false;
}

// ================= SAHIFALAR =================

// ---------- Kirish ----------
function viewLogin() {
  currentTab = "";
  const TGW = window.Telegram?.WebApp;
  const inTg = !!TGW?.initData;
  const st = { step: inTg ? "tg" : "phone", phone: "", botUrl: null, choose: [], code: "", devCode: null, busy: false, err: "", viaTg: inTg };
  const draw = () => {
    let body = "";
    if (st.step === "phone") {
      body = `
        <div><h1>Xush kelibsiz!</h1><p class="muted" style="margin:6px 0 0;line-height:1.45">Ulgurji mijozlar uchun buyurtma ilovasi. Telefon raqamingiz orqali kiring.</p></div>
        <form data-submit="request" class="field">
          <label for="tel"><span style="font-size:14px;font-weight: 600">Telefon raqam</span></label>
          <div class="input-wrap"><b style="font-size:17px">+998</b>
            <input id="tel" type="tel" inputmode="tel" autocomplete="tel-national" placeholder="90 123 45 67" value="${esc(st.phone)}" required></div>
          ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
          <button class="btn block" ${st.busy ? "disabled" : ""}>Kod olish</button>
        </form>
        <div class="note">Faqat bazada ro'yxatdan o'tgan mijozlar kira oladi. Raqamingiz topilmasa, menejerga murojaat qiling.</div>
        ${apkOffer()}`;
    } else if (st.step === "telegram") {
      body = `
        <div><h1>Telegram'ni ulang</h1><p class="muted" style="margin:6px 0 0;line-height:1.45">Kirish kodi Telegram orqali keladi. Botni oching, <b>«Raqamimni yuborish»</b> tugmasini bosing, so'ng shu yerga qayting.</p></div>
        ${st.botUrl ? `<a class="btn block" href="${esc(st.botUrl)}" target="_blank" rel="noopener">${icon("tg")} Telegram botni ochish</a>` : `<div class="note warn">Bot hali sozlanmagan. Menejerga murojaat qiling.</div>`}
        ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
        <button class="btn soft block" data-act="request" ${st.busy ? "disabled" : ""}>Raqamni yubordim — kod olish</button>
        <button class="link" data-act="restart">Boshqa raqam</button>`;
    } else if (st.step === "tg") {
      body = `<div><h1>Kirilmoqda…</h1><p class="muted" style="margin:6px 0 0">Telegram orqali avtomatik kiryapmiz.</p></div>
        ${st.err ? `<div class="err">${esc(st.err)}</div><button class="btn soft block" data-act="restart">Telefon raqam bilan kirish</button>` : '<div class="skeleton" style="height:54px"></div>'}`;
    } else if (st.step === "tgcontact") {
      body = `<div><h1>Raqamingizni ulang</h1><p class="muted" style="margin:6px 0 0;line-height:1.45">Bu Telegram hisobi hali do'koningizga ulanmagan. Raqamingizni yuboring — bir marta, keyin ilova o'zi ochiladi.</p></div>
        <button class="btn block" data-act="tgshare">${icon("tg")} Raqamimni yuborish</button>
        ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
        <button class="link" data-act="restart">Telefon raqam va kod bilan kirish</button>`;
    } else if (st.step === "code") {
      body = `
        <div><h1>Kodni kiriting</h1><p class="muted" style="margin:6px 0 0">+998 ${esc(st.phone)} uchun kod Telegram'ga yuborildi.</p></div>
        <form data-submit="verify" class="field">
          <label for="code" class="sr-only">4 xonali kod</label>
          <input id="code" class="input code-input" inputmode="numeric" autocomplete="one-time-code" maxlength="4" pattern="\\d{4}" value="${esc(st.code)}" required>
          ${st.devCode ? `<div class="note warn">Sinov rejimi: kod <b>${esc(st.devCode)}</b></div>` : ""}
          ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
          <button class="btn block" ${st.busy ? "disabled" : ""}>Kirish</button>
        </form>
        <button class="link" data-act="restart">Raqamni o'zgartirish</button>`;
    } else {
      body = `
        <div><h1>Do'konni tanlang</h1><p class="muted" style="margin:6px 0 0">Bu raqamga bir nechta do'kon bog'langan.</p></div>
        ${st.choose.map((c) => `<button class="btn soft block" data-act="pick" data-id="${c.id}">${esc(c.name)}</button>`).join("")}
        ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}`;
    }
    $app.innerHTML = `<div class="login"><span class="deco1"></span><span class="deco2"></span>
      <div class="top">${LOGO(96)}<b>Kiddy Toys</b></div>
      <div class="panel">${body}</div></div>`;
    $app.querySelector("#tel, #code")?.focus();
    // 4 ta raqam yozilishi bilan avtomatik kiradi
    $app.querySelector("#code")?.addEventListener("input", (e) => {
      const v = e.target.value.replace(/\D/g, "").slice(0, 4);
      e.target.value = v;
      if (v.length === 4 && !st.busy) verify();
    });
  };
  // Telegram botdan qaytganda kodni o'zi so'raydi
  const onVisible = () => { if (document.visibilityState === "visible" && st.step === "telegram" && !st.busy) request(); };
  document.addEventListener("visibilitychange", onVisible);
  cleanup.push(() => document.removeEventListener("visibilitychange", onVisible));

  const request = async () => {
    const input = $app.querySelector("#tel");
    if (input) st.phone = input.value.trim();
    st.busy = true; st.err = ""; draw();
    try {
      const r = await api("/auth/request", { method: "POST", body: { phone: st.phone } });
      if (r.need_telegram) { st.step = "telegram"; st.botUrl = r.bot_url; }
      else { st.step = "code"; st.devCode = r.dev_code || null; }
    } catch (e) {
      if (e.code === "too_soon") st.step = "code";
      st.err = e.message;
    }
    st.busy = false; draw();
  };
  const verify = async (clientId) => {
    const input = $app.querySelector("#code");
    if (input) st.code = input.value.trim();
    st.busy = true; st.err = ""; draw();
    try {
      const r = await api("/auth/verify", { method: "POST", body: { phone: st.phone, code: st.code, client_id: clientId } });
      if (r.choose) { st.step = "choose"; st.choose = r.choose; }
      else { session.save(r.token, r.client); location.hash = "#/"; return; }
    } catch (e) { st.err = e.message; }
    st.busy = false; draw();
  };
  // Telegram Mini App: imzolangan initData bilan avtomatik kirish
  const tgLogin = async (clientId) => {
    st.busy = true; st.err = ""; draw();
    try {
      const r = await api("/auth/telegram", { method: "POST", body: { init_data: TGW.initData, client_id: clientId } });
      if (r.token) { session.save(r.token, r.client); location.hash = "#/"; return; }
      if (r.choose) { st.step = "choose"; st.choose = r.choose; }
      else if (r.need_contact) st.step = "tgcontact";
    } catch (e) { st.err = e.message; }
    st.busy = false; draw();
  };
  actions = {
    request, verify: () => verify(),
    pick: (el) => (st.viaTg && st.step === "choose" ? tgLogin(Number(el.dataset.id)) : verify(Number(el.dataset.id))),
    tgshare: () => {
      if (TGW?.requestContact) {
        TGW.requestContact((ok) => { if (ok) setTimeout(() => tgLogin(), 1500); else { st.err = "Raqam yuborilmadi"; draw(); } });
      } else { TGW?.close?.(); }
    },
    restart: () => { st.step = "phone"; st.viaTg = false; st.err = ""; st.code = ""; draw(); },
  };
  draw();
  if (st.step === "tg") tgLogin();
}

// ---------- Bosh menyu ----------
// ---------- Ro'yxat bilan buyurtma ----------
// Mijoz ro'yxatni yozadi yoki nusxalab qo'yadi: har qatorda "kod yoki nom + miqdor". Biz topib, savatga qo'shamiz.
function viewListOrder() {
  currentTab = "savat";
  const st = { text: (() => { try { return localStorage.getItem("kt_list") || ""; } catch { return ""; } })(), items: null, busy: false, err: "" };
  const draw = () => {
    $app.innerHTML = `<div class="page">
      <div class="row"><a class="icon-btn" href="#/" aria-label="Orqaga">${icon("back")}</a><h1 class="grow">Ro'yxat bilan buyurtma</h1></div>
      ${st.items ? listResult() : `
      <div class="note">Har qatorga bitta tovar: kodi, shtrix-kodi yoki nomi va miqdori. Masalan:<br>
        <code>008-959 5 kor</code><br><code>kukla barbi 12</code><br><code>40000305 3</code><br>
        «kor» yozilsa — karobka, yozilmasa — dona. Excel yoki Telegram'dan nusxalab qo'yish mumkin.</div>
      <textarea id="ltext" class="input" rows="10" style="height:auto;padding:12px 14px;font-size:16px" placeholder="Ro'yxatni shu yerga yozing…">${esc(st.text)}</textarea>
      ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
      <button class="btn block" data-act="parse" ${st.busy ? "disabled" : ""}>${st.busy ? "Qidirilmoqda…" : "Tovarlarni topish"}</button>`}
    </div>`;
  };
  const qtyOf = (it) => {
    const p = it.match, box = p ? boxOf(p) : 0;
    return it.unit === "box" && box ? { qty: it.qty * box, mode: "box", label: `${it.qty} kar. (${it.qty * box} dona)` } : { qty: it.qty, mode: "unit", label: `${it.qty} dona` };
  };
  const listResult = () => {
    const found = st.items.filter((i) => i.match && i.on !== false);
    const sum = found.reduce((a, i) => a + (i.match.price || 0) * qtyOf(i).qty, 0);
    return `<div class="plist">${st.items.map((it, n) => it.match ? `
      <div class="card lrow2 ${it.on === false ? "off" : ""}">
        <label class="lchk"><input type="checkbox" data-act="ltoggle" data-n="${n}" ${it.on === false ? "" : "checked"}></label>
        <div class="grow" style="display:flex;flex-direction:column;gap:3px">
          <span class="meta">«${esc(it.line)}»${it.how === "taxminiy" ? ' <b style="color:var(--amber,#8A4B00)">· taxminiy</b>' : ""}</span>
          <b style="font-size:15px">${esc(it.match.name)}</b>
          <span class="meta">${qtyOf(it).label} · ${it.match.price ? som(it.match.price * qtyOf(it).qty) : "narx yo'q"}${(it.match.stock ?? 0) <= 0 ? ' · <span style="color:var(--red)">omborda yo\'q</span>' : ""}</span>
          ${it.alternatives.length ? `<div class="row" style="gap:6px;flex-wrap:wrap">${it.alternatives.map((a, k) => `<button class="chip" style="height:30px;font-size:12px" data-act="lalt" data-n="${n}" data-k="${k}">${esc(a.name.slice(0, 28))}</button>`).join("")}</div>` : ""}
        </div></div>` : `
      <div class="card lrow2 off"><span class="lchk">✕</span><div class="grow"><span class="meta">«${esc(it.line)}»</span><b style="font-size:14px;color:var(--red)">Topilmadi</b></div></div>`).join("")}</div>
      <div class="sumrow total"><span>${found.length} ta tovar</span><b>${som(sum)}</b></div>
      <button class="btn block" data-act="ladd" ${found.length ? "" : "disabled"}>Savatga qo'shish</button>
      <button class="btn soft block" data-act="ledit">Ro'yxatni tahrirlash</button>`;
  };
  actions = {
    parse: async () => {
      st.text = document.getElementById("ltext").value;
      try { localStorage.setItem("kt_list", st.text); } catch { /* */ }
      if (!st.text.trim()) { st.err = "Ro'yxat bo'sh"; draw(); return; }
      st.busy = true; st.err = ""; draw();
      try { const r = await api("/list-parse", { method: "POST", body: { text: st.text } }); st.items = r.items; r.items.forEach((i) => { if (i.match) remember([i.match, ...i.alternatives]); }); }
      catch (e) { st.err = e.message; }
      st.busy = false; draw();
    },
    ltoggle: (el) => { const it = st.items[Number(el.dataset.n)]; it.on = el.checked; draw(); },
    lalt: (el) => { const it = st.items[Number(el.dataset.n)], k = Number(el.dataset.k); const cur = it.match; it.match = it.alternatives[k]; it.alternatives[k] = cur; draw(); },
    ledit: () => { st.items = null; draw(); },
    ladd: () => {
      let n = 0;
      for (const it of st.items) {
        if (!it.match || it.on === false || !it.match.can_order) continue;
        const { qty, mode } = qtyOf(it);
        cart.add(it.match, qty, mode); n++;
      }
      try { localStorage.removeItem("kt_list"); } catch { /* */ }
      toast(`${n} ta tovar savatga qo'shildi`);
      location.hash = "#/savat";
    },
  };
  draw();
}

// ---------- yangiliklar ----------
const dayUz = (iso) => { const d = new Date(iso); return `${d.getDate()} ${["yanvar","fevral","mart","aprel","may","iyun","iyul","avgust","sentabr","oktabr","noyabr","dekabr"][d.getMonth()]}`; };
const postImg = (p) => p.image_url ? `<img src="${esc(fileUrl(p.image_url))}" alt="" loading="lazy">` : `<span class="post-ph">${icon("news")}</span>`;
const postCard = (p) => `<a class="post-card" href="#/yangilik/${p.id}">${postImg(p)}
  <span class="pc-body">${p.pinned ? '<span class="bdg">Muhim</span>' : ""}<b>${esc(p.title)}</b><span class="meta">${dayUz(p.published_at)}</span></span></a>`;

async function viewPosts() {
  currentTab = "home";
  $app.innerHTML = `<div class="page">
    <div class="row"><a class="icon-btn" href="#/" aria-label="Orqaga">${icon("back")}</a><h1 class="grow">Yangiliklar</h1></div>
    <div id="plist" class="plist">${'<div class="skeleton" style="height:120px"></div>'.repeat(3)}</div></div>`;
  try {
    const r = await api("/posts");
    try { localStorage.setItem("kt_posts_seen", String(Math.max(0, ...r.items.map((p) => p.id)))); } catch { /* */ }
    document.getElementById("plist").innerHTML = r.items.length ? r.items.map((p) => `
      <a class="card post-row" href="#/yangilik/${p.id}">${p.image_url ? `<img src="${esc(fileUrl(p.image_url))}" alt="" loading="lazy">` : ""}
        <span class="grow" style="display:flex;flex-direction:column;gap:4px">${p.pinned ? '<span class="bdg" style="align-self:flex-start">Muhim</span>' : ""}
          <b style="font-size:16px">${esc(p.title)}</b><span class="meta">${dayUz(p.published_at)}${p.products ? ` · ${p.products} ta tovar` : ""}</span>
          ${p.excerpt ? `<span class="small" style="color:var(--muted)">${esc(p.excerpt)}${p.excerpt.length >= 220 ? "…" : ""}</span>` : ""}</span></a>`).join("")
      : `<div class="empty">Hozircha yangilik yo'q</div>`;
  } catch (e) { document.getElementById("plist").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}

async function viewPost(id) {
  currentTab = "home";
  $app.innerHTML = `<div class="page"><div class="skeleton" style="height:240px"></div></div>`;
  let p;
  try { p = await api(`/posts/${id}`); } catch (e) { $app.innerHTML = `<div class="page"><div class="empty">${esc(e.message)}<a class="btn" href="#/yangiliklar">Yangiliklar</a></div></div>`; return; }
  $app.innerHTML = `<div class="page">
    <div class="row"><a class="icon-btn" href="#/yangiliklar" data-act="back" aria-label="Orqaga">${icon("back")}</a><span class="meta grow">${dayUz(p.published_at)}</span></div>
    ${p.image_url ? `<img class="post-hero" src="${esc(fileUrl(p.image_url))}" alt="">` : ""}
    <h1>${esc(p.title)}</h1>
    ${p.body ? `<div class="post-body">${esc(p.body).replace(/\n/g, "<br>")}</div>` : ""}
    ${p.products.length ? `<h2>Tovarlar</h2><div class="grid2">${p.products.map(pcard).join("")}</div>` : ""}
    <a class="btn soft block" href="#/chat">${icon("chat")} Menejerdan so'rash</a>
  </div>`;
  actions = { ...stepActions, back: () => (history.length > 1 ? history.back() : (location.hash = "#/yangiliklar")) };
}

async function viewHome() {
  currentTab = "home";
  const c = session.client || {};
  $app.innerHTML = `<div class="page">
    <div class="hello">${LOGO(44)}<div class="who"><span class="muted small">Xush kelibsiz,</span><b>${esc(c.name)}</b></div>
      <a class="icon-btn" href="#/chat" aria-label="Menejer bilan chat" id="chatbtn">${icon("chat")}</a></div>
    <div class="search">
      <a class="input-wrap" href="#/katalog?focus=1" style="color:var(--muted);font-weight: 400">${icon("search")} Tovar nomi yoki kodi…</a>
      <a class="icon-btn primary" href="#/skaner" aria-label="Shtrix-kodni skanerlash">${icon("scan")}</a>
    </div>
    <div class="qtiles">
      <a class="qtile" href="#/royxat"><span class="qi">📝</span><span>Ro'yxat bilan buyurtma</span></a>
      <a class="qtile" id="qrepeat" href="#/kabinet"><span class="qi">🔁</span><span>Oxirgi xaridni takrorlash</span></a>
      <a class="qtile" href="#/katalog?sort=new"><span class="qi">🆕</span><span>Yangi kelganlar</span></a>
    </div>
    <div id="hfolders" hidden></div>
    <div class="banners" id="banners" hidden></div>
    <div id="hero"><div class="skeleton" style="height:150px"></div></div>
    <div id="freq" hidden></div>
    <div id="posts" hidden></div>
    <div id="cheaper" hidden></div>
    <div class="row between"><h2>Bo'limlar</h2><a href="#/katalog" style="font-weight: 500;font-size:14px">Hammasi</a></div>
    <div class="cats" id="cats">${'<div class="skeleton" style="height:90px"></div>'.repeat(4)}</div>
    <a class="btn soft block" id="allcat" href="#/katalog">Butun katalog</a>
    <div class="row between"><h2>Yangi kelganlar</h2><a href="#/katalog?sort=new" style="font-weight: 500;font-size:14px">Barchasi</a></div>
    <div class="grid2" id="news">${'<div class="skeleton" style="height:200px"></div>'.repeat(4)}</div>
  </div>
  <a id="floatbar" class="floatbar" href="#/savat" hidden></a>`;
  refreshCtrls();
  actions = { ...stepActions };

  api("/me").then((me) => { session.setClient(me); const b = $app.querySelector(".who b"); if (b) b.textContent = me.name; }).catch(() => {});

  api("/home").then((h) => {
    Object.assign(homeInfo, { min_order_sum: h.min_order_sum, ledger_enabled: h.ledger_enabled, unread: h.unread_messages, default_mode: h.default_mode || "box", loaded: true });
    const cb = document.getElementById("chatbtn");
    if (cb && h.unread_messages) cb.insertAdjacentHTML("beforeend", `<span class="badge">${h.unread_messages}</span>`);
    const qr = document.getElementById("qrepeat");
    if (qr) {
      if (h.last_order) { qr.href = `#/buyurtma/${h.last_order.id}?repeat=1`; qr.querySelector("span:last-child").textContent = `Oxirgi xarid №${h.last_order.no}`; }
      else { qr.classList.add("off"); qr.removeAttribute("href"); qr.querySelector("span:last-child").textContent = "Oxirgi xarid hali yo'q"; }
    }
    const ac = document.getElementById("allcat");
    if (ac && h.catalog_count) ac.textContent = `Butun katalog (${fmt(h.catalog_count)} ta tovar)`;
    // Yangiliklar
    const pEl = document.getElementById("posts");
    if (pEl && h.posts?.length) {
      pEl.hidden = false;
      pEl.innerHTML = `<div class="row between" style="margin-bottom:10px"><h2>Yangiliklar</h2><a href="#/yangiliklar" style="font-weight:600;font-size:14px">Hammasi</a></div>
        <div class="hscroll">${h.posts.map(postCard).join("")}</div>`;
    }
    // Arzonlashganlar
    const chEl = document.getElementById("cheaper");
    if (chEl && h.cheaper?.length) {
      chEl.hidden = false;
      chEl.innerHTML = `<div class="row between" style="margin-bottom:10px"><h2>📉 Arzonlashdi</h2><a href="#/katalog?special=cheaper" style="font-weight:600;font-size:14px">Hammasi</a></div>
        <div class="hscroll">${h.cheaper.map((p) => `<div class="hs-item">${pcard(p)}</div>`).join("")}</div>`;
    }
    // Aksiya bannerlari
    const bEl = document.getElementById("banners");
    if (bEl && h.banners.length) {
      bEl.innerHTML = h.banners.map((b) => {
        const href = b.link_type === "product" ? `#/tovar/${encodeURIComponent(b.link_value)}`
          : b.link_type === "category" ? `#/katalog?cat=${encodeURIComponent(b.link_value)}`
          : b.link_type === "search" ? `#/katalog?q=${encodeURIComponent(b.link_value)}` : "";
        const inner = `${b.image_url ? `<img src="${esc(fileUrl(b.image_url))}" alt="">` : ""}<div><b>${esc(b.title)}</b>${b.subtitle ? `<span>${esc(b.subtitle)}</span>` : ""}</div>`;
        return href ? `<a class="banner" href="${href}" style="background:${esc(b.color)}">${inner}</a>` : `<div class="banner" style="background:${esc(b.color)}">${inner}</div>`;
      }).join("");
      bEl.hidden = false;
    }
    // Qarz kartasi yoki oxirgi buyurtma
    const hero = document.getElementById("hero");
    if (hero) {
      const l = h.ledger, o = h.last_order;
      hero.innerHTML = l ? `<div class="debt-card">
          <span class="lbl">${l.advance > 0 ? "Sizning haqqingiz (avans)" : "Joriy qarzingiz"}</span>
          <span class="big">${som(l.advance > 0 ? l.advance : l.debt)}</span>${partsHtml(l.parts)}
          ${l.overdue > 0 ? `<span class="warn">⏰ Muddati o'tgan: ${som(l.overdue)}</span>` : ""}
          ${l.credit_limit ? `<span class="lbl">Kredit limiti: ${som(l.credit_limit)} · bo'sh: ${som(Math.max(0, l.credit_limit - l.debt))}</span>` : ""}
          <a class="btn-white" href="#/kabinet?tab=ledger">Oldi-berdini ko'rish →</a></div>`
        : `<div class="hero">${o
          ? `<span class="lbl">Oxirgi buyurtma · ${dateUz(o.created_at)}</span><span class="big">№${o.no} · ${som(o.total)}</span>
             <a class="btn-white" href="#/buyurtma/${o.id}">Buyurtmani ko'rish →</a>`
          : `<span class="lbl">Hali buyurtma yo'q</span><span class="big">Birinchi buyurtmani bering!</span><a class="btn-white" href="#/katalog">Katalogni ochish →</a>`}</div>`;
    }
    // Tez-tez oladiganlarim
    const fEl = document.getElementById("freq");
    if (fEl && h.frequent.length) {
      remember(h.frequent);
      fEl.innerHTML = `<div class="row between" style="margin-bottom:10px"><h2>Tez-tez oladiganlarim</h2><a href="#/katalog?fav=1" style="font-weight: 500;font-size:14px">Sevimlilar</a></div>
        <div class="hscroll">${h.frequent.map(pcard).join("")}</div>`;
      fEl.hidden = false;
    }
  }).catch(fail);

  // Bo'limlar: iBox guruhlari (o'g'il bolalar, qizlar, chaqaloqlar…); guruh yo'q bo'lsa — kategoriyalar
  api("/catalog").then((r) => {
    const fh = document.getElementById("hfolders");
    if (fh && r.folders?.length) {
      fh.hidden = false;
      fh.innerHTML = `<div class="row between" style="margin-bottom:10px"><h2>Papkalar</h2><a href="#/katalog" style="font-weight:600;font-size:14px">Hammasi</a></div>
        <div class="folders">${r.folders.map((f) => `<a class="fold" href="#/katalog?folder=${f.id}">${f.photo ? `<img src="${esc(f.photo)}" alt="" loading="lazy">` : `<span class="fi">${f.id === 0 ? "📦" : "📁"}</span>`}<span>${esc(cap(f.name))}</span><small>${f.n}</small></a>`).join("")}</div>`;
    }
    const el = document.getElementById("cats");
    if (!el) return;
    const useGroups = r.groups.length >= 2;
    const list = (useGroups ? r.groups : r.categories).slice(0, 8);
    el.innerHTML = list.map((k) => `
      <a class="cat" href="#/katalog?${useGroups ? "group" : "cat"}=${k.id}">${k.photo
        ? `<span class="tile photo"><img src="${esc(k.photo)}" alt="" loading="lazy"></span>`
        : `<span class="tile" style="background:${tileFor(k.id)}">${esc((k.name || "?").trim()[0]?.toUpperCase())}</span>`}${esc(cap(k.name))}</a>`).join("")
      || `<p class="muted small">Bo'limlar yo'q</p>`;
  }).catch(() => {});

  api("/products?sort=new&in_stock=1&limit=6").then((r) => {
    remember(r.items);
    const el = document.getElementById("news");
    if (el) el.innerHTML = r.items.map(pcard).join("") || `<p class="muted small">Tovarlar hali yuklanmagan</p>`;
  }).catch(() => {});
}

// ---------- Katalog ----------
const catalogState = { q: "", cat: null, group: null, brand: null, folder: null, special: "", sort: "", inStock: true, items: [], offset: 0, hasMore: false, tree: null, fuzzy: false, dym: [] };
// Katalog ko'rinishi admin sozlamasidan: "media" (3 ustunli rasm to'ri) yoki "list" (ro'yxat)
let catalogCfg = null;
async function viewCatalog(params) {
  currentTab = "katalog";
  if (!catalogCfg) {
    $app.innerHTML = `<div class="page"><div class="skeleton" style="height:120px"></div><div class="skeleton" style="height:320px"></div></div>`;
    try {
      const t = await api("/catalog?in_stock=1");
      catalogCfg = t.cfg || { view: "media", tabs: "folder" };
      catalogState.rootTree = t;
    } catch (e) { catalogCfg = { view: "list", tabs: "folder" }; }
  }
  return catalogCfg.view === "list" ? viewCatalogList(params) : viewCatalogMedia(params);
}
async function viewCatalogList(params) {
  currentTab = "katalog";
  const st = catalogState;
  if (params.has("cat")) { st.cat = Number(params.get("cat")) || null; st.special = ""; }
  if (params.has("group")) { st.group = Number(params.get("group")) || null; st.cat = null; st.brand = null; st.special = ""; }
  if (params.has("brand")) { st.brand = params.get("brand") || null; st.special = ""; }
  if (params.has("folder")) { const f = params.get("folder"); st.folder = f === "" ? null : Number(f); st.group = null; st.cat = null; st.brand = null; st.special = ""; }
  if (params.has("q")) st.q = params.get("q");
  if (params.get("fav") === "1") { st.special = "fav"; st.cat = null; }
  if (params.get("promo") === "1") { st.special = "promo"; st.cat = null; }
  if (params.get("sort") === "new") { st.special = "new"; st.cat = null; }
  if (params.get("special") === "cheaper") { st.special = "cheaper"; st.cat = null; st.group = null; st.brand = null; }

  $app.innerHTML = `<div class="page">
    <h1>Katalog</h1>
    <div class="folders" id="folders" hidden></div>
    <div class="search">
      <label class="input-wrap">${icon("search")}<span class="sr-only">Qidirish</span>
        <input id="q" type="search" placeholder="Nomi, artikul yoki shtrix-kod" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search"></label>
      <a class="icon-btn primary" href="#/skaner" aria-label="Shtrix-kodni skanerlash">${icon("scan")}</a>
    </div>
    <div class="sugg" id="sugg" hidden></div>
    <div class="chips" id="chips"></div>
    <div class="filters" id="filters"></div>
    <div id="dym"></div>
    <div class="row between"><span class="muted small" id="found"></span>
      <button class="toggle" data-act="instock" aria-pressed="${st.inStock}">Faqat omborda borlari <span class="sw"></span></button></div>
    <div class="plist" id="list"></div>
    <div id="more"></div>
  </div>
  <a id="floatbar" class="floatbar" href="#/savat" hidden></a>`;

  const SORTS = [["", "Mavjudlari"], ["az", "A–Z"], ["price_asc", "Arzonroq"], ["price_desc", "Qimmatroq"]];
  const SPECIAL = [{ k: "fav", name: "❤ Sevimlilar" }, { k: "promo", name: "🔥 Aksiya" }, { k: "cheaper", name: "📉 Arzonlashgan" }, { k: "new", name: "🆕 Yangi" }];
  const nameOf = (list, id) => (list || []).find((x) => String(x.id ?? x.name) === String(id))?.name;
  const drawChips = () => {
    const el = document.getElementById("chips");
    if (!el) return;
    const t = st.tree || {};
    // Yuqoridagi papkalar (iBox'dagi papkalar)
    const fEl = document.getElementById("folders");
    if (fEl && t.folders?.length) {
      fEl.hidden = false;
      fEl.innerHTML = `<button class="fold ${st.folder === null ? "on" : ""}" data-act="folder" data-id=""><span class="fi">📂</span><span>Hammasi</span></button>` +
        t.folders.map((f) => `<button class="fold ${st.folder === f.id ? "on" : ""}" data-act="folder" data-id="${f.id}">
          ${f.photo ? `<img src="${esc(f.photo)}" alt="" loading="lazy">` : `<span class="fi">${f.id === 0 ? "📦" : "📁"}</span>`}
          <span>${esc(cap(f.name))}</span><small>${f.n}</small></button>`).join("");
    }
    const all = `<button class="chip ${!st.group && !st.special ? "on" : ""}" data-act="group" data-id="">Hammasi</button>`;
    const sp = SPECIAL.map((x) => `<button class="chip ${st.special === x.k ? "on" : ""}" data-act="special" data-k="${x.k}">${x.name}</button>`).join("");
    const gr = (t.groups || []).map((g) => `<button class="chip ${st.group === g.id ? "on" : ""}" data-act="group" data-id="${g.id}">${esc(cap(g.name))}</button>`).join("");
    el.innerHTML = all + gr + sp;
    const f = document.getElementById("filters");
    if (f) {
      const catName = st.cat ? (nameOf(t.categories, st.cat) || "tanlangan") : null;
      f.innerHTML = `
        <button class="fbtn ${st.cat ? "on" : ""}" data-act="pick" data-k="cat"><span class="lbl">Kategoriya</span><b>${esc(catName ? cap(catName) : "Hammasi")}</b>${icon("chev")}</button>
        <button class="fbtn ${st.brand ? "on" : ""}" data-act="pick" data-k="brand"><span class="lbl">Brend</span><b>${esc(st.brand ? cap(st.brand) : "Hammasi")}</b>${icon("chev")}</button>
        <button class="fbtn sortb" data-act="sort"><span class="lbl">Tartib</span><b>${SORTS.find((x) => x[0] === st.sort)?.[1] || "Nomi"}</b></button>
        ${st.cat || st.brand ? `<button class="fclear" data-act="fclear" aria-label="Filtrlarni tozalash">✕</button>` : ""}`;
    }
  };
  const loadTree = async () => {
    try { st.tree = await api(`/catalog?${st.group ? `group=${st.group}&` : ""}${st.folder !== null ? `folder=${st.folder}&` : ""}${st.inStock ? "in_stock=1" : ""}`); drawChips(); } catch { /* */ }
  };
  // Kategoriya / brend tanlash oynasi
  const openPick = (k) => {
    const t = st.tree || {};
    const list = k === "cat" ? (t.categories || []).map((c) => ({ v: c.id, name: c.name, n: c.n })) : (t.brands || []).map((b) => ({ v: b.name, name: b.name, n: b.n }));
    const cur = k === "cat" ? st.cat : st.brand;
    document.getElementById("pick")?.remove();
    $app.insertAdjacentHTML("beforeend", `<div id="pick"><div class="modal-bg" data-act="pclose"></div>
      <div class="sheet confirm" role="dialog" aria-modal="true" aria-labelledby="pkt">
        <h2 id="pkt" style="font-size:20px">${k === "cat" ? "Kategoriya" : "Brend"}${st.group ? ` · ${esc(cap(nameOf(t.groups, st.group) || ""))}` : ""}</h2>
        ${list.length > 8 ? `<label class="input-wrap" style="height:46px">${icon("search")}<input id="pq" placeholder="Qidirish" autocomplete="off"></label>` : ""}
        <div class="plistsel" id="plist">
          <button class="popt ${!cur ? "on" : ""}" data-act="pset" data-k="${k}" data-v=""><span>Hammasi</span></button>
          ${list.map((x) => `<button class="popt ${String(cur) === String(x.v) ? "on" : ""}" data-act="pset" data-k="${k}" data-v="${esc(String(x.v))}" data-s="${esc(x.name.toLowerCase())}"><span>${esc(cap(x.name))}</span><small>${x.n}</small></button>`).join("")}
        </div>
      </div></div>`);
    document.getElementById("pq")?.addEventListener("input", (e) => {
      const v = e.target.value.trim().toLowerCase();
      document.querySelectorAll("#plist .popt[data-s]").forEach((b) => { b.hidden = v && !b.dataset.s.includes(v); });
    });
  };
  // Qidiruv takliflari (yozayotganda)
  let sTimer, sReq = 0;
  const drawSugg = (items) => {
    const el = document.getElementById("sugg");
    if (!el) return;
    const ic = { group: "🗂", category: "📁", brand: "🏷", query: "🔍" };
    const what = { group: "bo'lim", category: "kategoriya", brand: "brend", query: "" };
    el.innerHTML = items.map((x) => `<button class="sopt" data-act="sugg" data-type="${x.type}" data-id="${esc(String(x.id ?? ""))}" data-label="${esc(x.label)}">
      <span aria-hidden="true">${ic[x.type]}</span><span class="grow">${esc(x.type === "query" ? x.label : cap(x.label))}</span>${what[x.type] ? `<small>${what[x.type]}${x.n ? ` · ${x.n}` : ""}</small>` : ""}</button>`).join("");
    el.hidden = !items.length;
  };
  const askSugg = (v) => {
    clearTimeout(sTimer);
    if (v.length < 2) { drawSugg([]); return; }
    sTimer = setTimeout(async () => {
      const my = ++sReq;
      try { const r = await api(`/suggest?q=${encodeURIComponent(v)}`); if (my === sReq && document.activeElement?.id === "q") drawSugg(r.items); } catch { /* */ }
    }, 180);
  };
  const drawDym = () => {
    const el = document.getElementById("dym");
    if (!el) return;
    el.innerHTML = st.q && (st.fuzzy || (!st.items.length && st.dym.length))
      ? `<div class="dym"><span>«${esc(st.q)}» bo'yicha aniq topilmadi.${st.fuzzy ? " O'xshash tovarlar ko'rsatildi." : ""}</span>
          ${st.dym.length ? `<div class="row wrap">Balki: ${st.dym.map((w) => `<button class="chip" data-act="dym" data-w="${esc(w)}">${esc(w)}</button>`).join("")}</div>` : ""}</div>`
      : "";
  };
  // Ulgurji qator: tepada rasm va nom (keng), pastda narx va miqdor
  const row = (p) => `
    <div class="prow2">
      <a class="top" href="#/tovar/${p.id}">
        <span class="rel">${ph(p)}${badgesHtml(p)}</span>
        <span class="info">
          <span class="nm">${esc(p.name)}</span>
          <span class="meta">${[p.sku && `Kod: ${esc(p.sku)}`, boxOf(p) && `Karobkada ${boxOf(p)} ${esc(p.unit || "dona")}`].filter(Boolean).join(" · ")}</span>
          <span class="${p.stock > 0 ? "stock-ok" : "stock-no"}">${p.stock > 0 ? `Omborda: ${fmtQty(p.stock)}${boxOf(p) && p.stock >= boxOf(p) ? ` (~${Math.floor(p.stock / boxOf(p))} kar.)` : ""}` : p.alert_on ? "🔔 Kelganda xabar beramiz" : "Omborda yo'q"}</span>
        </span>
      </a>
      <div class="bottom">
        <div class="prices">${priceHtml(p, true)}</div>
        <span data-ctrl="${p.id}" data-v="1">${ctrl(p, true)}</span>
      </div>
    </div>`;
  const drawList = () => {
    const el = document.getElementById("list");
    if (!el) return;
    const emptyText = st.special === "fav" ? "Sevimlilar ro'yxati bo'sh. Tovar sahifasida ❤ ni bosing." : "Hech narsa topilmadi";
    el.innerHTML = st.items.length ? st.items.map(row).join("") : `<div class="empty">${icon("search")}<span>${emptyText}</span></div>`;
    document.getElementById("found").textContent = st.items.length ? `${st.items.length}${st.hasMore ? "+" : ""} ta tovar` : "";
    document.getElementById("more").innerHTML = st.hasMore ? `<button class="btn soft block" data-act="more">Yana ko'rsatish</button>` : "";
  };
  let reqId = 0;
  const load = async (append = false) => {
    const my = ++reqId;
    if (!append) { st.offset = 0; document.getElementById("list").innerHTML = '<div class="skeleton" style="height:92px"></div>'.repeat(4); }
    const qs = new URLSearchParams({ limit: "30", offset: String(append ? st.offset : 0) });
    if (st.q) qs.set("q", st.q);
    if (st.cat) qs.set("category", String(st.cat));
    if (st.group) qs.set("group", String(st.group));
    if (st.brand) qs.set("brand", st.brand);
    if (st.folder !== null) qs.set("folder", String(st.folder));
    if (st.inStock && !["fav", "promo"].includes(st.special)) qs.set("in_stock", "1");
    if (st.special === "fav") qs.set("fav", "1");
    if (st.special === "promo") qs.set("promo", "1");
    if (st.special === "cheaper") qs.set("cheaper", "1");
    if (st.special === "new") qs.set("sort", "new");
    else if (st.sort) qs.set("sort", st.sort);
    try {
      const r = await api(`/products?${qs}`);
      if (my !== reqId) return;
      remember(r.items);
      st.items = append ? [...st.items, ...r.items] : r.items;
      st.offset = r.next_offset; st.hasMore = r.has_more;
      if (!append) { st.fuzzy = !!r.fuzzy; st.dym = r.did_you_mean || []; }
      drawList(); drawDym();
    } catch (e) { fail(e); }
  };

  actions = {
    ...stepActions,
    cat: (el) => { st.cat = el.dataset.id ? Number(el.dataset.id) : null; st.special = ""; drawChips(); load(); },
    group: (el) => { st.group = el.dataset.id ? Number(el.dataset.id) : null; st.cat = null; st.brand = null; st.special = ""; drawChips(); loadTree(); load(); },
    special: (el) => { st.special = st.special === el.dataset.k ? "" : el.dataset.k; st.cat = null; st.group = null; st.brand = null; drawChips(); load(); },
    instock: (el) => { st.inStock = !st.inStock; el.setAttribute("aria-pressed", String(st.inStock)); loadTree(); load(); },
    pick: (el) => openPick(el.dataset.k),
    folder: (el) => { st.folder = el.dataset.id === "" ? null : Number(el.dataset.id); st.group = null; st.cat = null; st.brand = null; st.special = ""; loadTree(); load(); },
    pclose: () => document.getElementById("pick")?.remove(),
    pset: (el) => {
      const v = el.dataset.v;
      if (el.dataset.k === "cat") st.cat = v ? Number(v) : null; else st.brand = v || null;
      st.special = "";
      document.getElementById("pick")?.remove(); drawChips(); load();
    },
    fclear: () => { st.cat = null; st.brand = null; drawChips(); load(); },
    sort: () => { const i = SORTS.findIndex((x) => x[0] === (st.sort || "")); st.sort = SORTS[(i + 1) % SORTS.length][0]; drawChips(); load(); },
    sugg: (el) => {
      const { type, id, label } = el.dataset;
      const qi = document.getElementById("q");
      drawSugg([]); qi.blur();
      if (type === "query") { qi.value = label; st.q = label; }
      else {
        qi.value = ""; st.q = ""; st.special = "";
        if (type === "group") { st.group = Number(id); st.cat = null; st.brand = null; loadTree(); }
        if (type === "category") st.cat = Number(id);
        if (type === "brand") st.brand = id;
        drawChips();
      }
      load();
    },
    dym: (el) => { const qi = document.getElementById("q"); qi.value = el.dataset.w; st.q = el.dataset.w; load(); },
    more: () => load(true),
  };
  let t;
  const q = document.getElementById("q");
  q.addEventListener("input", () => { askSugg(q.value.trim()); clearTimeout(t); t = setTimeout(() => { st.q = q.value.trim(); load(); }, 350); });
  q.addEventListener("keydown", (e) => { if (e.key === "Enter") { drawSugg([]); q.blur(); } });
  q.addEventListener("blur", () => setTimeout(() => drawSugg([]), 200));
  if (params.get("focus") === "1") q.focus();

  drawChips();
  loadTree();
  load();
  refreshCtrls();
}

// ---------- Katalog: rasmli to'r (Telegram "Media" kabi) ----------
const MX_SPECIAL = { fav: "❤ Sevimlilar", promo: "🔥 Aksiya", cheaper: "📉 Arzonlashgan", new: "🆕 Yangi kelganlar" };
async function viewCatalogMedia(params) {
  currentTab = "katalog";
  const st = catalogState;
  const cfg = catalogCfg || { tabs: "folder" };
  // Havoladan kelgan filtrlar (bosh sahifa, bannerlar, bot)
  if (params.has("cat")) { st.cat = Number(params.get("cat")) || null; st.group = null; st.folder = null; st.special = ""; }
  if (params.has("group")) { st.group = Number(params.get("group")) || null; st.cat = null; st.folder = null; st.special = ""; }
  if (params.has("folder")) { const f = params.get("folder"); st.folder = f === "" ? null : Number(f); st.group = null; st.cat = null; st.special = ""; }
  if (params.has("brand")) { st.brand = params.get("brand") || null; st.special = ""; }
  if (params.has("q")) st.q = params.get("q");
  if (params.get("fav") === "1") st.special = "fav";
  if (params.get("promo") === "1") st.special = "promo";
  if (params.get("sort") === "new") st.special = "new";
  if (params.get("special") === "cheaper") st.special = "cheaper";
  const openSearch = !!st.q || params.get("focus") === "1";

  $app.innerHTML = `<div class="mx">
    <header class="mx-head">
      <div class="mx-top">
        <a class="mx-circle" href="#/skaner" aria-label="Shtrix-kodni skanerlash">${icon("scan")}</a>
        <div class="mx-title"><b>KIDDY TOYS</b><span id="mxcount">&nbsp;</span></div>
        <button class="mx-circle" data-act="mxsearch" aria-label="Qidirish" aria-expanded="${openSearch}">${icon("search")}</button>
      </div>
      <label class="mx-search" id="mxs" ${openSearch ? "" : "hidden"}>${icon("search")}<span class="sr-only">Qidirish</span>
        <input id="q" type="search" placeholder="Nomi, artikul yoki shtrix-kod" value="${esc(st.q)}" autocomplete="off" enterkeyhint="search">
        <button class="mx-x" data-act="mxclear" aria-label="Qidiruvni tozalash">${icon("close")}</button></label>
      <div class="mx-tabs" id="mxtabs" role="tablist" aria-label="Bo'limlar" hidden></div>
      <div id="mxspecial"></div>
    </header>
    <div class="mx-grid" id="list" aria-live="polite"></div>
    <div id="more" class="mx-more"></div>
  </div>
  <a id="floatbar" class="floatbar" href="#/savat" hidden></a>
  <div id="mxpv"></div>`;

  // --- tepadagi bo'limlar paneli ---
  const tabsOf = (t) => {
    if (!t || cfg.tabs === "none") return [];
    if (cfg.tabs === "group") return (t.groups || []).map((x) => ({ k: "group", id: x.id, name: x.name, n: x.n }));
    if (cfg.tabs === "category") return (t.categories || []).map((x) => ({ k: "cat", id: x.id, name: x.name, n: x.n }));
    return (t.folders || []).map((x) => ({ k: "folder", id: x.id, name: x.name, n: x.n }));
  };
  const activeKey = () => (st.folder !== null ? `folder:${st.folder}` : st.group ? `group:${st.group}` : st.cat ? `cat:${st.cat}` : "");
  const drawTabs = () => {
    const el = document.getElementById("mxtabs");
    if (!el) return;
    const tabs = tabsOf(st.rootTree);
    el.hidden = !tabs.length;
    const a = activeKey();
    el.innerHTML = tabs.length ? `<button class="mx-tab ${!a ? "on" : ""}" role="tab" aria-selected="${!a}" data-act="mxtab" data-k="" data-id="">Hammasi</button>` +
      tabs.map((x) => { const on = a === `${x.k}:${x.id}`; return `<button class="mx-tab ${on ? "on" : ""}" role="tab" aria-selected="${on}" data-act="mxtab" data-k="${x.k}" data-id="${x.id}">${esc(cap(x.name))}</button>`; }).join("") : "";
    el.querySelector(".mx-tab.on")?.scrollIntoView({ inline: "center", block: "nearest" });
    const sp = document.getElementById("mxspecial");
    if (sp) sp.innerHTML = st.special || st.brand
      ? `<div class="mx-filter">${st.special ? `<button class="chip on" data-act="mxunspecial">${MX_SPECIAL[st.special] || ""} ✕</button>` : ""}${st.brand ? `<button class="chip on" data-act="mxunbrand">🏷 ${esc(cap(st.brand))} ✕</button>` : ""}</div>` : "";
  };
  const drawCount = () => {
    const el = document.getElementById("mxcount");
    if (!el) return;
    if (st.q || st.special || st.brand) { el.textContent = st.items.length ? `${st.items.length}${st.hasMore ? "+" : ""} ta tovar topildi` : "Topilmadi"; return; }
    const a = activeKey();
    const tab = a && tabsOf(st.rootTree).find((x) => `${x.k}:${x.id}` === a);
    const total = st.rootTree?.total;
    el.textContent = tab ? `${fmt(tab.n)} ta tovar · ${cap(tab.name)}` : total != null ? `${fmt(total)} ta tovar` : "";
  };

  // --- rasmli katakchalar ---
  const badgeText = (p) => { const q = cart.qty(p.id); return q ? qtyText(q, boxOf(p), modeOf(p), true) : ""; };
  const tile = (p) => {
    const b = badgeText(p);
    return `<button class="mx-tile" data-act="pv" data-id="${p.id}" style="background:${tileFor(p.id)}" aria-label="${esc(p.name)}">
      ${p.photo_url ? `<img src="${esc(p.photo_url)}" alt="" loading="lazy" decoding="async">` : icon("box")}
      ${p.promo_label || p.drop_pct || p.is_new ? `<span class="mx-tag">${p.promo_label ? esc(p.promo_label) : p.drop_pct ? `−${p.drop_pct}%` : "Yangi"}</span>` : ""}
      <span class="mx-badge" data-badge="${p.id}" ${b ? "" : "hidden"}>${esc(b)}</span>
      <span class="mx-cap"><span class="n">${esc(p.name)}</span><span class="p">${p.price ? fmt(p.price) : "Narx yo'q"}</span>${boxOf(p) ? `<span class="b">${boxOf(p)} dona/krb</span>` : ""}</span>
    </button>`;
  };
  const drawList = () => {
    const el = document.getElementById("list");
    if (!el) return;
    const emptyText = st.special === "fav" ? "Sevimlilar ro'yxati bo'sh" : st.q ? `«${esc(st.q)}» bo'yicha hech narsa topilmadi` : "Bu bo'limda tovar yo'q";
    el.innerHTML = st.items.length ? st.items.map(tile).join("") : `<div class="empty mx-empty">${icon("search")}<span>${emptyText}</span>${st.dym.length ? `<span class="row wrap" style="justify-content:center">Balki: ${st.dym.map((w) => `<button class="chip" data-act="dym" data-w="${esc(w)}">${esc(w)}</button>`).join("")}</span>` : ""}</div>`;
    drawCount();
  };
  const updateBadges = () => {
    $app.querySelectorAll("[data-badge]").forEach((el) => {
      const p = products.get(el.dataset.badge);
      const b = p ? badgeText(p) : "";
      el.textContent = b; el.hidden = !b;
    });
  };
  cleanup.push(cart.onChange(updateBadges) || (() => {}));

  let reqId = 0, loading = false;
  const load = async (append = false) => {
    const my = ++reqId;
    loading = true;
    if (!append) { st.offset = 0; document.getElementById("list").innerHTML = '<span class="mx-sk"></span>'.repeat(12); }
    const qs = new URLSearchParams({ limit: "45", offset: String(append ? st.offset : 0) });
    if (st.q) qs.set("q", st.q);
    if (st.cat) qs.set("category", String(st.cat));
    if (st.group) qs.set("group", String(st.group));
    if (st.folder !== null) qs.set("folder", String(st.folder));
    if (st.brand) qs.set("brand", st.brand);
    if (!["fav", "promo"].includes(st.special)) qs.set("in_stock", "1");
    if (st.special === "fav") qs.set("fav", "1");
    if (st.special === "promo") qs.set("promo", "1");
    if (st.special === "cheaper") qs.set("cheaper", "1");
    if (st.special === "new") qs.set("sort", "new");
    try {
      const r = await api(`/products?${qs}`);
      if (my !== reqId) return;
      remember(r.items);
      if (append) {
        st.items = [...st.items, ...r.items];
        document.getElementById("list")?.insertAdjacentHTML("beforeend", r.items.map(tile).join(""));
        drawCount();
      } else {
        st.items = r.items; st.fuzzy = !!r.fuzzy; st.dym = r.did_you_mean || [];
      }
      st.offset = r.next_offset; st.hasMore = r.has_more;
      if (!append) { drawList(); window.scrollTo(0, 0); }
      const more = document.getElementById("more");
      if (more) more.innerHTML = st.hasMore ? '<span class="mx-sk"></span>'.repeat(3) : st.items.length ? `<span class="muted small">${st.fuzzy ? "O'xshash tovarlar ko'rsatildi" : "Hammasi shu"}</span>` : "";
    } catch (e) { fail(e); }
    finally { if (my === reqId) loading = false; }
  };
  // Pastga yetganda keyingi tovarlar o'zi yuklanadi
  const io = new IntersectionObserver((en) => { if (en.some((x) => x.isIntersecting) && st.hasMore && !loading) load(true); }, { rootMargin: "600px 0px" });
  io.observe(document.getElementById("more"));
  cleanup.push(() => io.disconnect());

  // --- kattalashgan ko'rinish: rasm + ma'lumot + son yozish ---
  let pv = null;
  const pvCalc = () => {
    const box = boxOf(pv.p), units = pv.mode === "box" && box ? pv.qty * box : pv.qty;
    return { box, units, sum: units * (pv.p.price || 0) };
  };
  const pvDraw = () => {
    const host = document.getElementById("mxpv");
    if (!host) return;
    if (!pv) { host.innerHTML = ""; document.body.classList.remove("mx-lock"); return; }
    const p = pv.p, { box, units, sum } = pvCalc();
    const inCart = cart.qty(p.id) > 0;
    const stock = p.stock > 0 ? `Omborda: ${fmtQty(p.stock)}${box && p.stock >= box ? ` (~${Math.floor(p.stock / box)} krb)` : ""}` : "Omborda yo'q";
    host.innerHTML = `<div class="mx-pv" role="dialog" aria-modal="true" aria-label="${esc(p.name)}">
      <button class="mx-pv-bg" data-act="pvclose" aria-label="Yopish"></button>
      <div class="mx-pv-box">
        <div class="mx-pv-img" style="background:${tileFor(p.id)}">
          ${p.photo_url ? `<img src="${esc(p.photo_url)}" alt="${esc(p.name)}">` : icon("box")}
          <button class="mx-pv-info" data-act="pvinfo" aria-label="Batafsil ma'lumot">i</button>
          <div class="mx-cap big">
            <span class="n">${esc(p.name)}</span>
            <span class="p">${p.price ? `${fmt(p.price)} so'm` : "Narx qo'yilmagan"}${p.price ? ` <small>/ ${esc(p.unit || "dona")}</small>` : ""}${p.promo_old_price || p.drop_from ? ` <s>${fmt(p.promo_old_price || p.drop_from)}</s>` : ""}</span>
            <span class="b">${[box ? `Karobkada ${box} ${esc(p.unit || "dona")}` : "", p.sku ? `Kod ${esc(p.sku)}` : "", stock].filter(Boolean).join(" · ")}</span>
          </div>
        </div>
        <div class="mx-pv-panel">
          ${p.can_order ? `
            ${box ? `<div class="unitseg big" role="group" aria-label="Birlik">
              <button class="${pv.mode === "box" ? "on" : ""}" data-act="pvmode" data-m="box" aria-pressed="${pv.mode === "box"}">Karobka</button>
              <button class="${pv.mode === "unit" ? "on" : ""}" data-act="pvmode" data-m="unit" aria-pressed="${pv.mode === "unit"}">Dona</button></div>` : ""}
            <div class="mx-qrow">
              <button class="mx-qb" data-act="pvdec" aria-label="Kamaytirish">−</button>
              <label class="mx-qin"><input id="pvq" type="text" inputmode="numeric" pattern="[0-9]*" value="${pv.qty}" aria-label="Buyurtma soni"><span>${pv.mode === "box" && box ? "karobka" : "dona"}</span></label>
              <button class="mx-qb plus" data-act="pvinc" aria-label="Ko'paytirish">+</button>
            </div>
            <span class="mx-calc" id="pvcalc">${pv.mode === "box" && box ? `${pv.qty} krb × ${box} = ${fmtQty(units)} dona` : `${fmtQty(units)} dona`}</span>
            <button class="btn block" data-act="pvadd" ${units ? "" : "disabled"}>${inCart ? "Savatni yangilash" : "Savatga qo'shish"}<span class="mx-sum" id="pvsum">${som(sum)}</span></button>
            ${inCart ? `<button class="mx-del" data-act="pvremove">Savatdan olib tashlash</button>` : ""}`
          : `<p class="muted" style="margin:0;text-align:center">Bu tovarga narx qo'yilmagan — buyurtma berib bo'lmaydi.</p>`}
        </div>
      </div></div>`;
    document.body.classList.add("mx-lock");
    const qi = document.getElementById("pvq");
    qi?.addEventListener("input", () => {
      pv.qty = Math.max(0, parseInt(qi.value.replace(/\D/g, ""), 10) || 0);
      const c = pvCalc();
      document.getElementById("pvcalc").textContent = pv.mode === "box" && c.box ? `${pv.qty} krb × ${c.box} = ${fmtQty(c.units)} dona` : `${fmtQty(c.units)} dona`;
      document.getElementById("pvsum").textContent = som(c.sum);
      host.querySelector('[data-act="pvadd"]').disabled = !c.units;
    });
    qi?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); actions.pvadd(); } });
  };
  const pvOpen = (p) => {
    const box = boxOf(p), q = cart.qty(p.id), m = modeOf(p);
    pv = { p, mode: m, qty: q ? (m === "box" && box ? Math.max(1, Math.round(q / box)) : q) : 1 };
    history.pushState({ mxpv: 1 }, "");
    pvDraw();
  };
  const pvClose = () => { if (pv) history.back(); };
  const onPop = () => { if (pv) { pv = null; pvDraw(); } };
  window.addEventListener("popstate", onPop);
  cleanup.push(() => { window.removeEventListener("popstate", onPop); document.body.classList.remove("mx-lock"); });

  const setTab = (k, id) => {
    st.folder = null; st.group = null; st.cat = null; st.special = ""; st.brand = null;
    if (k === "folder") st.folder = Number(id);
    if (k === "group") st.group = Number(id);
    if (k === "cat") st.cat = Number(id);
    drawTabs(); load();
  };

  actions = {
    ...stepActions,
    mxtab: (el) => setTab(el.dataset.k, el.dataset.id),
    mxunspecial: () => { st.special = ""; drawTabs(); load(); },
    mxunbrand: () => { st.brand = null; drawTabs(); load(); },
    mxsearch: (el) => {
      const box = document.getElementById("mxs");
      box.hidden = !box.hidden;
      el.setAttribute("aria-expanded", String(!box.hidden));
      if (!box.hidden) document.getElementById("q").focus();
      else if (st.q) { st.q = ""; document.getElementById("q").value = ""; load(); }
    },
    mxclear: () => { const qi = document.getElementById("q"); qi.value = ""; if (st.q) { st.q = ""; load(); } qi.focus(); },
    dym: (el) => { const qi = document.getElementById("q"); qi.value = el.dataset.w; st.q = el.dataset.w; load(); },
    pv: (el) => { const p = products.get(el.dataset.id); if (p) pvOpen(p); },
    pvclose: pvClose,
    pvinfo: () => { const id = pv.p.id; pv = null; pvDraw(); location.replace(`#/tovar/${id}`); },
    pvmode: (el) => {
      const box = boxOf(pv.p), m = el.dataset.m;
      if (m === pv.mode) return;
      // Birlik almashganda sonni saqlaymiz: 2 krb → 24 dona, 30 dona → 3 krb (yaxlitlab)
      pv.qty = m === "unit" ? pv.qty * box : Math.max(1, Math.round(pv.qty / box));
      pv.mode = m; uiMode.set(String(pv.p.id), m); pvDraw();
    },
    pvinc: () => { pv.qty += 1; pvDraw(); },
    pvdec: () => { pv.qty = Math.max(1, pv.qty - 1); pvDraw(); },
    pvadd: () => {
      if (!pv) return;
      const { units, box } = pvCalc();
      if (!units) return;
      cart.set(pv.p, units, pv.mode === "box" && box ? "box" : "unit");
      toast(`Savatda: ${pv.p.name} — ${qtyText(units, box, pv.mode, true)}`);
      pvClose();
    },
    pvremove: () => { cart.set(pv.p, 0, pv.mode); toast("Savatdan olib tashlandi"); pvClose(); },
  };

  let t;
  const q = document.getElementById("q");
  q.addEventListener("input", () => { clearTimeout(t); t = setTimeout(() => { st.q = q.value.trim(); load(); }, 350); });
  q.addEventListener("keydown", (e) => { if (e.key === "Enter") q.blur(); });
  if (params.get("focus") === "1") q.focus();

  drawTabs();
  load();
  refreshCtrls();
  // Bo'limlar soni va jami tovar sonini yangilab olamiz
  api("/catalog?in_stock=1").then((r) => { st.rootTree = r; if (r.cfg) catalogCfg = r.cfg; drawTabs(); drawCount(); }).catch(() => {});
}

// ---------- Skaner ----------
async function viewScanner() {
  currentTab = "";
  $app.innerHTML = `<div class="scanner">
    <video muted playsinline></video><div class="shade"></div>
    <div class="frame"><i></i><i></i><i></i><i></i><div class="laser"></div></div>
    <div class="bar">
      <button class="icon-btn" data-act="close" aria-label="Yopish">${icon("close")}</button>
      <b>Shtrix-kod skaneri</b>
      <button class="icon-btn" data-act="torch" aria-label="Chiroq">${icon("flash", 'style="color:var(--yellow)"')}</button>
    </div>
    <p class="hint" id="hint">Tovar qutisidagi shtrix-kodni ramka ichiga joylang</p>
    <div class="sheet" id="sheet">
      <form data-submit="manual" class="row">
        <label class="input-wrap grow" style="height:48px"><span class="sr-only">Kodni qo'lda kiritish</span>
          <input id="manual" inputmode="numeric" placeholder="Kodni qo'lda kiritish"></label>
        <button class="btn small" style="height:48px">Topish</button>
      </form>
      <div id="found"></div>
    </div>
  </div>`;
  const video = $app.querySelector("video");
  let scanner = null, torchOn = false, busy = false;

  const show = (p) => {
    remember([p]);
    document.getElementById("found").innerHTML = `
      <div class="row" style="color:var(--green);font-weight: 600;font-size:14px">${icon("check")} Tovar topildi</div>
      <div class="row">${ph(p, "")}<div class="grow" style="display:flex;flex-direction:column;gap:2px">
        <b>${esc(p.name)}</b><span class="meta">${p.sku ? "Kod: " + esc(p.sku) + " · " : ""}${p.stock > 0 ? "Omborda: " + fmtQty(p.stock) : "Omborda yo'q"}</span>
        <span class="price">${p.price ? som(p.price) : "Narx yo'q"}</span></div>
        <span data-ctrl="${p.id}" data-v="1">${ctrl(p, true)}</span></div>
      <a class="btn soft block" href="#/tovar/${p.id}">Batafsil</a>`;
    const ph0 = document.querySelector("#found .ph");
    if (ph0) { ph0.style.width = "64px"; ph0.style.height = "64px"; ph0.style.borderRadius = "14px"; }
  };
  const lookup = async (code) => {
    if (busy) return;
    busy = true;
    try {
      const r = await api(`/barcode/${encodeURIComponent(code)}`);
      const p = r.items[0];
      if (p.can_order) {
        // Ulgurji: karobkasi bor tovar skanerlansa 1 karobka qo'shiladi
        changeQty(p, 1);
        toast(`+1 ${modeOf(p) === "box" ? `karobka (${boxOf(p)} dona)` : "dona"} · ${p.name} — jami ${qtyText(cart.qty(p.id), boxOf(p), modeOf(p), true)}`);
      }
      show(p);
    } catch (e) {
      document.getElementById("found").innerHTML = `<div class="err">${esc(code)}: ${esc(e.message)}</div>`;
    }
    busy = false;
  };

  actions = {
    ...stepActions,
    close: () => history.length > 1 ? history.back() : (location.hash = "#/katalog"),
    torch: async () => { torchOn = !torchOn; if (!(await scanner?.torch(torchOn))) toast("Bu telefonda chiroqni yoqib bo'lmaydi"); },
    manual: () => { const v = document.getElementById("manual").value.trim(); if (v) lookup(v); },
  };

  if (isNativeApp()) {
    // Android ilovada — Google ML Kit skaneri ochiladi (o'zining to'liq ekranli oynasi bilan)
    $app.querySelector("video").remove();
    $app.querySelector(".frame").remove();
    $app.querySelector(".shade").remove();
    $app.querySelector('[data-act="torch"]').style.visibility = "hidden";
    const hint = document.getElementById("hint");
    hint.style.top = "30%";
    const sheet = document.getElementById("sheet");
    sheet.insertAdjacentHTML("afterbegin", `<button class="btn block" data-act="native">${icon("scan")} Skanerlash</button>`);
    const runNative = async () => {
      hint.textContent = "Kamera ochilmoqda…";
      try {
        const code = await scanNative((t) => (hint.textContent = t));
        hint.textContent = "Keyingi tovarni skanerlash uchun tugmani bosing";
        if (code) await lookup(code);
      } catch (e) {
        hint.textContent = `Skanerni ochib bo'lmadi: ${e?.message || e}. Kodni qo'lda kiriting.`;
      }
    };
    actions.native = runNative;
    runNative();
    return;
  }

  try {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Kamera mavjud emas");
    scanner = await startScanner(video, lookup);
    cleanup.push(() => scanner.stop());
  } catch (e) {
    document.getElementById("hint").textContent = e?.name === "NotAllowedError"
      ? "Kameraga ruxsat berilmadi. Brauzer sozlamalaridan ruxsat bering yoki kodni qo'lda kiriting."
      : `Kamerani ochib bo'lmadi (${e?.message || e}). Kodni qo'lda kiriting.`;
  }
}

// ---------- Tovar sahifasi ----------
async function viewProduct(id) {
  currentTab = "";
  $app.innerHTML = `<div class="page no-tabs"><div class="skeleton" style="height:320px;margin:-16px -20px 0"></div></div>`;
  let p;
  try { p = await api(`/products/${id}`); } catch (e) { fail(e); $app.innerHTML = `<div class="page"><div class="empty">${esc(e.message)}<a class="btn" href="#/katalog">Katalogga</a></div></div>`; return; }
  remember([p]);
  if (!homeInfo.loaded) { try { const h = await api("/home"); Object.assign(homeInfo, { min_order_sum: h.min_order_sum, default_mode: h.default_mode || "box", loaded: true }); } catch { /* */ } }
  const box = boxOf(p);
  const inCart = cart.qty(p.id);
  const st = { mode: modeOf(p), n: 0 };
  st.n = inCart ? (st.mode === "box" ? Math.max(1, Math.round(inCart / box)) : inCart) : 1;
  const photos = [p.photo_url, ...(p.photos || [])].filter((x, i, a) => x && a.indexOf(x) === i);
  const unit = esc(p.unit || "dona");
  const outOfStock = !(p.stock > 0);
  const units = () => st.n * (st.mode === "box" ? box : 1);

  const draw = () => {
    const qty = units();
    const stockBoxes = box && p.stock > 0 ? Math.floor(p.stock / box) : 0;
    $app.innerHTML = `<div class="page no-tabs">
      <div class="backbtn row" style="left:0;right:0;padding:0 20px;justify-content:space-between;max-width:560px;margin:0 auto">
        <a class="icon-btn" href="#/katalog" data-act="back" aria-label="Orqaga">${icon("back")}</a>${heartBtn(p)}</div>
      <div class="gallery" style="background:${tileFor(p.id)}">${photos.length ? photos.map((u) => `<img src="${esc(u)}" alt="">`).join("") : `<div class="ph" style="background:${tileFor(p.id)}">${icon("box")}</div>`}</div>
      <div class="row">
        <span class="tag ${outOfStock ? "no" : "ok"}">${outOfStock ? "Omborda yo'q" : `Omborda: ${fmtQty(p.stock)} ${unit}${stockBoxes ? ` (~${stockBoxes} kar.)` : ""}`}</span>
        ${p.promo_label ? `<span class="bdg promo">${esc(p.promo_label)}</span>` : ""}${p.is_new ? '<span class="bdg">Yangi</span>' : ""}
      </div>
      <div><h1 style="font-size:23px;line-height:1.2">${esc(p.name)}</h1>
        <span class="meta">${[p.sku && "Kod: " + esc(p.sku), p.barcodes?.[0] && "Shtrix-kod: " + esc(p.barcodes[0])].filter(Boolean).join(" · ")}</span></div>
      <div class="kv">
        <div><span>1 ${unit} narxi</span><b style="color:var(--primary)">${p.price ? som(p.price) : "—"}</b>${p.promo_old_price ? `<span class="old" style="margin:0">${som(p.promo_old_price)}</span>` : ""}${p.usd ? `<span class="usd">${usdFmt(p.usd)} · kurs ${fmt(p.price / p.usd)}</span>` : ""}</div>
        ${box ? `<div><span>1 karobka = ${box} ${unit}</span><b>${p.price ? som(p.price * box) : "—"}</b>${p.usd ? `<span class="usd">${usdFmt(p.usd * box)}</span>` : ""}</div>`
              : `<div><span>Kategoriya</span><b style="font-size:15px">${esc(p.category_name || "—")}</b></div>`}
      </div>
      ${outOfStock ? `<button class="btn ${p.alert_on ? "soft" : "dark"} block" data-act="alert">${icon("bell")} ${p.alert_on ? "Kelganda xabar beramiz ✓ (bekor qilish)" : "Kelganda xabar ber"}</button>
        <span class="meta" style="text-align:center">Tovar omborga kelishi bilan Telegram'ga xabar keladi</span>` : ""}
      ${p.can_order ? `
      <div class="card" style="display:flex;flex-direction:column;gap:12px;padding:16px">
        <div class="row between"><h2 style="font-size:16px">Miqdor${outOfStock ? " (oldindan buyurtma)" : ""}</h2>${box ? `<span class="meta">1 karobka = ${box} ${unit}</span>` : ""}</div>
        ${box ? `<div class="unitseg big" role="group" aria-label="Birlik">
          <button class="${st.mode === "box" ? "on" : ""}" data-act="pm" data-m="box" aria-pressed="${st.mode === "box"}">Karobka</button>
          <button class="${st.mode === "unit" ? "on" : ""}" data-act="pm" data-m="unit" aria-pressed="${st.mode === "unit"}">Dona</button></div>` : ""}
        <div class="bigstep">
          <button data-act="n" data-d="-1" aria-label="Kamaytirish">−</button>
          <label><input id="nq" inputmode="numeric" value="${st.n}" aria-label="Miqdor"><span>${st.mode === "box" ? "karobka" : unit}</span></label>
          <button class="plus" data-act="n" data-d="1" aria-label="Ko'paytirish">+</button>
        </div>
        <div class="chips" style="margin:0;padding:0">${[5, 10, 20, 50].map((k) => `<button class="chip" data-act="n" data-d="${k}" style="background:var(--bg)">+${k}</button>`).join("")}</div>
        ${box && st.mode === "box" ? `<div class="calc">${st.n} karobka × ${box} ${unit} = <b>${fmtQty(qty)} ${unit}</b></div>` : ""}
        ${!outOfStock && qty > p.stock ? `<div class="warnbox">Omborda ${fmtQty(p.stock)} ${unit} bor. Qolgani keyingi kelishda yuboriladi yoki menejer bog'lanadi.</div>` : ""}
      </div>` : `<div class="note warn">Bu tovarga hali narx qo'yilmagan — buyurtma berib bo'lmaydi.</div>`}
      ${p.comment ? `<p class="muted" style="margin:0;line-height:1.5">${esc(p.comment)}</p>` : ""}
    </div>
    ${p.can_order ? `<div class="sheet" style="flex-direction:row;align-items:center;gap:14px">
      <div style="display:flex;flex-direction:column"><span class="meta">${box && st.mode === "box" ? `${st.n} kar. · ${fmtQty(qty)} dona` : `${fmtQty(qty)} ${unit}`}</span><b style="font-size:20px">${som(qty * p.price)}</b></div>
      <button class="btn grow" data-act="put" ${qty ? "" : "disabled"}>${inCart ? "Savatni yangilash" : "Savatga qo'shish"}</button></div>` : ""}`;
    document.getElementById("nq")?.addEventListener("change", (e) => { st.n = Math.max(0, parseInt(String(e.target.value).replace(/\D/g, ""), 10) || 0); draw(); });
  };
  actions = {
    fav: (el) => toggleFav(p.id, el),
    back: () => (history.length > 1 ? history.back() : (location.hash = "#/katalog")),
    pm: (el) => {
      if (el.dataset.m === st.mode) return;
      const q = units();
      st.mode = el.dataset.m; uiMode.set(String(p.id), st.mode);
      st.n = st.mode === "box" ? Math.max(1, Math.round(q / box)) : q;  // jami miqdor saqlanadi
      draw();
    },
    n: (el) => { st.n = Math.max(0, st.n + Number(el.dataset.d)); draw(); },
    put: () => {
      cart.set(p, units(), st.mode);
      toast(`Savatga: ${qtyText(units(), box, st.mode)}`);
      history.length > 1 ? history.back() : (location.hash = "#/savat");
    },
    alert: async () => {
      const on = !p.alert_on;
      try {
        const r = await api("/alerts", { method: "POST", body: { product_id: p.id, on } });
        p.alert_on = on;
        toast(on ? (r.telegram_linked ? "Tovar kelganda Telegram'ga xabar beramiz" : "Belgilandi. Xabar olish uchun Telegram botni ulang") : "Bekor qilindi");
        draw();
      } catch (e) { fail(e); }
    },
  };
  draw();
}

// ---------- Savat ----------
// Savatdagi tovarlar bo'yicha ogohlantirishlar (qoldiq yetmasa va h.k.)
const cartWarn = new Map();

/** Savat ochilganda narx, qoldiq va karobka sonini serverdan yangilaydi */
async function refreshCart() {
  const items = cart.items();
  if (!items.length) return;
  let r;
  try { r = await api(`/products?ids=${items.map((i) => i.id).join(",")}`); } catch { return; }
  remember(r.items);
  const fresh = new Map(r.items.map((p) => [String(p.id), p]));
  const removed = [], changed = [];
  cartWarn.clear();
  for (const i of items) {
    const p = fresh.get(String(i.id));
    if (!p || !p.can_order) { removed.push(i.name); cart.set({ id: i.id }, 0); continue; }
    if (p.price !== i.price) changed.push(i.name);
    if (p.price !== i.price || (p.box_qty || null) !== (i.box_qty || null) || p.name !== i.name) cart.set(p, i.qty, i.mode);
    if (!(p.stock > 0)) cartWarn.set(String(i.id), "Omborda yo'q — menejer bog'lanadi");
    else if (i.qty > p.stock) cartWarn.set(String(i.id), `Omborda faqat ${fmtQty(p.stock)} dona${boxOf(p) ? (p.stock >= boxOf(p) ? ` (~${Math.floor(p.stock / boxOf(p))} kar.)` : " — 1 karobkadan kam") : ""}`);
  }
  const msg = [removed.length && `Sotuvdan chiqqani savatdan olindi: ${removed.join(", ")}`, changed.length && `Narx yangilandi: ${changed.join(", ")}`].filter(Boolean);
  if (msg.length) toast(msg.join(". "), !!removed.length);
  refreshCtrls();
}

function viewCart() {
  currentTab = "savat";
  refreshCart().then(() => { if (location.hash.startsWith("#/savat")) draw(); });
  if (!homeInfo.loaded) api("/home").then((h) => { Object.assign(homeInfo, { min_order_sum: h.min_order_sum, ledger_enabled: h.ledger_enabled, default_mode: h.default_mode || "box", loaded: true }); if (location.hash.startsWith("#/savat")) draw(); }).catch(() => {});
  const draw = () => {
    const items = cart.items();
    items.forEach((i) => { if (!products.has(String(i.id))) products.set(String(i.id), { ...i, can_order: true }); });
    if (!items.length) {
      $app.innerHTML = `<div class="page"><h1>Savat</h1><div class="empty">${icon("cart")}<span>Savat bo'sh</span>
        <a class="btn" href="#/katalog">Katalogni ochish</a></div></div>`;
      return;
    }
    $app.innerHTML = `<div class="page" style="padding-bottom:calc(330px + var(--safe-b))">
      <div class="row between"><h1>Savat</h1><button class="link" data-act="clear" style="color:var(--red)">Tozalash</button></div>
      <div class="plist">${items.map((i) => `
        <div class="prow2" id="line-${i.id}">
          <a class="top" href="#/tovar/${i.id}">${ph(i)}
            <span class="info"><span class="nm">${esc(i.name)}</span>
              <span class="meta">${fmt(i.price)} so'm/dona${i.box_qty > 1 ? ` · ${fmt(i.price * i.box_qty)} so'm/kar.` : ""}</span>
              ${cartWarn.get(String(i.id)) ? `<span class="stock-no">⚠ ${esc(cartWarn.get(String(i.id)))}</span>` : ""}</span>
          </a>
          <div class="bottom">
            <div class="prices"><span class="meta">Summa</span><span class="price">${som(i.price * i.qty)}</span></div>
            <span data-ctrl="${i.id}" data-v="1">${ctrl(products.get(String(i.id)), true)}</span>
          </div>
        </div>`).join("")}</div>
      <label class="card field"><span class="meta" style="font-weight: 600">Izoh (ixtiyoriy)</span>
        <textarea id="comment" class="input" maxlength="500" placeholder="Masalan: ertaga ertalab olib kelinglar" style="border:0;padding:0;min-height:44px"></textarea></label>
    </div>
    <div class="sheet" style="bottom:calc(76px + var(--safe-b));border-radius:24px 24px 0 0;padding-bottom:16px">
      <div class="sumrow"><span>Tovarlar</span><span>${items.length} xil · ${cart.boxes() ? `${cart.boxes()} karobka · ` : ""}${fmtQty(cart.count())} dona</span></div>
      <div class="sumrow total"><span>Buyurtma summasi</span><b>${som(cart.total())}</b></div>
      ${homeInfo.min_order_sum > cart.total() ? `<div class="warnbox">Minimal buyurtma — ${som(homeInfo.min_order_sum)}. Yana ${som(homeInfo.min_order_sum - cart.total())}lik tovar qo'shing.</div>` : ""}
      <div id="orderwarn"></div>
      <button class="btn block" data-act="order" ${homeInfo.min_order_sum > cart.total() ? "disabled" : ""}>Buyurtma berish</button>
      <span class="meta" style="text-align:center">Buyurtma menejerga boradi, tasdiqlangach Telegram'ga xabar keladi</span>
    </div>`;
    const saved = sessionStorage.getItem("kt_comment");
    if (saved) document.getElementById("comment").value = saved;
    document.getElementById("comment").addEventListener("input", (e) => sessionStorage.setItem("kt_comment", e.target.value));
  };
  const off = cart.onChange(draw);
  cleanup.push(off);
  actions = {
    ...stepActions,
    clear: () => { if (confirmTwice("Tozalash uchun yana bir marta bosing")) cart.clear(); },
    order: () => {
      // Ulgurji buyurtma katta summa — avval tasdiqlatamiz
      const items = cart.items();
      const comment = document.getElementById("comment")?.value.trim() || "";
      document.getElementById("confirm")?.remove();
      $app.insertAdjacentHTML("beforeend", `<div id="confirm"><div class="modal-bg" data-act="cancel"></div>
        <div class="sheet confirm" role="dialog" aria-modal="true" aria-labelledby="cft">
          <h2 id="cft" style="font-size:20px">Buyurtmani tasdiqlang</h2>
          <div class="clist">${items.map((i) => `<div class="sumrow"><span>${esc(i.name)}</span><span>${esc(qtyText(i.qty, i.box_qty, i.mode, true))}</span></div>`).join("")}</div>
          <div class="sumrow"><span>Jami</span><span>${items.length} xil · ${cart.boxes() ? `${cart.boxes()} kar. · ` : ""}${fmtQty(cart.count())} dona</span></div>
          ${comment ? `<div class="sumrow"><span>Izoh</span><span>${esc(comment)}</span></div>` : ""}
          <div class="sumrow total"><span>Summa</span><b>${som(cart.total())}</b></div>
          <button class="btn block" data-act="send">Tasdiqlash va yuborish</button>
          <button class="btn soft block" data-act="cancel">Orqaga</button>
        </div></div>`);
    },
    cancel: () => document.getElementById("confirm")?.remove(),
    send: async (el) => {
      el.disabled = true; el.textContent = "Yuborilmoqda…";
      try {
        const r = await api("/orders", {
          method: "POST",
          body: { items: cart.items().map((i) => ({ product_id: i.id, qty: i.qty, mode: i.mode || "unit" })), comment: document.getElementById("comment")?.value || "" },
        });
        off();
        document.getElementById("confirm")?.remove();
        cart.clear();
        sessionStorage.removeItem("kt_comment");
        location.hash = `#/tayyor/${r.id}?no=${r.no}&sum=${r.total}`;
      } catch (e) {
        if (e.code === "min_order" || e.code === "over_limit") {
          const w = document.getElementById("orderwarn");
          if (w) w.innerHTML = `<div class="warnbox">${esc(e.message)}${e.code === "over_limit" ? ' <a href="#/chat">Menejerga yozish →</a>' : ""}</div>`;
        } else if (e.code === "unavailable" && e.data?.product_ids) {
          e.data.product_ids.forEach((id) => { const p = products.get(String(id)); if (p) cart.set(p, 0); });
          toast("Ba'zi tovarlar sotuvda qolmagan — savatdan olib tashlandi. Qayta tekshiring.", true);
        } else fail(e);
        document.getElementById("confirm")?.remove();
      }
    },
  };
  draw();
}
let clearArmed = 0;
function confirmTwice(msg) {
  // Brauzer oynasi o'rniga: 3 soniya ichida ikki marta bosish
  if (Date.now() - clearArmed < 3000) { clearArmed = 0; return true; }
  clearArmed = Date.now();
  toast(msg);
  return false;
}

function viewDone(id, params) {
  currentTab = "";
  $app.innerHTML = `<div class="page no-tabs" style="min-height:100dvh;justify-content:center;text-align:center;align-items:center">
    <span style="width:88px;height:88px;border-radius:44px;background:var(--green-soft);display:flex;align-items:center;justify-content:center;color:var(--green)">${icon("check", 'style="width:44px;height:44px;stroke-width:3"')}</span>
    <h1>Buyurtma qabul qilindi!</h1>
    <p class="muted" style="margin:0;line-height:1.5">Buyurtma №${esc(params.get("no"))} · ${som(params.get("sum"))}<br>Menejer tasdiqlagach Telegram'ga xabar keladi.</p>
    <a class="btn block" href="#/buyurtma/${esc(id)}">Buyurtmani ko'rish</a>
    <a class="btn soft block" href="#/">Bosh sahifaga</a>
  </div>`;
  actions = {};
}

// ---------- Kabinet ----------
async function viewCabinet(params) {
  currentTab = "kabinet";
  const c = session.client || {};
  const tab = params.get("tab") || "orders";
  const tabs = [["orders", "Buyurtmalar"], ["stats", "Xaridlarim"], ["ledger", "Oldi-berdi"], ["complaints", "Murojaat"]];
  $app.innerHTML = `<div class="page">
    <div class="hello"><span style="width:48px;height:48px;border-radius:16px;background:var(--yellow);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight: 600">${esc((c.name || "?").replace(/[^\p{L}\p{N}]/gu, "")[0] || "?")}</span>
      <div class="who"><b>${esc(c.name)}</b><span class="muted small">${esc(c.phone || "")}</span></div>
      <a class="icon-btn" href="#/chat" aria-label="Menejer bilan chat">${icon("chat")}</a>
      <button class="icon-btn" data-act="logout" aria-label="Chiqish">${icon("out")}</button></div>
    <div class="seg" role="tablist">${tabs.map(([k, t]) => `<button role="tab" aria-selected="${tab === k}" class="${tab === k ? "on" : ""}" data-act="tab" data-k="${k}">${t}</button>`).join("")}</div>
    <div id="tabbody" class="plist">${'<div class="skeleton" style="height:96px"></div>'.repeat(3)}</div>
    ${apkOffer()}
  </div>`;
  actions = {
    tab: (el) => { location.hash = `#/kabinet?tab=${el.dataset.k}`; },
    logout: async () => {
      if (!confirmTwice("Chiqish uchun yana bir marta bosing")) return;
      try { await api("/auth/logout", { method: "POST" }); } catch { /* */ }
      session.clear(); cart.clear(); location.hash = "#/kirish";
    },
  };
  const body = () => document.getElementById("tabbody");
  try {
    if (tab === "orders") await tabOrders(body());
    else if (tab === "stats") await tabStats(body());
    else if (tab === "ledger") await tabLedger(body(), params);
    else await tabComplaints(body());
  } catch (e) {
    if (body()) body().innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

// Xaridlarim: oyma-oy xaridlar va eng ko'p olingan bo'limlar
const OY = ["yan", "fev", "mar", "apr", "may", "iyn", "iyl", "avg", "sen", "okt", "noy", "dek"];
const short = (n) => n >= 1e9 ? (n / 1e9).toFixed(1).replace(".0", "") + " mlrd" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(".0", "") + " mln" : n >= 1e3 ? Math.round(n / 1e3) + " ming" : fmt(n);
async function tabStats(el) {
  const r = await api("/my-stats");
  const useShip = r.months.some((m) => m.shipped > 0);
  const vals = r.months.map((m) => (useShip ? m.shipped : m.app_sum));
  const max = Math.max(1, ...vals);
  const cur = vals[vals.length - 1], prev = vals[vals.length - 2] || 0;
  const diff = prev ? Math.round(((cur - prev) / prev) * 100) : null;
  const gTotal = r.groups.reduce((a, g) => a + g.total, 0) || 1;
  el.innerHTML = `
    <div class="stat-tiles">
      <div class="stat-tile blue"><span class="stat-big">${short(cur)}</span><span>shu oy, so'm${diff !== null ? ` · <b class="${diff >= 0 ? "up" : "down"}">${diff >= 0 ? "▲" : "▼"} ${Math.abs(diff)}%</b>` : ""}</span></div>
      <div class="stat-tile green"><span class="stat-big">${r.totals.orders}</span><span>ilovadan buyurtma</span></div>
    </div>
    <div class="card">
      <div class="row between"><h2>Oyma-oy xaridlar</h2><span class="meta">${useShip ? "iBox bo'yicha" : "ilovadagi buyurtmalar"}</span></div>
      <div class="bars">${r.months.map((m, i) => {
        const v = vals[i], [y, mo] = m.month.split("-");
        return `<div class="bar-col" title="${fmt(v)} so'm"><span class="bar-v">${v ? short(v) : ""}</span>
          <span class="bar ${i === vals.length - 1 ? "now" : ""}" style="height:${Math.max(3, Math.round((v / max) * 120))}px"></span>
          <span class="bar-l">${OY[Number(mo) - 1]}</span></div>`;
      }).join("")}</div>
    </div>
    ${r.groups.length ? `<div class="card stack-sm"><h2>Ko'p oladigan bo'limlarim</h2>
      ${r.groups.map((g) => { const pct = Math.round((g.total / gTotal) * 100); return `<div class="gline"><div class="row between"><span>${esc(cap(g.name))}</span><span class="meta">${pct}%</span></div>
        <span class="gbar"><i style="width:${pct}%"></i></span></div>`; }).join("")}
      <span class="meta">So'nggi 6 oydagi ilova buyurtmalari bo'yicha</span></div>` : ""}
    <a class="btn soft block" href="#/katalog?special=cheaper">📉 Arzonlashgan tovarlarni ko'rish</a>`;
}

async function tabOrders(el) {
  const r = await api("/orders");
  const me = session.client || {};
  el.innerHTML = (r.items.length ? r.items.map((o) => `
    <a class="card" href="#/buyurtma/${o.id}" style="color:inherit;display:flex;flex-direction:column;gap:6px">
      <div class="row between"><b style="font-size:16px">Buyurtma №${o.no}</b><span class="ostatus ${esc(o.status)}">${esc(o.status_text)}</span></div>
      <span class="meta">${dateUz(o.created_at)} · ${o.lines} xil, ${fmtQty(o.units)} dona</span>
      <b style="font-size:17px">${som(o.total)}</b></a>`).join("")
    : `<div class="empty">Hali buyurtma yo'q<a class="btn" href="#/katalog">Katalogni ochish</a></div>`) +
    `<button class="toggle card" data-act="news" aria-pressed="${me.notify_news !== false}" style="justify-content:space-between;width:100%;color:var(--ink)">
       <span style="text-align:left">Yangi tovarlar haqida Telegram xabari</span><span class="sw"></span></button>`;
  actions.news = async (b) => {
    const on = b.getAttribute("aria-pressed") !== "true";
    b.setAttribute("aria-pressed", String(on));
    try { await api("/me/settings", { method: "POST", body: { notify_news: on } }); session.setClient({ ...session.client, notify_news: on }); toast(on ? "Yoqildi" : "O'chirildi"); }
    catch (e) { b.setAttribute("aria-pressed", String(!on)); fail(e); }
  };
}

// Oldi-berdi: davr tanlash, qoldiq, hujjatlar, akt-sverka
async function tabLedger(el, params) {
  const today = new Date(Date.now() + 5 * 3600_000);
  const ymd = (d) => d.toISOString().slice(0, 10);
  const monthStart = ymd(new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1)));
  const prevStart = ymd(new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() - 1, 1)));
  const prevEnd = ymd(new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 0)));
  const periods = { month: [monthStart, null, "Shu oy"], prev: [prevStart, prevEnd, "O'tgan oy"], q: [ymd(new Date(Date.now() - 90 * 86400_000)), null, "3 oy"], all: [null, null, "Hammasi"] };
  const pk = periods[params.get("p")] ? params.get("p") : "month";
  const [from, to] = periods[pk];
  const qs = new URLSearchParams(); if (from) qs.set("from", from); if (to) qs.set("to", to);
  let l;
  try { l = await api(`/ledger?${qs}`); }
  catch (e) { el.innerHTML = `<div class="empty">${icon("file")}<span>${esc(e.message)}</span></div>`; return; }
  const linked = (session.client || {}).telegram_linked;
  el.innerHTML = `
    <div class="debt-card">
      <span class="lbl">${l.advance > 0 ? "Sizning haqqingiz (avans)" : "Joriy qarzingiz"}</span>
      <span class="big">${som(l.advance > 0 ? l.advance : l.debt)}</span>${partsHtml(l.parts)}
      ${l.overdue > 0 ? `<span class="warn">⏰ Muddati o'tgan: ${som(l.overdue)}${l.overdue_since ? ` (${l.overdue_since.split("-").reverse().join(".")} dan)` : ""}</span>` : ""}
      ${(l.usd_used ? ["UZS", "USD"] : ["UZS"]).map((k) => { const c = l.period.cur[k]; const f = (n) => money(n, k); return `${l.usd_used ? `<span class="lbl" style="margin-top:4px">${k === "USD" ? "Dollarda" : "So'mda"}</span>` : ""}<div class="two"><div><span class="lbl">Davrda olindi</span><b>${f(c.debit)}</b></div><div><span class="lbl">Davrda to'landi</span><b>${f(c.credit)}</b></div></div>`; }).join("")}
    </div>
    <div class="chips" style="margin:0">${Object.entries(periods).map(([k, v]) => `<button class="chip ${k === pk ? "on" : ""}" data-act="period" data-k="${k}">${v[2]}</button>`).join("")}</div>
    <span class="meta">«+» — qarz oshdi (tovar olindi), «−» — qarz kamaydi (to'lov, qaytarish). Qoldiq — shu hujjatdan keyingi qarz${l.usd_used ? " (so'm va dollar alohida yuritiladi)" : ""}.</span>
    <div class="card">
      ${l.entries.length ? l.entries.map((e) => `<div class="lrow">
          <span class="sg ${e.amount > 0 ? "plus" : "minus"}" aria-hidden="true">${e.amount > 0 ? "+" : "−"}</span>
          <div class="grow" style="display:flex;flex-direction:column"><b style="font-size:14px">${esc(e.title)}${e.number ? " " + esc(e.number) : ""}</b>
            <span class="meta">${e.date.split("-").reverse().join(".")} · qoldiq ${money(e.balance, e.currency)}</span></div>
          <span class="${e.amount > 0 ? "amt-plus" : "amt-minus"}">${e.amount > 0 ? "+" : "−"}${money(Math.abs(e.amount), e.currency)}</span></div>`).join("")
        : `<div class="empty" style="padding:20px">Bu davrda hujjat yo'q</div>`}
      <div class="sumrow" style="padding-top:8px"><span>Davr boshida</span><span>${money(l.period.cur.UZS.opening, "UZS")}${l.usd_used ? ` · ${money(l.period.cur.USD.opening, "USD")}` : ""}</span></div>
    </div>
    <div class="card" style="display:flex;flex-direction:column;gap:10px">
      <b>📄 Akt-sverka (${periods[pk][2].toLowerCase()})</b>
      ${linked ? `<button class="btn block" data-act="akt" data-via="telegram">Telegram'ga PDF yuborish</button>` : ""}
      ${isNativeApp() ? "" : `<button class="btn ${linked ? "soft" : ""} block" data-act="akt" data-via="link">PDF'ni ochish</button>`}
    </div>`;
  actions.period = (b) => { location.hash = `#/kabinet?tab=ledger&p=${b.dataset.k}`; };
  actions.akt = async (b) => {
    const via = b.dataset.via;
    // iPhone Safari bloklamasligi uchun oynani darhol ochamiz
    const win = via === "link" ? window.open("", "_blank") : null;
    b.disabled = true;
    try {
      const r = await api("/ledger/akt", { method: "POST", body: { from, to, via } });
      if (via === "telegram") toast("Akt Telegram'ga yuborildi");
      else { const url = `${API_BASE}/${r.url}`; if (win) win.location.href = url; else location.href = url; }
    } catch (e) { win?.close(); fail(e); }
    b.disabled = false;
  };
}

async function tabComplaints(el) {
  const r = await api("/complaints");
  el.innerHTML = `<a class="btn block" href="#/murojaat">${icon("ret")} Qaytarish yoki shikoyat yuborish</a>` +
    (r.items.length ? r.items.map((c) => `<div class="card" style="display:flex;flex-direction:column;gap:6px">
      <div class="row between"><b>${c.kind === "return" ? "Qaytarish" : "Shikoyat"} #${c.id}</b><span class="ostatus ${c.status === "done" || c.status === "accepted" ? "delivered" : c.status === "rejected" ? "cancelled" : ""}">${esc(c.status_text)}</span></div>
      <span class="meta">${dateUz(c.created_at)}${c.order_no ? ` · buyurtma №${c.order_no}` : ""}${c.product_name ? ` · ${esc(c.product_name)}` : ""}${c.qty ? `, ${fmtQty(c.qty)} dona` : ""}</span>
      <span style="white-space:pre-wrap">${esc(c.reason)}</span>
      ${c.images.length ? `<div class="photos">${c.images.map((u) => `<div class="ph"><img src="${esc(fileUrl(u))}" alt=""></div>`).join("")}</div>` : ""}
      ${c.admin_note ? `<div class="note">Menejer: ${esc(c.admin_note)}</div>` : ""}</div>`).join("")
    : `<div class="empty">Murojaatlar yo'q</div>`);
}

async function viewOrder(id, params) {
  currentTab = "kabinet";
  $app.innerHTML = `<div class="page"><div class="skeleton" style="height:200px"></div></div>`;
  let o;
  try { o = await api(`/orders/${encodeURIComponent(id)}`); } catch (e) { fail(e); return; }
  o.items.forEach((i) => { if (!products.has(String(i.product_id))) products.set(String(i.product_id), { id: i.product_id, name: i.name, price: i.price, photo_url: i.photo_url, unit: i.unit, box_qty: i.current_box_qty ?? i.box_qty, can_order: true }); });
  $app.innerHTML = `<div class="page">
    <div class="row"><a class="icon-btn" href="#/kabinet" aria-label="Orqaga">${icon("back")}</a><h1 class="grow">Buyurtma №${o.no}</h1></div>
    <div class="card" style="display:flex;flex-direction:column;gap:8px">
      <div class="row between"><span class="meta">${dateUz(o.created_at)}</span><span class="ostatus ${esc(o.status)}">${esc(o.status_text)}</span></div>
      ${o.comment ? `<span class="meta">Izoh: ${esc(o.comment)}</span>` : ""}
      <div class="sumrow total"><span>Summa</span><b>${som(o.total)}</b></div>
    </div>
    <div class="plist">${o.items.map((i) => `
      <div class="prow">${ph({ id: i.product_id, photo_url: i.photo_url })}
        <div class="info"><span class="nm" style="font-size:14px">${esc(i.name)}</span>
          <span class="meta">${qtyText(i.qty, i.box_qty, i.mode)} × ${fmt(i.price)}</span><span class="price">${som(i.total)}</span></div></div>`).join("")}</div>
    <button class="btn soft block" data-act="repeat">Shu buyurtmani takrorlash</button>
    <a class="btn soft block" href="#/murojaat?order=${o.id}" style="background:var(--red-soft);color:var(--red)">${icon("ret")} Qaytarish yoki shikoyat</a>
  </div>`;
  actions = {
    repeat: () => {
      o.items.forEach((i) => {
        const p = products.get(String(i.product_id));
        // Karobka soni o'zgargan bo'lsa ham, mijoz tanlagan birlikni saqlaymiz
        if (p) { if (i.current_box_qty) p.box_qty = i.current_box_qty; cart.add(p, i.qty, i.mode); }
      });
      toast("Tovarlar savatga qo'shildi");
      location.hash = "#/savat";
    },
  };
  if (params?.get("repeat") === "1") actions.repeat();
}

// ---------- Chat ----------
async function viewChat() {
  currentTab = "";
  $app.innerHTML = `<div class="page no-tabs" style="padding-bottom:calc(90px + var(--safe-b))">
    <div class="row"><a class="icon-btn" href="#/" data-act="back" aria-label="Orqaga">${icon("back")}</a>
      <div class="grow"><h1 style="font-size:20px">Menejer bilan chat</h1><span class="meta">Odatda ish vaqtida tez javob beramiz</span></div></div>
    <div class="chatbox" id="msgs"><div class="skeleton" style="height:60px"></div></div>
  </div>
  <form class="composer" data-submit="send">
    <label class="icon-btn" style="background:var(--bg);cursor:pointer" aria-label="Rasm biriktirish">${icon("cam")}<input type="file" id="pic" accept="image/*" hidden></label>
    <textarea id="txt" rows="1" placeholder="Xabar yozing…" maxlength="2000"></textarea>
    <button class="icon-btn primary" aria-label="Yuborish"><svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12 20 4l-6 16-3-7z"/></svg></button>
  </form>`;
  let lastId = 0;
  const draw = (items, append) => {
    const el = document.getElementById("msgs");
    if (!el) return;
    const html = items.map((m) => `<div class="bubble ${m.direction}"><div class="tx">${esc(m.text || "")}</div>${m.image_url ? `<img src="${esc(fileUrl(m.image_url))}" alt="Rasm">` : ""}<div class="t">${m.direction === "out" ? esc(m.author || "Menejer") + " · " : ""}${dateUz(m.created_at)}</div></div>`).join("");
    if (append) el.insertAdjacentHTML("beforeend", html);
    else el.innerHTML = html || `<div class="empty">Savolingiz bormi? Shu yerga yozing — menejer javob beradi.<br>Rasm ham yuborishingiz mumkin.</div>`;
    if (items.length) lastId = items[items.length - 1].id;
    window.scrollTo(0, document.body.scrollHeight);
  };
  const load = async (append = false) => {
    try {
      const r = await api(`/messages${append ? "?after=" + lastId : ""}`);
      if (append && !r.items.length) return;
      if (append && document.querySelector("#msgs .empty")) document.getElementById("msgs").innerHTML = "";
      draw(r.items, append);
    } catch (e) { if (!append) fail(e); }
  };
  const send = async (payload) => {
    try { await api("/messages", { method: "POST", body: payload }); await load(true); }
    catch (e) { fail(e); }
  };
  actions = {
    back: () => (history.length > 1 ? history.back() : (location.hash = "#/")),
    send: async () => {
      const t = document.getElementById("txt"); const text = t.value.trim();
      if (!text) return;
      t.value = ""; t.style.height = "";
      await send({ text });
    },
  };
  const t = document.getElementById("txt");
  t.addEventListener("input", () => { t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 120) + "px"; });
  document.getElementById("pic").addEventListener("change", async (e) => {
    const f = e.target.files?.[0]; e.target.value = "";
    if (!f) return;
    try { toast("Rasm yuborilmoqda…"); await send({ image: await readImage(f), text: document.getElementById("txt").value.trim() }); document.getElementById("txt").value = ""; }
    catch (err) { fail(err); }
  });
  await load();
  const timer = setInterval(() => load(true), 8000);
  cleanup.push(() => clearInterval(timer));
}

// ---------- Qaytarish / shikoyat ----------
async function viewComplaintForm(params) {
  currentTab = "";
  const orderId = params.get("order");
  let order = null;
  if (orderId) { try { order = await api(`/orders/${encodeURIComponent(orderId)}`); } catch { /* */ } }
  const st = { kind: "return", images: [] };
  const draw = () => {
    $app.innerHTML = `<div class="page no-tabs">
      <div class="row"><a class="icon-btn" href="#/kabinet?tab=complaints" data-act="back" aria-label="Orqaga">${icon("back")}</a><h1 class="grow" style="font-size:21px">Qaytarish / shikoyat</h1></div>
      <form data-submit="submit" class="card" style="display:flex;flex-direction:column;gap:14px">
        <div class="seg">${[["return", "Tovarni qaytarish"], ["complaint", "Shikoyat"]].map(([k, t]) => `<button type="button" class="${st.kind === k ? "on" : ""}" data-act="kind" data-k="${k}">${t}</button>`).join("")}</div>
        ${order ? `<label class="field"><span>Buyurtma №${order.no} dagi tovar</span>
          <select class="input" id="prod"><option value="">— umumiy —</option>${order.items.map((i) => `<option value="${i.product_id}">${esc(i.name)} (${fmtQty(i.qty)} dona)</option>`).join("")}</select></label>`
          : `<span class="meta">Muayyan buyurtma bo'yicha bo'lsa, Kabinet → Buyurtmalar → buyurtmani ochib, shu tugmani bosing.</span>`}
        ${st.kind === "return" ? `<label class="field"><span>Necha dona</span><input class="input" id="qty" inputmode="numeric" placeholder="masalan 2"></label>` : ""}
        <label class="field"><span>Sababi</span><textarea class="input" id="reason" rows="4" maxlength="2000" required placeholder="${st.kind === "return" ? "Masalan: qutisi ezilgan, ishlamaydi, noto'g'ri tovar keldi" : "Muammoni yozing"}"></textarea></label>
        <div class="field"><span>Rasmlar (4 tagacha)</span>
          <div class="photos">${st.images.map((src, i) => `<div class="ph rel"><img src="${src}" alt=""><button type="button" class="x" data-act="rm" data-i="${i}" aria-label="Rasmni olib tashlash">×</button></div>`).join("")}
          ${st.images.length < 4 ? `<label aria-label="Rasm qo'shish">${icon("cam")}<input type="file" id="pics" accept="image/*" multiple hidden></label>` : ""}</div></div>
        <button class="btn block" id="sendbtn">Yuborish</button>
      </form></div>`;
    document.getElementById("pics")?.addEventListener("change", async (e) => {
      const keep = { reason: document.getElementById("reason").value, qty: document.getElementById("qty")?.value, prod: document.getElementById("prod")?.value };
      for (const f of [...e.target.files].slice(0, 4 - st.images.length)) { try { st.images.push(await readImage(f, 1280)); } catch (err) { fail(err); } }
      draw();
      document.getElementById("reason").value = keep.reason;
      if (keep.qty && document.getElementById("qty")) document.getElementById("qty").value = keep.qty;
      if (keep.prod && document.getElementById("prod")) document.getElementById("prod").value = keep.prod;
    });
  };
  actions = {
    back: () => (history.length > 1 ? history.back() : (location.hash = "#/kabinet?tab=complaints")),
    kind: (el) => { st.kind = el.dataset.k; draw(); },
    rm: (el) => { st.images.splice(Number(el.dataset.i), 1); draw(); },
    submit: async () => {
      const b = document.getElementById("sendbtn");
      b.disabled = true; b.textContent = "Yuborilmoqda…";
      try {
        await api("/complaints", { method: "POST", body: {
          kind: st.kind, order_id: order?.id ?? null, product_id: document.getElementById("prod")?.value || null,
          qty: document.getElementById("qty")?.value || null, reason: document.getElementById("reason").value, images: st.images,
        } });
        toast("Yuborildi. Menejer ko'rib chiqib javob beradi");
        location.hash = "#/kabinet?tab=complaints";
      } catch (e) { fail(e); b.disabled = false; b.textContent = "Yuborish"; }
    },
  };
  draw();
}

// ---------- Marshrutlash ----------
async function router() {
  cleanup.forEach((f) => { try { f(); } catch { /* */ } });
  cleanup = [];
  actions = {};
  const raw = location.hash.slice(1) || "/";
  const [path, qs] = raw.split("?");
  const params = new URLSearchParams(qs || "");

  if (!session.token && path !== "/kirish") { location.hash = "#/kirish"; return; }
  if (session.token && path === "/kirish") { location.hash = "#/"; return; }

  let m;
  if (path === "/kirish") viewLogin();
  else if (path === "/") await viewHome();
  else if (path === "/katalog") await viewCatalog(params);
  else if (path === "/skaner") await viewScanner();
  else if ((m = path.match(/^\/tovar\/(\d+)$/))) await viewProduct(m[1]);
  else if (path === "/savat") viewCart();
  else if ((m = path.match(/^\/tayyor\/(.+)$/))) viewDone(m[1], params);
  else if (path === "/kabinet") await viewCabinet(params);
  else if ((m = path.match(/^\/buyurtma\/(.+)$/))) await viewOrder(m[1], params);
  else if (path === "/royxat") viewListOrder();
  else if (path === "/chat") await viewChat();
  else if (path === "/murojaat") await viewComplaintForm(params);
  else if (path === "/yangiliklar") await viewPosts();
  else if ((m = path.match(/^\/yangilik\/(\d+)$/))) await viewPost(m[1]);
  else { location.hash = "#/"; return; }
  renderTabbar();
  if (!path.startsWith("/tovar") && path !== "/chat") window.scrollTo(0, 0);
}

// Telegram ichida ochilganda: to'liq ekran, rang, orqaga tugmasi
const TG = window.Telegram?.WebApp;
if (TG?.initData) {
  try {
    TG.ready(); TG.expand();
    TG.setHeaderColor?.("#F4F6FB"); TG.setBackgroundColor?.("#F4F6FB");
    document.documentElement.classList.add("in-tg");
    TG.BackButton?.onClick(() => history.back());
    window.addEventListener("hashchange", () => {
      const root = ["", "#/", "#/katalog", "#/savat", "#/kabinet", "#/kirish"].includes(location.hash.split("?")[0]);
      root ? TG.BackButton?.hide() : TG.BackButton?.show();
    });
  } catch { /* */ }
}

window.addEventListener("hashchange", router);
window.addEventListener("offline", () => toast("Internet aloqasi uzildi. Savat saqlanib turadi.", true));
window.addEventListener("online", () => toast("Internet qaytdi"));
router();

if ("serviceWorker" in navigator && location.protocol === "https:") {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
