// Kamera orqali shtrix-kod o'qish.
// Android Chrome'da brauzerning o'zidagi BarcodeDetector ishlatiladi (tez),
// iPhone va boshqalarda ZXing kutubxonasi yuklanadi.
const FORMATS = ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "itf", "qr_code"];
const ZXING_URL = "https://unpkg.com/@zxing/browser@0.1.5/umd/zxing-browser.min.js";

/** Android ilova (Capacitor) ichida ochilganmi */
export function isNativeApp() {
  return !!window.Capacitor?.isNativePlatform?.();
}

function nativeScanner() {
  const C = window.Capacitor;
  return C.registerPlugin ? C.registerPlugin("BarcodeScanner") : C.Plugins?.BarcodeScanner;
}

/**
 * Android ilovada: Google ML Kit skaneri (to'liq ekranli, tez va aniq).
 * Qaytaradi: o'qilgan kod yoki null (bekor qilinsa).
 */
export async function scanNative(onStatus = () => {}) {
  const BS = nativeScanner();
  if (!BS) throw new Error("Skaner plagini topilmadi");
  const { available } = await BS.isGoogleBarcodeScannerModuleAvailable().catch(() => ({ available: true }));
  if (!available) {
    onStatus("Skaner birinchi marta o'rnatilmoqda, biroz kuting…");
    await new Promise((resolve, reject) => {
      let handle;
      const t = setTimeout(() => { handle?.remove?.(); reject(new Error("Skaner moduli yuklanmadi. Internetni tekshiring.")); }, 60000);
      BS.addListener("googleBarcodeScannerModuleInstallProgress", (e) => {
        if (e.state === 4) { clearTimeout(t); handle?.remove?.(); resolve(); } // 4 = COMPLETED
        if (e.state === 5 || e.state === 3) { clearTimeout(t); handle?.remove?.(); reject(new Error("Skaner moduli o'rnatilmadi")); } // 5 = FAILED, 3 = CANCELED
      }).then((h) => (handle = h));
      BS.installGoogleBarcodeScannerModule().catch(reject);
    });
  }
  try {
    const { barcodes } = await BS.scan();
    return barcodes?.[0]?.rawValue ?? null;
  } catch (e) {
    if (/cancel/i.test(String(e?.message ?? e))) return null;
    throw e;
  }
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src; s.async = true; s.onload = resolve; s.onerror = () => reject(new Error("Skaner kutubxonasi yuklanmadi"));
    document.head.appendChild(s);
  });
}

/**
 * video elementida skanerni boshlaydi. onCode(kod) har bir yangi kod uchun chaqiriladi.
 * Qaytaradi: { stop(), torch(on) }
 */
export async function startScanner(video, onCode) {
  let stopped = false, stream = null, zxControls = null, last = "", lastAt = 0;
  const emit = (code) => {
    const now = Date.now();
    if (!code || (code === last && now - lastAt < 2500)) return; // bir xil kodni ketma-ket takrorlamaymiz
    last = code; lastAt = now;
    if (navigator.vibrate) navigator.vibrate(60);
    onCode(code);
  };

  const constraints = { video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false };

  let native = false;
  if ("BarcodeDetector" in window) {
    try {
      const supported = await window.BarcodeDetector.getSupportedFormats();
      native = FORMATS.some((f) => supported.includes(f));
    } catch { native = false; }
  }

  if (native) {
    stream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = stream;
    video.setAttribute("playsinline", "");
    await video.play();
    const supported = await window.BarcodeDetector.getSupportedFormats();
    const detector = new window.BarcodeDetector({ formats: FORMATS.filter((f) => supported.includes(f)) });
    const tick = async () => {
      if (stopped) return;
      try {
        if (video.readyState >= 2) {
          const codes = await detector.detect(video);
          if (codes.length) emit(codes[0].rawValue);
        }
      } catch { /* kadr tayyor emas */ }
      setTimeout(tick, 180);
    };
    tick();
  } else {
    if (!window.ZXingBrowser) await loadScript(ZXING_URL);
    const reader = new window.ZXingBrowser.BrowserMultiFormatReader();
    zxControls = await reader.decodeFromConstraints(constraints, video, (result) => {
      if (result && !stopped) emit(result.getText());
    });
    stream = video.srcObject;
  }

  return {
    stop() {
      stopped = true;
      try { zxControls?.stop(); } catch { /* */ }
      stream?.getTracks?.().forEach((t) => t.stop());
      video.srcObject = null;
    },
    async torch(on) {
      const track = stream?.getVideoTracks?.()[0];
      if (!track?.getCapabilities?.().torch) return false;
      await track.applyConstraints({ advanced: [{ torch: !!on }] });
      return true;
    },
  };
}
