// Server bilan aloqa va mahalliy saqlash (sessiya, savat)
const CFG = window.KIDDY_CONFIG || {};
const API = (CFG.API_URL || "").replace(/\/+$/, "");

const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* xotira to'la */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* */ } },
};

export const session = {
  get token() { return LS.get("kt_token", null); },
  get client() { return LS.get("kt_client", null); },
  save(token, client) { LS.set("kt_token", token); LS.set("kt_client", client); },
  setClient(client) { LS.set("kt_client", client); },
  clear() { LS.del("kt_token"); LS.del("kt_client"); },
};

export class ApiError extends Error {
  constructor(status, code, message, data) { super(message); this.status = status; this.code = code; this.data = data; }
}

export async function api(path, { method = "GET", body } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (session.token) headers["Authorization"] = `Bearer ${session.token}`;
  let res;
  try {
    res = await fetch(API + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, "offline", "Internet aloqasi yo'q. Qayta urinib ko'ring.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && data.error === "no_session") {
      session.clear();
      location.hash = "#/kirish";
    }
    throw new ApiError(res.status, data.error || "error", data.message || "Xatolik yuz berdi", data);
  }
  return data;
}

// ---------- Savat ----------
// Qator: { id, name, price, photo_url, box_qty, unit, qty, mode }
//   qty  — har doim DONA hisobida (iBox'ga shunday yuboriladi)
//   mode — mijoz tanlagan birlik: "box" (karobka) yoki "unit" (dona)
const listeners = new Set();
const boxOf = (p) => (p && p.box_qty > 1 ? Number(p.box_qty) : 0);
export const cart = {
  all() { return LS.get("kt_cart", {}); },
  items() { return Object.values(this.all()); },
  line(id) { return this.all()[id] || null; },
  qty(id) { return this.all()[id]?.qty || 0; },
  mode(id) { return this.all()[id]?.mode || null; },
  count() { return this.items().reduce((s, i) => s + i.qty, 0); },
  boxes() { return this.items().reduce((s, i) => s + (i.mode === "box" && i.box_qty > 1 ? Math.floor(i.qty / i.box_qty) : 0), 0); },
  total() { return this.items().reduce((s, i) => s + i.qty * (i.price || 0), 0); },
  set(product, qty, mode) {
    const all = this.all();
    qty = Math.max(0, Math.round(Number(qty) || 0));
    const prev = all[product.id];
    const box = boxOf(product) || boxOf(prev);
    const m = box ? (mode || prev?.mode || "box") : "unit";
    if (qty === 0) delete all[product.id];
    else all[product.id] = {
      id: product.id, name: product.name ?? prev?.name, price: product.price ?? prev?.price, photo_url: product.photo_url ?? prev?.photo_url,
      box_qty: box || null, unit: product.unit ?? prev?.unit, qty, mode: m,
    };
    LS.set("kt_cart", all);
    listeners.forEach((f) => f());
  },
  add(product, delta, mode) { this.set(product, this.qty(product.id) + delta, mode); },
  setMode(product, mode) { const l = this.line(product.id); if (l) this.set(product, l.qty, mode); },
  clear() { LS.set("kt_cart", {}); listeners.forEach((f) => f()); },
  onChange(f) { listeners.add(f); return () => listeners.delete(f); },
};
