// Kiddy Toys admin panel
const CFG = window.KIDDY_CONFIG || {};
const API = (CFG.API_URL || "").replace(/\/+$/, "");
const ADMIN = API.replace(/\/api$/, "/admin");
const fileUrl = (rel) => (rel ? `${API}/${rel}` : "");

const $root = document.getElementById("root");
const $toast = document.getElementById("toast");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => (n == null || n === "" ? "—" : Math.round(Number(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " "));
const dt = (iso) => { if (!iso) return "—"; const d = new Date(iso); return d.toLocaleDateString("ru-RU") + " " + d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }); };
// datetime-local maydon uchun mahalliy vaqt
const toLocalInput = (iso) => { if (!iso) return ""; const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };
const ago = (iso) => {
  if (!iso) return "hech qachon";
  const m = Math.round((Date.now() - new Date(iso)) / 60000);
  if (m < 2) return "hozir"; if (m < 60) return `${m} daq oldin`;
  const h = Math.round(m / 60); if (h < 24) return `${h} soat oldin`;
  return `${Math.round(h / 24)} kun oldin`;
};
let toastT;
const toast = (t, bad = false) => { $toast.textContent = t; $toast.className = "toast" + (bad ? " bad" : ""); $toast.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => ($toast.hidden = true), 2800); };

const store = {
  get token() { try { return JSON.parse(localStorage.getItem("kt_admin_token")); } catch { return null; } },
  set token(v) { v ? localStorage.setItem("kt_admin_token", JSON.stringify(v)) : localStorage.removeItem("kt_admin_token"); },
  get name() { return localStorage.getItem("kt_admin_name") || ""; },
  set name(v) { localStorage.setItem("kt_admin_name", v || ""); },
};

async function api(path, { method = "GET", body } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (store.token) headers.Authorization = `Bearer ${store.token}`;
  let res;
  try { res = await fetch(ADMIN + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }); }
  catch { throw new Error("Internet aloqasi yo'q"); }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { store.token = null; render(); throw new Error(data.message || "Qayta kiring"); }
  if (!res.ok) throw Object.assign(new Error(data.message || "Xatolik"), { data });
  return data;
}
const fail = (e) => toast(e.message || "Xatolik", true);

/** Rasmni brauzerda kichraytirib, data URL qilib qaytaradi */
function readImage(file, max = 1280) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => reject(new Error("Rasmni o'qib bo'lmadi"));
    img.src = URL.createObjectURL(file);
  });
}

// ---------- hodisalar ----------
let actions = {};
$root.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (el && actions[el.dataset.act]) { e.preventDefault(); actions[el.dataset.act](el, e); }
});
$root.addEventListener("submit", (e) => {
  const fn = actions[e.target.dataset.submit];
  if (fn) { e.preventDefault(); fn(e.target, new FormData(e.target)); }
});
let armed = { key: "", at: 0 };
const twice = (key, msg) => { if (armed.key === key && Date.now() - armed.at < 3000) { armed = { key: "", at: 0 }; return true; } armed = { key, at: Date.now() }; toast(msg); return false; };

// ---------- kirish ----------
function viewLogin() {
  const st = { step: "phone", phone: "", err: "", dev: "" };
  const draw = () => {
    $root.innerHTML = `<div class="login"><form class="card" data-submit="${st.step}">
      <div class="row"><img src="../icons/logo.svg" width="44" height="44" alt=""><div><h1 style="font-size:20px">Kiddy Toys</h1><span class="muted">Admin panel</span></div></div>
      ${st.step === "phone" ? `
        <label class="f">Telefon raqam<input class="input" name="phone" inputmode="tel" placeholder="90 123 45 67" value="${esc(st.phone)}" required autofocus></label>
        <span class="muted small">Kod Telegram botga keladi. Raqamingiz adminlar ro'yxatida bo'lishi va botga ulangan bo'lishi kerak.</span>
        <button class="btn">Kod olish</button>`
      : `<label class="f">Telegram'ga kelgan 6 xonali kod<input class="input" name="code" inputmode="numeric" maxlength="6" required autofocus style="letter-spacing:8px;font-size:20px;text-align:center"></label>
        ${st.dev ? `<span class="pill amber">Sinov rejimi: ${esc(st.dev)}</span>` : ""}
        <button class="btn">Kirish</button><button type="button" class="btn soft" data-act="back">Raqamni o'zgartirish</button>`}
      ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
    </form></div>`;
  };
  actions = {
    phone: async (f, d) => { st.phone = d.get("phone"); st.err = ""; try { const r = await api("/auth/request", { method: "POST", body: { phone: st.phone } }); st.dev = r.dev_code || ""; st.step = "code"; } catch (e) { st.err = e.message; } draw(); },
    code: async (f, d) => { try { const r = await api("/auth/verify", { method: "POST", body: { phone: st.phone, code: d.get("code") } }); store.token = r.token; store.name = r.admin.name; location.hash = "#/"; render(); } catch (e) { st.err = e.message; draw(); } },
    back: () => { st.step = "phone"; draw(); },
  };
  draw();
}

// ---------- karkas ----------
const NAV = [
  ["/", "Bosh sahifa", "home"], ["/buyurtmalar", "Buyurtmalar", "bag"], ["/mijozlar", "Mijozlar", "users"], ["/tovarlar", "Tovarlar", "box"],
  ["/yangiliklar", "Yangiliklar", "news"], ["/bannerlar", "Bannerlar", "image"], ["/shikoyatlar", "Qaytarish / shikoyat", "alert"],
  ["/chat", "Chat", "chat"], ["/bolimlar", "Katalog bo'limlari", "grid"], ["/qidiruv", "Qidiruv va sinonimlar", "search"],
  ["/xabar", "Xabar yuborish", "send"], ["/sozlamalar", "Sozlamalar", "gear"],
];
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  bag: '<path d="M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.5 3.3-5.5 6.5-5.5s5.9 2 6.5 5.5M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c2 .6 3.2 2.4 3.5 5.2"/>',
  box: '<path d="M3 7.5 12 3l9 4.5v9L12 21l-9-4.5zM3 7.5l9 4.5 9-4.5M12 12v9"/>',
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8a2 2 0 0 1-2 2M8 9h5M8 13h5M8 16h3"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m3 18 5-5 4 4 3-3 6 6"/>',
  alert: '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5h.01"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  grid: '<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
  send: '<path d="M21 3 3 10.5l7 2.5 2.5 7z M10 13l11-10"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
};
const svg = (k) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[k] || ""}</svg>`;
let badges = { chat: 0, cmp: 0 };
const greet = () => { const h = new Date().getHours(); return h < 5 ? "Xayrli tun" : h < 11 ? "Xayrli tong" : h < 17 ? "Xayrli kun" : "Xayrli kech"; };
function shell(path, inner) {
  $root.innerHTML = `<div class="layout">
    <nav class="side" aria-label="Bo'limlar">
      <div class="brand"><img src="../icons/logo.svg" width="38" height="38" alt=""><div><b>Kiddy Toys</b><span>Boshqaruv paneli</span></div></div>
      ${NAV.map(([p, t, ic]) => {
        const n = p === "/chat" ? badges.chat : p === "/shikoyatlar" ? badges.cmp : 0;
        return `<a href="#${p}" class="${path === p ? "on" : ""}">${svg(ic)}<span class="t">${t}</span>${n ? `<span class="cnt">${n}</span>` : ""}</a>`;
      }).join("")}
      <div class="foot">${esc(store.name)}<br><button data-act="logout">Chiqish</button></div>
    </nav>
    <main class="main" id="main">
      <div class="topbar"><span class="hi">${greet()}, ${esc(store.name || "admin")}!</span>
        <form class="qfind" data-submit="qfind"><input class="input" name="q" placeholder="Buyurtma № yoki mijoz nomi" autocomplete="off"><button class="btn">Topish</button></form></div>
      <div id="view" style="display:flex;flex-direction:column;gap:18px">${inner}</div>
    </main></div>`;
}
const main = () => document.getElementById("main");
const loading = '<div class="empty">Yuklanmoqda…</div>';
const statusPill = (s, t) => `<span class="pill ${{ failed: "red", new: "amber", cancelled: "red", delivered: "green", shipped: "green", accepted: "", sent: "gray" }[s] ?? ""}">${esc(t)}</span>`;

// ---------- bosh panel ----------
const shortSum = (n) => n >= 1e9 ? (n / 1e9).toFixed(1).replace(".0", "") + " mlrd" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(".0", "") + " mln" : fmt(n);
async function viewDash() {
  const d = await api("/stats");
  badges = { chat: d.unread_messages, cmp: d.open_complaints };
  const syncLine = (k, label) => {
    const ok = d.sync[`last_ok_${k}`], er = d.sync[`last_error_${k}`];
    const bad = er && (!ok || new Date(er.at) > new Date(ok.at));
    return `<tr><td>${label}</td><td>${bad ? `<span class="pill red">Xato</span> <span class="small">${esc(er.value)}</span>` : ok ? `<span class="pill green">OK</span> ${ago(ok.value)}` : '<span class="pill gray">hali yo\'q</span>'}</td></tr>`;
  };
  const max = Math.max(1, ...d.daily.map((x) => x.n));
  const gSum = d.by_group.reduce((a, g) => a + g.total, 0) || 1;
  const anySyncErr = ["products", "stock", "clients", "orders"].some((k) => { const ok = d.sync[`last_ok_${k}`], er = d.sync[`last_error_${k}`]; return er && (!ok || new Date(er.at) > new Date(ok.at)); });
  return `<h1>Bosh sahifa</h1>
    ${d.failed_orders.length ? `<div class="alert"><div><b>iBox'ga yetib bormagan buyurtmalar: ${d.failed_orders.length} ta</b><span>${d.failed_orders.slice(0, 4).map((o) => "№" + o.no).join(", ")} — qayta yuboring</span></div>
        <div class="row">${d.failed_orders.slice(0, 3).map((o) => `<button class="btn sm" data-act="resend" data-id="${o.id}">№${o.no} qayta</button>`).join("")}</div></div>`
      : `<div class="alert ${d.ledger_enabled ? "ok" : ""}"><div><b>Oldi-berdi: ${d.ledger_enabled ? "YOQILGAN" : "O'CHIRILGAN"}</b>
        <span>${d.ledger_enabled ? "Mijozlar o'z qarzi va akt-sverkani ilovada ko'radi." : "Mijozlar qarzini ilovada ko'rmaydi. 2–3 mijozni iBox bilan solishtirib, keyin yoqing."}</span></div>
        <a class="btn ${d.ledger_enabled ? "soft" : "green"}" href="#/sozlamalar">${d.ledger_enabled ? "Sozlamalar" : "Oldi-berdini yoqish"}</a></div>`}
    <div class="tiles">
      <a class="tile blue" href="#/buyurtmalar"><b>${d.orders.today_n}</b><span>bugungi buyurtma · ${shortSum(d.orders.today_sum)} so'm</span></a>
      <a class="tile green" href="#/mijozlar"><b>${d.clients.active_7d}</b><span>faol mijoz (7 kun) · jami ${fmt(d.clients.total)}</span></a>
      <a class="tile red" href="#/chat"><b>${d.unread_messages + d.open_complaints}</b><span>javob kutmoqda · ${d.unread_messages} xabar, ${d.open_complaints} shikoyat</span></a>
      <a class="tile orange" href="#/tovarlar"><b>${fmt(d.products.in_stock)}</b><span>omborda bor tovar · jami ${fmt(d.products.active)}</span></a>
    </div>
    <div class="kpis">
      <div class="kpi"><span>7 kunlik savdo</span><b>${shortSum(d.orders.week_sum)}</b><span>${d.orders.week_n} ta buyurtma</span></div>
      <div class="kpi"><span>30 kunlik savdo</span><b>${shortSum(d.orders.month_sum)}</b><span>${d.orders.month_n} ta buyurtma</span></div>
      <div class="kpi"><span>Ilovaga kirgan mijozlar</span><b>${fmt(d.clients.ever)}</b><span>Telegram'ga ulangan: ${fmt(d.clients.linked)}</span></div>
      <a class="kpi" href="#/yangiliklar"><span>Arzonlashgan tovarlar (14 kun)</span><b>${fmt(d.products.cheaper)}</b><span>yangiliklar: ${d.products.posts}${d.usd_rate ? ` · 1$ = ${fmt(d.usd_rate)}` : ""}</span></a>
    </div>
    <div class="grid2">
      <div class="card"><div class="card-h"><h2>Buyurtmalar · oxirgi 14 kun</h2><span class="small muted">${d.daily.reduce((a, x) => a + x.n, 0)} ta</span></div>
        <div class="vbars">${d.daily.map((x, i) => `<div class="c" title="${x.day}: ${x.n} ta, ${fmt(x.sum)} so'm"><span class="v">${x.n || ""}</span>
          <span class="b ${i === d.daily.length - 1 ? "today" : ""}" style="height:${Math.round((x.n / max) * 120)}px"></span><span class="d">${x.day.slice(8)}</span></div>`).join("")}</div></div>
      <div class="card"><div class="card-h"><h2>Bo'limlar bo'yicha (30 kun)</h2><a href="#/bolimlar">Bo'limlar</a></div>
        ${d.by_group.length ? d.by_group.map((g) => { const p = Math.round((g.total / gSum) * 100); return `<div class="hbar"><div class="row"><span>${esc(g.name)}</span><span class="muted">${shortSum(g.total)} · ${p}%</span></div><div class="track"><div class="fill" style="width:${p}%"></div></div></div>`; }).join("")
          : '<div class="empty">Hali buyurtma yo\'q</div>'}</div>
    </div>
    <div class="grid2">
      <div class="card"><div class="card-h"><h2>Hafta tovarlari</h2><a href="#/tovarlar">Hammasi</a></div><div class="tbl-wrap"><table><thead><tr><th>Nomi</th><th class="num">Dona</th><th class="num">Mijoz</th><th class="num">Summa</th></tr></thead><tbody>
        ${d.week_products.map((p) => `<tr><td>${esc(p.name)}</td><td class="num">${fmt(p.qty)}</td><td class="num">${p.clients}</td><td class="num">${fmt(p.total)}</td></tr>`).join("") || '<tr><td colspan="4" class="muted">Bu hafta buyurtma yo\'q</td></tr>'}</tbody></table></div></div>
      <div class="card"><div class="card-h"><h2>Hafta mijozlari</h2><a href="#/mijozlar">Hammasi</a></div><div class="tbl-wrap"><table><thead><tr><th>#</th><th>Mijoz</th><th class="num">Buyurtma</th><th class="num">Summa</th></tr></thead><tbody>
        ${d.week_clients.map((c, i) => `<tr class="click" data-act="client" data-id="${c.client_id}"><td>${i + 1}</td><td>${esc(c.name)}</td><td class="num">${c.n}</td><td class="num">${fmt(c.total)}</td></tr>`).join("") || '<tr><td colspan="4" class="muted">—</td></tr>'}</tbody></table></div></div>
    </div>
    <div class="card"><div class="card-h"><h2>iBox bilan sinxronlash</h2>${anySyncErr ? '<span class="pill red">Xato bor</span>' : '<span class="pill green">Hammasi joyida</span>'}</div>
      <div class="tbl-wrap"><table><tbody>
      ${syncLine("products", "Tovarlar")}${syncLine("stock", "Narx va qoldiq")}${syncLine("clients", "Mijozlar")}${syncLine("ledger", "Oldi-berdi hujjatlari")}${syncLine("order_status", "Buyurtma holatlari")}${syncLine("orders", "Buyurtmalarni yuborish")}
      </tbody></table></div></div>`;
}

// ---------- yangiliklar ----------
let postEdit = null;
async function viewPostsAdmin() {
  const d = await api("/posts");
  const e = postEdit || {};
  return `<h1>Yangiliklar</h1>
    <p class="muted" style="margin:0">Mijozlar ilovaning bosh sahifasida ko'radi: yangi kolleksiya, aksiya, ish tartibi, yetkazib berish haqida. Tovar kodlarini yozsangiz, yangilik ichida o'sha tovarlar "Savatga" tugmasi bilan chiqadi.</p>
    <form class="card stack" data-submit="postsave">
      <div class="card-h" style="margin:0"><h2>${e.id ? "Tahrirlash" : "Yangi yangilik"}</h2>${e.id ? '<button type="button" class="btn soft sm" data-act="postnew">Yangisini yozish</button>' : ""}</div>
      <div class="form">
        <label class="f" style="grid-column:1/-1">Sarlavha<input class="input" name="title" maxlength="120" required value="${esc(e.title || "")}" placeholder="Masalan: Yangi yozgi kolleksiya keldi!"></label>
        <label class="f" style="grid-column:1/-1">Matn<textarea class="input" name="body" rows="5" maxlength="4000" placeholder="Batafsil…">${esc(e.body || "")}</textarea></label>
        <label class="f">Rasm<input class="input" type="file" name="image" accept="image/*" style="padding-top:6px"></label>
        <label class="f">Tovarlar (kod, shtrix-kod yoki ID, vergul bilan)<input class="input" name="products" value="${esc((e.product_ids || []).join(", "))}" placeholder="008-959, 40000305"></label>
        <label class="f">E'lon vaqti<input class="input" type="datetime-local" name="published_at" value="${toLocalInput(e.published_at)}"></label>
      </div>
      <div class="row">
        <label class="chk"><input type="checkbox" name="published" ${e.id ? (e.published ? "checked" : "") : "checked"}> E'lon qilingan</label>
        <label class="chk"><input type="checkbox" name="pinned" ${e.pinned ? "checked" : ""}> Muhim (tepada turadi)</label>
        <label class="chk"><input type="checkbox" name="notify"> Telegram'dagi mijozlarga ham yuborish</label>
        ${e.image_url ? `<label class="chk"><input type="checkbox" name="remove_image"> Rasmni olib tashlash</label>` : ""}
      </div>
      <div class="row"><button class="btn">${e.id ? "Saqlash" : "E'lon qilish"}</button></div>
    </form>
    <div class="tbl-wrap"><table><thead><tr><th></th><th>Sarlavha</th><th>Sana</th><th class="num">Tovar</th><th class="num">Ko'rildi</th><th>Holat</th><th></th></tr></thead><tbody>
      ${d.items.map((p) => `<tr><td>${p.image_url ? `<img src="${esc(fileUrl(p.image_url))}" width="56" height="40" style="object-fit:cover;border-radius:8px">` : ""}</td>
        <td><b>${esc(p.title)}</b>${p.pinned ? ' <span class="pill amber">muhim</span>' : ""}</td><td>${dt(p.published_at)}</td><td class="num">${p.product_ids.length}</td><td class="num">${p.views}</td>
        <td>${p.published ? '<span class="pill green">e\'londa</span>' : '<span class="pill gray">qoralama</span>'}</td>
        <td class="num" style="white-space:nowrap"><button class="btn soft sm" data-act="postedit" data-id="${p.id}">Tahrirlash</button> <button class="btn danger sm" data-act="postdel" data-id="${p.id}">O'chirish</button></td></tr>`).join("") || '<tr><td colspan="7" class="empty">Hali yangilik yo\'q</td></tr>'}
    </tbody></table></div>`;
}
let postsCache = [];

// ---------- buyurtmalar ----------
let orderFilter = "";
let lastOrders = [];
async function viewOrders() {
  const d = await api(`/orders${orderFilter ? "?status=" + orderFilter : ""}`);
  lastOrders = d.items;
  const opts = [["", "Hammasi"], ["sent", "iBox'da"], ["accepted", "Tasdiqlangan"], ["shipped", "Jo'natilgan"], ["failed", "Xato"], ["cancelled", "Bekor"]];
  return `<div class="row between"><h1>Buyurtmalar</h1>
      <div class="row"><select class="input" data-change="ofilter">${opts.map(([v, t]) => `<option value="${v}" ${v === orderFilter ? "selected" : ""}>${t}</option>`).join("")}</select>
      <button class="btn soft" data-act="ocsv">⬇ Excel (CSV)</button></div></div>
    <div class="tbl-wrap"><table><thead><tr><th>№</th><th>Sana</th><th>Mijoz</th><th class="num">Xil</th><th class="num">Summa</th><th>Holat</th><th>iBox</th></tr></thead><tbody>
    ${d.items.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td><b>${o.no}</b></td><td>${dt(o.created_at)}</td><td>${esc(o.client_name)}</td>
      <td class="num">${o.lines}</td><td class="num">${fmt(o.total)}</td><td>${statusPill(o.status, o.status_text)}</td><td class="small muted">${o.ibox_number ? "№" + esc(o.ibox_number) : esc(o.ibox_error || "")}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Buyurtma yo\'q</td></tr>'}
    </tbody></table></div>`;
}
async function openOrder(id) {
  const o = await api(`/orders/${id}`);
  drawer(`<div class="row between"><h1>Buyurtma №${o.no}</h1><button class="btn soft sm" data-act="close">Yopish</button></div>
    <div class="card stack"><div class="row between"><b>${esc(o.client_name)}</b>${statusPill(o.status, o.status_text)}</div>
      <span class="muted">${esc(o.phone || "")} · ${dt(o.created_at)}${o.ibox_number ? ` · iBox №${esc(o.ibox_number)}` : ""}</span>
      ${o.comment ? `<span>Izoh: ${esc(o.comment)}</span>` : ""}${o.ibox_error ? `<span class="err">${esc(o.ibox_error)}</span>` : ""}
      ${["failed", "new"].includes(o.status) ? `<button class="btn" data-act="resend" data-id="${o.id}">iBox'ga qayta yuborish</button>` : ""}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th class="num">Miqdor</th><th class="num">Narx</th><th class="num">Summa</th></tr></thead><tbody>
      ${o.items.map((i) => `<tr><td>${esc(i.name)}</td><td class="num">${i.mode === "box" && i.box_qty ? `${Math.floor(i.qty / i.box_qty)} kar.${i.qty % i.box_qty ? ` + ${i.qty % i.box_qty}` : ""}<br><span class="small muted">${fmt(i.qty)} dona</span>` : `${fmt(i.qty)} dona`}</td><td class="num">${fmt(i.price)}</td><td class="num">${fmt(i.total)}</td></tr>`).join("")}
      <tr><td colspan="3"><b>Jami</b></td><td class="num"><b>${fmt(o.total)}</b></td></tr></tbody></table></div>`);
}

// ---------- mijozlar ----------
let clientQ = "";
async function viewClients() {
  const d = await api(`/clients?q=${encodeURIComponent(clientQ)}`);
  return `<div class="row between"><h1>Mijozlar</h1>
      <form data-submit="csearch" class="row"><input class="input" name="q" placeholder="Nomi, kodi yoki telefon" value="${esc(clientQ)}"><button class="btn soft">Qidirish</button></form></div>
    <div class="tbl-wrap"><table><thead><tr><th>Mijoz</th><th>Telefon</th><th>Telegram</th><th class="num">Balans</th><th class="num">Limit</th><th>Ilovaga kirgan</th><th class="num">Buyurtma</th></tr></thead><tbody>
    ${d.items.map((c) => `<tr class="click" data-act="client" data-id="${c.id}"><td><b>${esc(c.name)}</b><br><span class="small muted">${esc(c.code || "")}</span></td>
      <td>${esc(c.phone || "—")}</td><td>${c.telegram ? '<span class="pill green">ulangan</span>' : '<span class="pill gray">yo\'q</span>'}</td>
      <td class="num ${c.balance > 0 ? "pos" : c.balance < 0 ? "neg" : ""}">${fmt(c.balance)}</td><td class="num">${fmt(c.credit_limit)}</td>
      <td>${ago(c.last_seen)}</td><td class="num">${c.orders_n}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Topilmadi</td></tr>'}
    </tbody></table></div>`;
}
async function openClient(id) {
  const c = await api(`/clients/${id}`);
  const l = c.ledger;
  drawer(`<div class="row between"><h1 style="font-size:20px">${esc(c.name)}</h1><button class="btn soft sm" data-act="close">Yopish</button></div>
    <span class="muted">${esc(c.phone || "")} · kod ${esc(c.code || "—")} · Telegram: ${c.telegram ? "ulangan" : "yo'q"} · kredit muddati: ${c.credit_days ?? "—"} kun</span>
    ${l ? `<div class="kpis"><div class="kpi"><span>Balans</span><b class="${l.balance > 0 ? "pos" : "neg"}">${fmt(l.balance)}</b><span>${l.balance > 0 ? "qarz" : l.balance < 0 ? "haq (avans)" : ""}${l.parts && Math.abs(l.parts.usd) >= 0.01 ? ` · so'm ${fmt(l.parts.uzs)}, $${l.parts.usd}` : ""}</span></div>
      <div class="kpi"><span>Muddati o'tgan</span><b>${fmt(l.overdue)}</b><span>${l.overdue_since ? "eng eskisi " + l.overdue_since : ""}</span></div></div>` : ""}
    <form class="card stack" data-submit="csave" data-id="${c.id}"><h2>Limitlar va boshlang'ich qoldiq</h2>
      <div class="form">
        <label class="f">Kredit limiti, so'm<input class="input" name="credit_limit" inputmode="numeric" value="${c.credit_limit ?? ""}" placeholder="limitsiz"></label>
        <label class="f">Minimal buyurtma, so'm<input class="input" name="min_order_sum" inputmode="numeric" value="${c.min_order_sum ?? ""}" placeholder="umumiy sozlama"></label>
        <label class="f">Boshlang'ich qoldiq, so'm (+ qarz, − haq)<input class="input" name="opening_balance" inputmode="numeric" value="${c.opening_balance ?? 0}"></label>
        <label class="f">Boshlang'ich qoldiq, dollar<input class="input" name="opening_balance_usd" inputmode="decimal" value="${c.opening_balance_usd ?? 0}"></label>
        <label class="f">Qaysi sanadan<input class="input" type="date" name="opening_balance_date" value="${c.opening_balance_date ? String(c.opening_balance_date).slice(0, 10) : ""}"></label>
      </div>
      <span class="small muted">Boshlang'ich qoldiq — iBox'dagi shu sanadagi qarz (akt-sverkadan). Undan keyingi jo'natma, to'lov va qaytarishlar iBox'dan avtomatik qo'shiladi.</span>
      <div class="row"><button class="btn">Saqlash</button><button type="button" class="btn soft" data-act="chatwith" data-id="${c.id}">Chatga yozish</button></div></form>
    ${l && l.entries.length ? `<div class="tbl-wrap"><table><thead><tr><th>Sana</th><th>Hujjat</th><th class="num">Summa</th><th class="num">Qoldiq</th></tr></thead><tbody>
      ${l.entries.map((e) => `<tr><td>${e.date}</td><td>${esc(e.title)} ${esc(e.number || "")}</td><td class="num ${e.amount > 0 ? "pos" : "neg"}">${e.currency === "USD" ? "$" + e.amount : fmt(e.amount)}</td><td class="num">${e.currency === "USD" ? "$" + e.balance : fmt(e.balance)}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <div class="tbl-wrap"><table><thead><tr><th>Oxirgi buyurtmalar</th><th class="num">Summa</th><th>Holat</th></tr></thead><tbody>
      ${c.orders.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td>№${o.no} · ${dt(o.created_at)}</td><td class="num">${fmt(o.total)}</td><td>${statusPill(o.status, o.status_text)}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">Yo\'q</td></tr>'}</tbody></table></div>`);
}

// ---------- tovarlar ----------
let prodQ = "", prodFilter = "";
async function viewProducts() {
  const d = await api(`/products?q=${encodeURIComponent(prodQ)}&filter=${prodFilter}`);
  const opts = [["", "Hammasi"], ["no_box", "Karobka soni yo'q"], ["suggest", "Nomidan topilgan taklif bor"], ["promo", "Aksiyadagilar"], ["no_price", "Narxi yo'q"]];
  const nSuggest = d.items.filter((p) => !p.box_qty && p.box_qty_suggest).length;
  return `<div class="row between"><h1>Tovarlar</h1>
      <form data-submit="psearch" class="row"><input class="input" name="q" placeholder="Nomi, artikul, shtrix-kod" value="${esc(prodQ)}">
        <select class="input" name="filter">${opts.map(([v, t]) => `<option value="${v}" ${v === prodFilter ? "selected" : ""}>${t}</option>`).join("")}</select><button class="btn soft">Ko'rsatish</button></form></div>
    <details class="card"><summary style="cursor:pointer;font-weight:800">📋 Karobka sonini Excel'dan ko'chirib qo'yish</summary>
      <form data-submit="bulk" class="stack" style="margin-top:12px"><span class="muted small">Faqat iBox'da karobka soni yo'q tovarlar uchun kerak. Excel'da ikki ustun: <b>artikul yoki shtrix-kod</b> va <b>karobkadagi dona soni</b>. Ustunlarni belgilab nusxalang (Ctrl+C) va shu yerga qo'ying (Ctrl+V).</span>
      <textarea class="input" name="text" rows="6" placeholder="RC-01	12&#10;4600234100518	48"></textarea><div><button class="btn">Yuklash</button></div></form></details>
    <div class="card row between"><span class="muted">Karobkadagi son tartibi: <b>qo'lda kiritilgan</b> → <b>iBox'dagi</b>. Nomidan topilgani faqat tasdiqlasangiz ishlatiladi.</span>
      ${nSuggest ? `<button class="btn soft" data-act="accept">Nomidan topilgan ${nSuggest} tasini tasdiqlash</button>` : ""}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th class="num">Narx</th><th class="num">Karobka narxi</th><th class="num">Qoldiq</th><th>Karobkada (dona)</th><th>Aksiya belgisi</th><th>Eski narx</th><th></th></tr></thead><tbody>
    ${d.items.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="small muted">${esc(p.sku || "")} ${esc(p.category_name || "")}</span></td>
      <td class="num">${fmt(p.price)}</td><td class="num">${p.box_qty && p.price ? fmt(p.price * p.box_qty) : "—"}</td>
      <td class="num">${fmt(p.stock)}${p.box_qty && p.stock ? `<br><span class="small muted">~${Math.floor(p.stock / p.box_qty)} kar.</span>` : ""}</td>
      <td><input class="input sm" data-f="box_qty" data-id="${p.id}" inputmode="numeric" value="${p.box_qty_manual ?? ""}" placeholder="${p.box_qty_ibox ?? ""}">
        <div class="small muted">${p.box_qty_manual ? "qo'lda" : p.box_qty_ibox ? `iBox: ${p.box_qty_ibox}` : p.box_qty_suggest ? `nomidan: ${p.box_qty_suggest}?` : "yo'q"}</div></td>
      <td><input class="input sm" data-f="promo_label" data-id="${p.id}" value="${esc(p.promo_label || "")}" placeholder="—"></td>
      <td><input class="input sm" style="width:110px" data-f="promo_old_price" data-id="${p.id}" inputmode="numeric" value="${p.promo_old_price ?? ""}"></td>
      <td><button class="btn sm" data-act="psave" data-id="${p.id}">Saqlash</button></td></tr>`).join("") || '<tr><td colspan="7" class="empty">Topilmadi</td></tr>'}
    </tbody></table></div>`;
}

// ---------- bannerlar ----------
let bannerEdit = null;
async function viewBanners() {
  const d = await api("/banners");
  const b = bannerEdit || { title: "", subtitle: "", color: "#3D4FE0", link_type: "none", link_value: "", active: true, sort: 0 };
  return `<h1>Aksiya bannerlari</h1>
    <form class="card stack" data-submit="bsave"><h2>${b.id ? "Bannerni tahrirlash" : "Yangi banner"}</h2>
      <div class="form">
        <label class="f">Sarlavha<input class="input" name="title" maxlength="80" value="${esc(b.title)}" required></label>
        <label class="f">Qo'shimcha matn<input class="input" name="subtitle" maxlength="160" value="${esc(b.subtitle || "")}"></label>
        <label class="f">Rang<input class="input" type="color" name="color" value="${esc(b.color)}" style="padding:4px"></label>
        <label class="f">Bosilganda<select class="input" name="link_type">
          ${[["none", "Hech narsa"], ["category", "Kategoriya (ID)"], ["product", "Tovar (ID)"], ["search", "Qidiruv so'zi"]].map(([v, t]) => `<option value="${v}" ${b.link_type === v ? "selected" : ""}>${t}</option>`).join("")}</select></label>
        <label class="f">Havola qiymati<input class="input" name="link_value" value="${esc(b.link_value || "")}" placeholder="masalan 3 yoki ayiq"></label>
        <label class="f">Tartib<input class="input" name="sort" type="number" value="${b.sort || 0}"></label>
        <label class="f">Boshlanishi<input class="input" type="datetime-local" name="starts_at" value="${toLocalInput(b.starts_at)}"></label>
        <label class="f">Tugashi<input class="input" type="datetime-local" name="ends_at" value="${toLocalInput(b.ends_at)}"></label>
        <label class="f">Rasm (ixtiyoriy)<input class="input" type="file" name="image" accept="image/*" style="padding:6px"></label>
      </div>
      <label class="chk"><input type="checkbox" name="active" ${b.active ? "checked" : ""}> Faol</label>
      <div class="row"><button class="btn">${b.id ? "Saqlash" : "Qo'shish"}</button>${b.id ? '<button type="button" class="btn soft" data-act="bnew">Bekor qilish</button>' : ""}</div></form>
    <div class="grid2">${d.items.map((x) => `<div class="card stack">
      <div class="banner-prev" style="background:${esc(x.color)}">${x.image_url ? `<img src="${esc(fileUrl(x.image_url))}" alt="">` : ""}<div><b style="font-size:18px">${esc(x.title)}</b><br>${esc(x.subtitle || "")}</div></div>
      <div class="row between"><span>${x.active ? '<span class="pill green">faol</span>' : '<span class="pill gray">o\'chiq</span>'} <span class="small muted">${x.link_type !== "none" ? esc(x.link_type + ": " + x.link_value) : ""}</span></span>
        <span class="row"><button class="btn soft sm" data-act="bedit" data-id="${x.id}">Tahrirlash</button><button class="btn danger sm" data-act="bdel" data-id="${x.id}">O'chirish</button></span></div></div>`).join("") || '<div class="empty card">Hali banner yo\'q</div>'}</div>`;
}
let bannersCache = [];

// ---------- shikoyatlar ----------
let cmpFilter = "new";
async function viewComplaints() {
  const d = await api(`/complaints${cmpFilter ? "?status=" + cmpFilter : ""}`);
  const opts = [["new", "Yangi"], ["accepted", "Qabul qilingan"], ["done", "Hal qilingan"], ["rejected", "Rad etilgan"], ["", "Hammasi"]];
  return `<div class="row between"><h1>Qaytarish va shikoyatlar</h1>
      <select class="input" data-change="cfilter">${opts.map(([v, t]) => `<option value="${v}" ${v === cmpFilter ? "selected" : ""}>${t}</option>`).join("")}</select></div>
    ${d.items.map((c) => `<form class="card stack" data-submit="cmpsave" data-id="${c.id}">
      <div class="row between"><b>${c.kind === "return" ? "↩️ Qaytarish" : "⚠️ Shikoyat"} #${c.id} · ${esc(c.client_name)}</b><span class="small muted">${dt(c.created_at)}</span></div>
      <span class="muted">${esc(c.phone || "")}${c.order_no ? ` · buyurtma №${c.order_no}` : ""}${c.product_name ? ` · ${esc(c.product_name)}` : ""}${c.qty ? `, ${fmt(c.qty)} dona` : ""}</span>
      <div style="white-space:pre-wrap">${esc(c.reason)}</div>
      ${c.images.length ? `<div class="thumbs">${c.images.map((u) => `<a href="${esc(fileUrl(u))}" target="_blank" rel="noopener"><img src="${esc(fileUrl(u))}" alt="Rasm"></a>`).join("")}</div>` : ""}
      <div class="row"><select class="input" name="status">${[["new", "Yangi"], ["accepted", "Qabul qilindi"], ["rejected", "Rad etildi"], ["done", "Hal qilindi"]].map(([v, t]) => `<option value="${v}" ${c.status === v ? "selected" : ""}>${t}</option>`).join("")}</select>
        <input class="input grow" name="admin_note" placeholder="Mijozga izoh (ixtiyoriy)" value="${esc(c.admin_note || "")}"><button class="btn">Saqlash va xabar berish</button></div>
    </form>`).join("") || '<div class="empty card">Bu bo\'limda hech narsa yo\'q</div>'}`;
}

// ---------- chat ----------
let chatClient = null, chatTimer = null;
async function viewChat() {
  const d = await api("/chats");
  badges.chat = d.items.reduce((s, c) => s + c.unread, 0);
  if (!chatClient && d.items[0]) chatClient = d.items[0].client_id;
  return `<h1>Chat</h1><div class="chat">
    <div class="list">${d.items.map((c) => `<button data-act="pick" data-id="${c.client_id}" class="${c.client_id === chatClient ? "on" : ""}">
      <span class="row between"><b>${esc(c.name)}</b>${c.unread ? `<span class="pill red">${c.unread}</span>` : ""}</span>
      <span class="small muted">${c.last_dir === "out" ? "Siz: " : ""}${esc((c.last_text || "[rasm]").slice(0, 60))}</span><span class="small muted">${ago(c.last_at)}</span></button>`).join("") || '<div class="empty">Hali xabar yo\'q</div>'}</div>
    <div class="conv" id="conv">${chatClient ? loading : '<div class="empty">Mijozni tanlang</div>'}</div></div>`;
}
async function loadConv() {
  const el = document.getElementById("conv");
  if (!el || !chatClient) return;
  const d = await api(`/chats/${chatClient}`);
  el.innerHTML = `<div class="row between" style="padding:12px 16px;border-bottom:1px solid var(--line)"><b>${esc(d.client?.name)}</b><span class="small muted">${esc(d.client?.phone || "")} · Telegram: ${d.client?.telegram ? "ulangan" : "yo'q"}</span></div>
    <div class="msgs" id="msgs">${d.items.map((m) => `<div class="bubble ${m.direction}">${esc(m.text || "")}${m.image_url ? `<a href="${esc(fileUrl(m.image_url))}" target="_blank" rel="noopener"><img src="${esc(fileUrl(m.image_url))}" alt="Rasm"></a>` : ""}
      <div class="t">${m.direction === "out" ? esc(m.author || "Menejer") + " · " : ""}${dt(m.created_at)}${m.direction === "out" && m.read_at ? " · o'qildi" : ""}</div></div>`).join("") || '<div class="empty">Xabar yo\'q</div>'}</div>
    <form data-submit="send"><input class="input grow" name="text" placeholder="Javob yozing…" autocomplete="off"><label class="btn soft" style="cursor:pointer">📎<input type="file" name="image" accept="image/*" hidden></label><button class="btn">Yuborish</button></form>`;
  const msgs = document.getElementById("msgs");
  msgs.scrollTop = msgs.scrollHeight;
}

// ---------- qidiruv: sinonimlar, sinash, tahlil ----------
let searchTestQ = "";
async function viewSearch() {
  const [d, syn, test] = await Promise.all([
    api("/search-stats?days=30"), api("/synonyms"),
    searchTestQ ? api(`/search-test?q=${encodeURIComponent(searchTestQ)}`) : Promise.resolve(null),
  ]);
  return `<h1>Qidiruv va sinonimlar</h1>
    <p class="muted" style="margin:0">Ilova qidiruvi lotin va kirillni bir xil tushunadi (машина = mashina), apostrofsiz yozilsa ham topadi (qogirchoq = qo'g'irchoq), xato yozilsa yaqin variantlarni taklif qiladi. Sinonimlar — mijozlar boshqacha ataydigan so'zlar.</p>
    <form class="card stack" data-submit="stest"><h2>Qidiruvni sinash</h2>
      <div class="row"><input class="input" name="q" placeholder="Mijoz nima yozadi? Masalan: кукла, mashna, ayiqcha" value="${esc(searchTestQ)}"><button class="btn soft">Sinash</button></div>
      ${test ? `<span class="small">Tushunildi: ${test.understood.map((g) => `<b>${g.map(esc).join(" / ")}</b>`).join(" + ") || "—"}
        · ${test.fuzzy ? `aniq topilmadi, o'xshashlari` : `${test.total} ta tovar`}${test.did_you_mean.length ? ` · Balki: ${test.did_you_mean.map(esc).join(", ")}` : ""}</span>
        <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th>Guruh</th><th>Kategoriya</th><th>Brend</th></tr></thead><tbody>
        ${test.items.map((p) => `<tr><td>${esc(p.name)}</td><td>${esc(p.group_name || "")}</td><td>${esc(p.category_name || "")}</td><td>${esc(p.brand_name || "")}</td></tr>`).join("") || '<tr><td colspan="4" class="muted">Hech narsa chiqmadi — pastda sinonim qo\'shing</td></tr>'}</tbody></table></div>` : ""}
    </form>
    <form class="card stack" data-submit="synsave" id="synform"><h2>Sinonim qo'shish</h2>
      <input type="hidden" name="id" value="">
      <label class="f">Bir xil ma'noli so'zlar, vergul bilan<input class="input" name="words" placeholder="qo'g'irchoq, kukla, кукла, barbie" required></label>
      <span class="small muted">Birortasi qidirilsa, qolganlari bo'yicha ham topiladi. Ruscha, inglizcha va xalq orasidagi nomlarni yozing.</span>
      <div class="row"><button class="btn">Saqlash</button><button type="button" class="btn soft" data-act="synnew">Tozalash</button></div></form>
    <div class="tbl-wrap"><table><thead><tr><th>Sinonimlar (${syn.items.length})</th><th></th></tr></thead><tbody>
      ${syn.items.map((x) => `<tr><td>${x.words.map(esc).join(", ")}</td><td class="num" style="white-space:nowrap">
        <button class="btn soft sm" data-act="synedit" data-id="${x.id}" data-words="${esc(x.words.join(", "))}">Tahrirlash</button>
        <button class="btn soft sm" data-act="syndel" data-id="${x.id}">O'chirish</button></td></tr>`).join("") || '<tr><td colspan="2" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
    <h2 style="margin-top:8px">Tahlil — 30 kun</h2>
    <p class="muted" style="margin:0">Topilmagan so'zlar: yo sinonim qo'shing, yo bu tovarni olib kelish kerak.</p>
    <div class="grid2">
      <div class="tbl-wrap"><table><thead><tr><th>Topilmagan so'zlar</th><th class="num">Marta</th><th class="num">Mijoz</th><th></th></tr></thead><tbody>
        ${d.not_found.map((r) => `<tr><td>${esc(r.q)}</td><td class="num">${r.n}</td><td class="num">${r.clients}</td>
          <td class="num"><button class="btn soft sm" data-act="synfrom" data-q="${esc(r.q)}">+ sinonim</button></td></tr>`).join("") || '<tr><td colspan="4" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
      <div class="tbl-wrap"><table><thead><tr><th>Eng ko'p qidirilgan</th><th class="num">Marta</th><th class="num">O'rtacha natija</th></tr></thead><tbody>
        ${d.top.map((r) => `<tr><td>${esc(r.q)}</td><td class="num">${r.n}</td><td class="num">${r.avg_results}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
    </div>`;
}

// ---------- katalog bo'limlari ----------
let secKind = "group";
async function viewSections() {
  const d = await api("/sections");
  const tabs = [["group", "Guruhlar"], ["category", "Kategoriyalar"], ["brand", "Brendlar"]];
  const list = d[secKind];
  return `<h1>Katalog bo'limlari</h1>
    <p class="muted" style="margin:0">Ilovada tovarlar iBox'dagi guruh, kategoriya va brend bo'yicha ajratiladi. Nomlarni iBox'da o'zgartirasiz — 5 daqiqada ilovaga o'tadi. Bu yerda keraksiz bo'limni ilovada yashirish mumkin (tovarlar ham ko'rinmaydi).</p>
    <div class="row">${tabs.map(([k, t]) => `<button class="btn ${k === secKind ? "" : "soft"} sm" data-act="seckind" data-k="${k}">${t} (${d[k].length})</button>`).join("")}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Nomi</th><th class="num">Tovarlar</th><th>Ilovada</th></tr></thead><tbody>
      ${list.map((r) => `<tr><td>${esc(r.name)}</td><td class="num">${r.n}</td><td>
        <label class="chk" style="margin:0"><input type="checkbox" data-change="sechide" data-kind="${secKind}" data-key="${esc(r.key)}" ${r.hidden ? "" : "checked"}> ${r.hidden ? '<span class="pill gray">yashirilgan</span>' : "ko'rinadi"}</label></td></tr>`).join("") || '<tr><td colspan="3" class="muted">iBox\'da bo\'lim yo\'q</td></tr>'}</tbody></table></div>`;
}

// ---------- xabar yuborish ----------
async function viewBroadcast() {
  const d = await api("/broadcast", { method: "POST", body: { text: "...", dry_run: true } });
  return `<h1>Barcha mijozlarga xabar</h1>
    <form class="card stack" data-submit="bcast" style="max-width:680px">
      <span class="muted">Xabar Telegram botga ulangan <b>${d.recipients}</b> ta mijozga boradi. Aksiya, yangi tovar yoki ish tartibi haqida e'lon uchun.</span>
      <textarea class="input" name="text" rows="6" maxlength="3000" required placeholder="Masalan: Yangi yil munosabati bilan 25-dekabrgacha barcha yumshoq o'yinchoqlarga 15% chegirma!"></textarea>
      <label class="f">Tugma bosilganda ochiladigan bo'lim (ixtiyoriy)<select class="input" name="link"><option value="/">Bosh sahifa</option><option value="/katalog?promo=1">Aksiyadagi tovarlar</option><option value="/katalog?sort=new">Yangi tovarlar</option></select></label>
      <div><button class="btn">Yuborish</button></div></form>`;
}

// ---------- sozlamalar ----------
async function viewSettings() {
  const d = await api("/settings");
  const s = d.settings;
  return `<h1>Sozlamalar</h1>
    <form class="card stack" data-submit="ssave" style="max-width:760px"><h2>Ilova</h2>
      <div class="form">
        <label class="f">Minimal buyurtma summasi, so'm (0 — cheklovsiz)<input class="input" name="min_order_sum" inputmode="numeric" value="${s.min_order_sum}"></label>
        <label class="f">"Yangi" belgisi necha kun turadi<input class="input" name="new_days" type="number" min="1" value="${s.new_days}"></label>
        <label class="f">Ilovada birinchi tanlangan birlik<select class="input" name="default_mode"><option value="box" ${s.default_mode === "box" ? "selected" : ""}>Karobka (ulgurji)</option><option value="unit" ${s.default_mode === "unit" ? "selected" : ""}>Dona</option></select></label>
        <label class="f">Dollar kursi (1 USD = … so'm)<input class="input" name="usd_rate" inputmode="decimal" value="${s.usd_rate}"></label>
      </div>
      <h2 style="margin-top:6px">Katalog ko'rinishi</h2>
      <div class="form">
        <label class="f">Tovarlar qanday ko'rinsin<select class="input" name="catalog_view">
          <option value="media" ${s.catalog_view !== "list" ? "selected" : ""}>Rasmli to'r — 3 ustun (Telegram "Media" kabi)</option>
          <option value="list" ${s.catalog_view === "list" ? "selected" : ""}>Ro'yxat — har tovar alohida qatorda</option></select></label>
        <label class="f">Tepadagi bo'limlar paneli (saralash)<select class="input" name="catalog_tabs">
          <option value="folder" ${s.catalog_tabs === "folder" || !s.catalog_tabs ? "selected" : ""}>Papkalar bo'yicha (iBox papkalari)</option>
          <option value="group" ${s.catalog_tabs === "group" ? "selected" : ""}>Guruhlar bo'yicha</option>
          <option value="category" ${s.catalog_tabs === "category" ? "selected" : ""}>Kategoriyalar bo'yicha</option>
          <option value="none" ${s.catalog_tabs === "none" ? "selected" : ""}>O'chirilgan — panel ko'rinmaydi</option></select></label>
      </div>
      <span class="small muted">Rasmli to'rda tovar bosilsa kattalashadi va ostida karobka/dona hamda son yozish joyi chiqadi. O'zgarish mijozlar ilovani qayta ochganda kuchga kiradi.</span>
      <label class="chk"><input type="checkbox" name="usd_rate_auto" ${s.usd_rate_auto ? "checked" : ""}> Kursni iBox'dan avtomatik olish (iBox kursni API orqali bersa ishlaydi; hozircha qo'lda yangilang)</label>
      <label class="chk"><input type="checkbox" name="show_usd" ${s.show_usd ? "checked" : ""}> Dollarli tovarlarda asl narxni ($) ham ko'rsatish</label>
      <label class="chk"><input type="checkbox" name="ledger_enabled" ${s.ledger_enabled ? "checked" : ""}> Oldi-berdi (qarz, akt-sverka) bo'limini mijozlarga ko'rsatish</label>
      <label class="chk"><input type="checkbox" name="block_over_limit" ${s.block_over_limit ? "checked" : ""}> Kredit limitidan oshsa buyurtmani to'xtatish</label>
      <label class="chk"><input type="checkbox" name="overdue_reminder" ${s.overdue_reminder ? "checked" : ""}> Muddati o'tgan qarz haqida haftada bir eslatma</label>
      <label class="chk"><input type="checkbox" name="new_arrivals_notify" ${s.new_arrivals_notify ? "checked" : ""}> Yangi kelgan tovarlar haqida kuniga bir marta xabar</label>
      <span class="small muted">Qarz iBox'ning "Qarzdorlar" ro'yxatidan aniq olinadi (so'm va dollar alohida). Agar iBox kaliti bu ro'yxatga ruxsat bermasa, qarz hujjatlardan hisoblanadi — unda Mijozlar bo'limida boshlang'ich qoldiq va sanani kiriting. Yoqishdan oldin 2–3 mijozning qarzini iBox bilan solishtiring.</span>
      <div><button class="btn">Saqlash</button></div></form>
    <div class="card stack" style="max-width:760px"><h2>Adminlar</h2>
      ${d.admins.map((a) => `<div class="row between"><span><b>${esc(a.name)}</b> · …${esc(a.phone_key.slice(-4))}</span><span>${a.telegram ? '<span class="pill green">Telegram ulangan</span>' : '<span class="pill amber">botga raqam yubormagan</span>'} ${a.active ? "" : '<span class="pill gray">o\'chiq</span>'}</span></div>`).join("")}
      <form data-submit="addadmin" class="row"><input class="input" name="name" placeholder="Ism" required><input class="input" name="phone" placeholder="Telefon" required><button class="btn soft">Admin qo'shish</button></form>
      <span class="small muted">Yangi admin Telegram botga o'z raqamini yuborgach, panelga kira oladi.</span></div>
    <details class="card" style="max-width:760px"><summary style="cursor:pointer;font-weight:800">🔧 iBox javob namunalari (dasturchi uchun)</summary>
      <div class="stack" style="margin-top:10px">${Object.entries(d.samples).map(([k, v]) => `<div><b>${esc(k)}</b><pre>${esc(v || "— hali yo'q —")}</pre></div>`).join("")}</div></details>`;
}

// ---------- drawer ----------
function drawer(html) {
  closeDrawer();
  const bg = document.createElement("div"); bg.className = "drawer-bg"; bg.onclick = closeDrawer;
  const d = document.createElement("div"); d.className = "drawer"; d.setAttribute("role", "dialog"); d.innerHTML = html;
  document.getElementById("main").append(bg, d);
}
function closeDrawer() { document.querySelectorAll(".drawer, .drawer-bg").forEach((x) => x.remove()); }

// ---------- marshrut ----------
const VIEWS = { "/": viewDash, "/yangiliklar": async () => { const h = await viewPostsAdmin(); return h; }, "/buyurtmalar": viewOrders, "/mijozlar": viewClients, "/tovarlar": viewProducts, "/bannerlar": viewBanners,
  "/shikoyatlar": viewComplaints, "/chat": viewChat, "/qidiruv": viewSearch, "/bolimlar": viewSections, "/xabar": viewBroadcast, "/sozlamalar": viewSettings };

async function render() {
  clearInterval(chatTimer);
  if (!store.token) return viewLogin();
  const path = (location.hash.slice(1) || "/").split("?")[0];
  const view = VIEWS[path] || viewDash;
  shell(path, loading);
  actions = commonActions();
  try {
    const html = await view();
    shell(path, html);
    if (path === "/chat") { await loadConv(); chatTimer = setInterval(() => loadConv().catch(() => {}), 10000); }
  } catch (e) { const v = document.getElementById("view") || main(); v.innerHTML = `<div class="empty card">${esc(e.message)}</div>`; }
}

function commonActions() {
  return {
    logout: async () => { if (!twice("logout", "Chiqish uchun yana bir marta bosing")) return; try { await api("/auth/logout", { method: "POST" }); } catch { /* */ } store.token = null; render(); },
    close: closeDrawer,
    // Yuqoridagi tezkor qidiruv: raqam — buyurtma, matn — mijoz
    qfind: async (f, d) => {
      const q = String(d.get("q") || "").trim().replace(/^№/, "");
      if (!q) return;
      if (/^\d{1,7}$/.test(q)) {
        try { const r = await api(`/orders?q=${encodeURIComponent(q)}`); if (r.items[0]) return openOrder(r.items[0].id); toast(`№${q} buyurtma topilmadi`, true); } catch (e) { fail(e); }
        return;
      }
      clientQ = q; location.hash = "#/mijozlar"; render();
    },
    resend: async (el) => { el.disabled = true; try { const r = await api(`/orders/${el.dataset.id}/resend`, { method: "POST" }); toast(r.ok ? "iBox'ga yuborildi" : "Yana xato: " + (r.error || ""), !r.ok); render(); } catch (e) { fail(e); el.disabled = false; } },
    order: (el) => openOrder(el.dataset.id).catch(fail),
    client: (el) => openClient(el.dataset.id).catch(fail),
    chatwith: (el) => { chatClient = Number(el.dataset.id); closeDrawer(); location.hash = "#/chat"; },
    csearch: (f, d) => { clientQ = d.get("q").trim(); render(); },
    csave: async (f, d) => { try { await api(`/clients/${f.dataset.id}`, { method: "POST", body: Object.fromEntries(d) }); toast("Saqlandi"); openClient(f.dataset.id); } catch (e) { fail(e); } },
    psearch: (f, d) => { prodQ = d.get("q").trim(); prodFilter = d.get("filter"); render(); },
    psave: async (el) => {
      const id = el.dataset.id, body = {};
      document.querySelectorAll(`[data-id="${id}"][data-f]`).forEach((i) => (body[i.dataset.f] = i.value));
      try { await api(`/products/${id}`, { method: "POST", body }); toast("Saqlandi"); } catch (e) { fail(e); }
    },
    accept: async () => { try { const r = await api("/products/accept-suggestions", { method: "POST", body: {} }); toast(`${r.updated} ta tovarga karobka soni qo'yildi`); render(); } catch (e) { fail(e); } },
    bulk: async (f, d) => { try { const r = await api("/products/box-bulk", { method: "POST", body: { text: d.get("text") } }); toast(`${r.updated} ta tovar yangilandi${r.missing_count ? `, ${r.missing_count} ta topilmadi: ${r.missing.slice(0, 5).join(", ")}` : ""}`, !!r.missing_count && !r.updated); render(); } catch (e) { fail(e); } },
    bsave: async (f, d) => {
      const body = Object.fromEntries(d);
      body.active = d.get("active") === "on";
      for (const k of ["starts_at", "ends_at"]) body[k] = body[k] ? new Date(body[k]).toISOString() : null;
      const file = d.get("image");
      delete body.image;
      try {
        if (file && file.size) body.image = await readImage(file, 1200);
        if (bannerEdit?.id) { body.id = bannerEdit.id; body.image_id = bannerEdit.image_id; }
        await api("/banners", { method: "POST", body }); bannerEdit = null; toast("Saqlandi"); render();
      } catch (e) { fail(e); }
    },
    bnew: () => { bannerEdit = null; render(); },
    bedit: async (el) => { const d = await api("/banners"); bannerEdit = d.items.find((x) => String(x.id) === el.dataset.id); render(); },
    bdel: async (el) => { if (!twice("bdel" + el.dataset.id, "O'chirish uchun yana bir marta bosing")) return; try { await api(`/banners/${el.dataset.id}/delete`, { method: "POST" }); render(); } catch (e) { fail(e); } },
    cmpsave: async (f, d) => { try { await api(`/complaints/${f.dataset.id}`, { method: "POST", body: Object.fromEntries(d) }); toast("Saqlandi, mijozga xabar yuborildi"); render(); } catch (e) { fail(e); } },
    pick: (el) => { chatClient = Number(el.dataset.id); document.querySelectorAll(".chat .list button").forEach((b) => b.classList.toggle("on", b === el)); loadConv().catch(fail); },
    send: async (f, d) => {
      const text = String(d.get("text") || "").trim(), file = d.get("image");
      if (!text && !(file && file.size)) return;
      const body = { text };
      try { if (file && file.size) body.image = await readImage(file); const r = await api(`/chats/${chatClient}`, { method: "POST", body }); if (!r.telegram) toast("Ilovaga yozildi (mijozning Telegram'i ulanmagan)"); await loadConv(); } catch (e) { fail(e); }
    },
    bcast: async (f, d) => {
      if (!twice("bcast", "Hammaga yuborish uchun yana bir marta bosing")) return;
      try { const r = await api("/broadcast", { method: "POST", body: { text: d.get("text"), link: d.get("link") } }); toast(`${r.sent} / ${r.recipients} mijozga yuborildi`); f.reset(); } catch (e) { fail(e); }
    },
    ssave: async (f, d) => {
      const body = { min_order_sum: d.get("min_order_sum"), new_days: d.get("new_days"), default_mode: d.get("default_mode"), usd_rate: d.get("usd_rate"), catalog_view: d.get("catalog_view"), catalog_tabs: d.get("catalog_tabs") };
      for (const k of ["ledger_enabled", "block_over_limit", "overdue_reminder", "new_arrivals_notify", "usd_rate_auto", "show_usd"]) body[k] = d.get(k) === "on";
      try { await api("/settings", { method: "POST", body }); toast("Saqlandi"); } catch (e) { fail(e); }
    },
    addadmin: async (f, d) => { try { await api("/admins", { method: "POST", body: Object.fromEntries(d) }); toast("Admin qo'shildi"); render(); } catch (e) { fail(e); } },
    stest: (f, d) => { searchTestQ = String(d.get("q") || "").trim(); render(); },
    synsave: async (f, d) => { try { await api("/synonyms", { method: "POST", body: { id: d.get("id"), words: d.get("words") } }); toast("Saqlandi"); render(); } catch (e) { fail(e); } },
    synnew: () => { const f = document.getElementById("synform"); f.elements.id.value = ""; f.elements.words.value = ""; },
    synedit: (el) => { const f = document.getElementById("synform"); f.elements.id.value = el.dataset.id; f.elements.words.value = el.dataset.words; f.scrollIntoView({ behavior: "smooth" }); f.elements.words.focus(); },
    synfrom: (el) => { const f = document.getElementById("synform"); f.elements.id.value = ""; f.elements.words.value = el.dataset.q + ", "; f.scrollIntoView({ behavior: "smooth" }); f.elements.words.focus(); },
    syndel: async (el) => { if (!twice("syndel" + el.dataset.id, "O'chirish uchun yana bir marta bosing")) return; try { await api(`/synonyms/${el.dataset.id}/delete`, { method: "POST" }); render(); } catch (e) { fail(e); } },
    seckind: (el) => { secKind = el.dataset.k; render(); },
    postnew: () => { postEdit = null; render(); },
    // Buyurtmalar ro'yxatini Excel ochadigan CSV qilib yuklab olish
    ocsv: () => {
      const rows = [["№", "Sana", "Mijoz", "Telefon", "Xil", "Summa", "Holat", "iBox №"],
        ...lastOrders.map((o) => [o.no, dt(o.created_at), o.client_name, o.phone || "", o.lines, Math.round(o.total), o.status_text, o.ibox_number || ""])];
      const csv = "\ufeff" + rows.map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(";")).join("\r\n");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
      a.download = `buyurtmalar-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    },
    postedit: async (el) => { const r = await api("/posts"); postEdit = r.items.find((p) => String(p.id) === el.dataset.id) || null; render(); window.scrollTo(0, 0); },
    postdel: async (el) => { if (!twice("postdel" + el.dataset.id, "O'chirish uchun yana bir marta bosing")) return; try { await api(`/posts/${el.dataset.id}/delete`, { method: "POST" }); toast("O'chirildi"); render(); } catch (e) { fail(e); } },
    postsave: async (f, d) => {
      const body = { title: d.get("title"), body: d.get("body"), products: d.get("products"),
        published: d.get("published") === "on", pinned: d.get("pinned") === "on", notify: d.get("notify") === "on",
        remove_image: d.get("remove_image") === "on",
        published_at: d.get("published_at") ? new Date(d.get("published_at")).toISOString() : null };
      const file = d.get("image");
      try {
        if (file && file.size) body.image = await readImage(file, 1280);
        if (postEdit?.id) { body.id = postEdit.id; body.image_id = postEdit.image_id; }
        const r = await api("/posts", { method: "POST", body });
        toast(`Saqlandi${r.products_asked ? ` · tovar: ${r.products_found}/${r.products_asked} topildi` : ""}${body.notify ? ` · Telegram: ${r.sent}` : ""}`, r.products_asked > r.products_found);
        postEdit = null; render();
      } catch (e) { fail(e); }
    },
  };
}
$root.addEventListener("change", (e) => {
  const k = e.target.dataset.change;
  if (k === "ofilter") { orderFilter = e.target.value; render(); }
  if (k === "cfilter") { cmpFilter = e.target.value; render(); }
  if (k === "sechide") {
    api("/sections", { method: "POST", body: { kind: e.target.dataset.kind, key: e.target.dataset.key, hidden: !e.target.checked } })
      .then(() => { toast(e.target.checked ? "Ilovada ko'rinadi" : "Ilovada yashirildi"); render(); }).catch(fail);
  }
});
window.addEventListener("hashchange", render);
render();
