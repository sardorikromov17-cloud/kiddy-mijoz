// Ilova sozlamalari. API_URL — Supabase'dagi "api" funksiyasining manzili.
// Masalan: https://abcdefgh.supabase.co/functions/v1/api
window.KIDDY_CONFIG = {
  API_URL: "https://YOUR-PROJECT.supabase.co/functions/v1/api",
  COMPANY: "Kiddy Toys",
  // Android ilovasi (APK) havolasi. GitHub Actions har safar shu manzilga yangi versiyani qo'yadi:
  // https://github.com/USERNAME/REPO/releases/latest/download/kiddy-toys.apk
  ANDROID_APK_URL: "",
};
