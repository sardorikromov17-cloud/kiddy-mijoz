import type { CapacitorConfig } from "@capacitor/cli";

// Ilova GitHub Pages'dagi sahifani ochadi — sahifa yangilansa, ilova ham darhol yangilanadi.
// APP_URL ni GitHub Actions o'zi beradi: https://USERNAME.github.io/REPO/
const appUrl = process.env.APP_URL || "https://example.github.io/kiddy-mijoz/";
const host = new URL(appUrl).host;

const config: CapacitorConfig = {
  appId: "uz.kiddytoys.mijoz",
  appName: "Kiddy Toys",
  webDir: "www",
  server: {
    url: appUrl,
    androidScheme: "https",
    errorPath: "offline.html", // internet bo'lmasa shu sahifa chiqadi
    allowNavigation: [host, "*.supabase.co"],
  },
  android: {
    backgroundColor: "#3D4FE0",
  },
  plugins: {
    SplashScreen: { launchShowDuration: 800, backgroundColor: "#3D4FE0", showSpinner: false },
    StatusBar: { backgroundColor: "#F4F6FB", style: "LIGHT", overlaysWebView: false },
  },
};

export default config;
