# Kiddy Toys — mijozlar buyurtma ilovasi (1-bosqich)

Ulgurji mijozlar telefonidan katalogni ko'radi (har bir tovarni **karobka yoki dona** bilan), tovarni nomi yoki shtrix-kodi bo'yicha topadi, savatga soladi va buyurtma beradi. Buyurtma **to'g'ridan-to'g'ri iBox'ga** "kutilmoqda" holatida tushadi. Menejer uni iBox'da tasdiqlaydi.

**Mijoz ilovasida:** Telegram orqali kirish (bir marta), bosh menyu, aksiya bannerlari, "Tez-tez oladiganlarim", katalog (qidiruv, kategoriyalar, ❤ sevimlilar, 🔥 aksiya, 🆕 yangi), shtrix-kod skaneri, tovar kartochkasi (karobka + dona, "Kelganda xabar ber"), savat (minimal summa, kredit limiti), buyurtma va uni takrorlash, **oldi-berdi** (qarz, muddati o'tgan qarz, akt-sverka PDF), **menejer bilan chat**, **qaytarish/shikoyat** (rasm bilan).
**Telegram xabarlari:** kirish kodi, buyurtma qabul qilindi / tasdiqlandi / jo'natildi / bekor qilindi, tovar keldi, yangi tovarlar (kuniga 1 marta), muddati o'tgan qarz (haftada 1 marta), menejer javobi, akt-sverka PDF.
**Admin panel** (`/admin/`): statistika, buyurtmalar, mijozlar (limit, boshlang'ich qoldiq), tovarlar (karobka soni, aksiya belgisi, Excel'dan ko'chirish), bannerlar, shikoyatlar, chat, qidiruv tahlili, hammaga xabar, sozlamalar.
**Keyingi bosqich:** shafyor ilovasi va xaritada kuzatish.

```
supabase/
  migrations/…sql      ← baza jadvallari
  functions/api        ← ilova uchun API (kirish, katalog, buyurtma)
  functions/ibox-sync  ← iBox'dan tovar, narx, qoldiq va mijozlarni olib keladi; buyurtmalarni qayta yuboradi
  functions/tg-bot     ← Telegram bot (kirish kodlari, menejerlar guruhi bilan chat)
  functions/admin      ← admin panel API
  cron.sql             ← har 5 daqiqada avtomatik sinxronlash
web/                   ← ilovaning o'zi (GitHub Pages; iPhone shu havola orqali ishlaydi)
web/admin/             ← admin panel (kompyuterda ishlatiladi)
mobile/                ← Android ilova (Capacitor 8) — web/ saytini ochadi, ML Kit skaneri bilan
.github/workflows/     ← GitHub'da avtomatik: sayt joylash + APK yig'ish
dev/                   ← sinov uchun soxta iBox va yordamchi fayllar
```

## Qanday ishlaydi

```
iBox ──(har 5 daqiqa)──▶ ibox-sync ──▶ Supabase bazasi ◀── api ◀── Mijoz telefoni (web/)
  ▲                                                          │
  └──────────────── buyurtma (POST document/order) ──────────┘
Telegram bot ── mijoz raqamini bog'laydi, kirish kodini yuboradi
```

- Mijoz faqat **iBox'dagi telefon raqami** bilan kira oladi (`main_phone` ning oxirgi 9 raqami solishtiriladi).
- Narxni har doim server bazadan oladi — telefondan kelgan narxga ishonilmaydi.
- iBox vaqtincha ishlamasa, buyurtma yo'qolmaydi: `ibox-sync` uni keyin qayta yuboradi (5 martagacha).
- iBox'da ilova buyurtmalari **`M-1`, `M-2`…** raqami va "Mobil ilova №…" izohi bilan ko'rinadi.

---

## O'rnatish

Eng oson yo'l — o'rnatish yordamchisi: `ORNATISH.bat` (Windows) yoki `./ornatish.sh`. U quyidagi 1–7 qadamlarning deyarli hammasini o'zi bajaradi. Qisqa yo'riqnoma — `BOSHLASH.md`. Quyida — qo'lda o'rnatish.

Kompyuterda [Node.js](https://nodejs.org) o'rnatilgan bo'lishi kerak. Supabase CLI'ni `npx supabase` orqali ishlatamiz.

### 1. Supabase loyihasi

Xodimlar bo'limi uchun ochilgan loyihani ishlatsa bo'ladi. Jadvallar alohida `mijoz` sxemasida turadi, xodimlar ma'lumotlariga tegmaydi.

1. Supabase → **SQL Editor** → `supabase/migrations/` dagi **uchala** faylni tartib bilan (`…0001…`, `…0002…`, `…0003…`) qo'yib, **Run** bosing.
   So'ng o'zingizni admin qilib qo'shing (raqamning oxirgi 9 raqami):
   ```sql
   insert into mijoz.admins (phone_key, name) values ('901234567', 'Ikromov');
   ```
2. Terminalda shu papkada:
   ```bash
   npx supabase login
   npx supabase link --project-ref LOYIHA_ID
   ```

### 2. Telegram bot

1. Telegram'da **@BotFather** → `/newbot` → nom bering, masalan `Kiddy Toys buyurtma`, username: `KiddyToysOrderBot`.
2. BotFather bergan **tokenni** hech kimga yubormang. Uni keyingi qadamda o'zingiz Secrets'ga kiritasiz.

### 3. Sozlamalar (Secrets)

Supabase → **Edge Functions → Secrets** bo'limiga quyidagilarni qo'shing:

| Nomi | Qiymati |
|---|---|
| `IBOX_BASE_URL` | `https://kiddytoys.ibox.io` |
| `IBOX_TOKEN` | iBox'da yaratilgan API token **(maxfiy)** |
| `IBOX_FILIAL_ID` | filial raqami, masalan `1` |
| `IBOX_PRICE_TYPE_ID` | ulgurji narx turi raqami (4-qadamda topamiz) |
| `IBOX_WAREHOUSE_ID` | buyurtma qaysi ombordan chiqadi (4-qadamda topamiz) |
| `IBOX_CURRENCY_ID` | so'm valyutasining raqami (odatda `1`) |
| `IBOX_RESERVE` | `1` — buyurtma tushganda tovar band qilinsin, `0` — yo'q |
| `SYNC_SECRET` | istalgan uzun tasodifiy so'z, masalan 40 ta harf/raqam **(maxfiy)** |
| `TELEGRAM_BOT_TOKEN` | BotFather bergan token **(maxfiy)** |
| `TELEGRAM_BOT_USERNAME` | `KiddyToysOrderBot` (@ belgisiz) |
| `TELEGRAM_WEBHOOK_SECRET` | yana bitta tasodifiy so'z **(maxfiy)** |
| `ALLOWED_ORIGINS` | ilova manzili, masalan `https://ikromov.github.io` |
| `MANAGER_PHONE` | menejer telefoni, masalan `+998 90 000 00 00` |
| `MANAGER_CHAT_ID` | menejerlar Telegram guruhining raqami (6-qadamda topamiz), masalan `-1001234567890` |
| `APP_URL` | ilova manzili, masalan `https://ikromov.github.io/kiddy-mijoz/` (xabarlardagi tugmalar uchun) |

> ⚠️ `DEV_MODE` ni haqiqiy ishda **qo'shmang**. U faqat sinov uchun: kirish kodini ekranga chiqarib yuboradi.

### 4. Funksiyalarni o'rnatish

```bash
npx supabase functions deploy api ibox-sync tg-bot admin --no-verify-jwt
```

iBox'dagi narx turlari, omborlar va valyutalar ro'yxatini ko'rish (`SYNC_SECRET` o'rniga o'zingiznikini qo'ying):

```bash
curl -X POST https://LOYIHA_ID.supabase.co/functions/v1/ibox-sync \
  -H "Authorization: Bearer SYNC_SECRET" -d '{"show":"directories"}'
```

Chiqqan ro'yxatdan kerakli `id` larni topib, `IBOX_PRICE_TYPE_ID`, `IBOX_WAREHOUSE_ID` va `IBOX_CURRENCY_ID` ga yozing.

### 5. Birinchi sinxronlash

```bash
curl -X POST https://LOYIHA_ID.supabase.co/functions/v1/ibox-sync \
  -H "Authorization: Bearer SYNC_SECRET" -d '{}'
```

Javobda har bir qadam uchun `"ok": true` va soni chiqishi kerak. So'ng Supabase → **Table Editor → mijoz.products** da tovarlar, narx (`price`) va qoldiq (`stock`) borligini tekshiring.

**Agar narx yoki qoldiq bo'sh bo'lsa:** iBox hujjatida `stock/selection` javobining shakli ko'rsatilmagan, shuning uchun eng ko'p uchraydigan maydon nomlarini tekshiradigan qilib yozdim. Bunday holda `{"show":"directories"}` javobidagi `stock_sample` qatorini menga yuboring, men moslab beraman.

Keyin **avtomatik sinxronlash**: `supabase/cron.sql` faylidagi `LOYIHA_ID` va `SYNC_SECRET` ni almashtirib, SQL Editor'da bajaring.

### 6. Telegram botni ulash

Brauzerda quyidagi manzilni oching (3 joyni almashtiring):

```
https://api.telegram.org/botTELEGRAM_BOT_TOKEN/setWebhook?url=https://LOYIHA_ID.supabase.co/functions/v1/tg-bot&secret_token=TELEGRAM_WEBHOOK_SECRET
```

`"ok":true` chiqsa tayyor. Botga `/start` yozib, **o'z raqamingizni yuboring** — bot sizni admin sifatida ulaydi.

**Menejerlar guruhi** (mijoz xabarlari va shikoyatlari shu yerga keladi):
1. Telegram'da guruh oching (masalan "Kiddy — mijozlar"), menejerlarni va botni qo'shing.
2. Guruhda `/id` yozing — bot guruh raqamini yuboradi. Uni Secrets'dagi `MANAGER_CHAT_ID` ga yozing.
3. Mijoz yozgan xabarga **Reply (Javob berish)** qilib yozsangiz, javob mijozning ilovasiga va Telegram'iga boradi. Javobni admin paneldagi Chat bo'limidan ham yozish mumkin.

### 7. GitHub'ga yuklash — sayt va Android ilova o'zi yig'iladi

Shu papkaning **hammasini** (`.github` yashirin papkasi bilan birga) bitta GitHub repozitoriyga yuklang, masalan `kiddy-mijoz`.

1. `web/config.js` faylida `API_URL` ni o'zgartiring: `https://LOYIHA_ID.supabase.co/functions/v1/api`.
2. **Imzo kaliti** (Android yangilanishlari uchun shart): alohida yuborilgan `android-imzo-kaliti.zip` ichidagi `GITHUB_SECRETS.txt` ni oching. Undagi 4 ta qiymatni GitHub → repozitoriy → **Settings → Secrets and variables → Actions → New repository secret** ga birma-bir qo'shing. Kalit faylini va shu matnni fleshkada saqlang: kalit yo'qolsa, ilovani yangilab bo'lmaydi.
3. GitHub → **Settings → Pages → Source: GitHub Actions** ni tanlang.
4. `main` tarmog'iga push qiling. **Actions** bo'limida ikkita ish ko'rinadi:
   - **Sayt (GitHub Pages)** — 1–2 daqiqada ilova `https://USERNAME.github.io/REPO/` manzilida ochiladi;
   - **Android APK** — 5–10 daqiqada APK tayyor bo'lib, **Releases** bo'limida paydo bo'ladi.
5. Sayt manzilini (`https://USERNAME.github.io`) Supabase Secrets'dagi `ALLOWED_ORIGINS` ga yozing.

Android ilovaning doimiy yuklab olish havolasi (mijozlarga shuni yuborasiz):

```
https://github.com/USERNAME/REPO/releases/latest/download/kiddy-toys.apk
```

Bu havola Android telefondan brauzerda kirgan mijozlarga ham avtomatik ko'rsatiladi ("Android ilovasini yuklab oling").

**Yangilanishlar qanday ishlaydi:**
- `web/` dagi har qanday o'zgarish (dizayn, yangi bo'lim) push qilingandan keyin **darhol** ham iPhone havolasida, ham Android ilovada ko'rinadi. APK'ni qayta o'rnatish shart emas, chunki Android ilova shu saytni ochadi.
- `mobile/` o'zgarsa (ikonka, ilova nomi, yangi Android imkoniyati), yangi APK yig'iladi. Mijozlar uni o'sha havoladan yuklab, eskisining ustidan o'rnatadi.

### 8. Telefonga o'rnatish (mijozlarga yuboriladigan yo'riqnoma)

- **Android:** APK havolasini oching → yuklab olingan faylni bosing → **"O'rnatish"**. Telefon "noma'lum manbadan o'rnatish"ga ruxsat so'rasa, ruxsat bering (Play Market'da bo'lmagani uchun shunday so'raydi). Android ilovada skaner Google ML Kit orqali ishlaydi: tezroq va xira kodlarni ham o'qiydi.
- **iPhone (Safari):** havolani oching → pastdagi **Ulashish** tugmasi → **"Bosh ekranga qo'shish"**.

Birinchi kirishda ilova Telegram botni ochishni so'raydi. **Bir marta kirgandan keyin qayta kod so'ralmaydi** — ilova o'zi kirib ketadi. Ilovadan 90 kun umuman foydalanilmasa yoki «Chiqish» bosilsa, qayta kod bilan kiriladi.

> iPhone'da: avval **bosh ekranga qo'shing, keyin ikonka orqali ochib kiring**. Safari va bosh ekrandagi ilova kirishni alohida saqlaydi.

Telegram orqali kirish: Mijoz botda **"Raqamimni yuborish"** ni bosadi, so'ng ilovaga qaytib **"Kod olish"** ni bosadi. Kod Telegram'ga keladi.

---

## Karobka va dona

Savdo ulgurji bo'lgani uchun karobkasi bor har bir tovarda **Karobka | Dona** tanlovi bor. Karobka tanlanganda "3" yozilsa — 3 karobka, ya'ni karobkadagi son × 3 dona. Katalog, tovar sahifasi, savat, skaner (1 skaner = 1 karobka) va buyurtma tarixida karobkalar ko'rinadi. **iBox'ga har doim dona hisobida yuboriladi** (narx iBox'da 1 dona uchun turadi), menejerga va mijozga esa "12 karobka + 5 dona (293 dona)" ko'rinishida.

Karobkadagi dona soni qayerdan olinadi (shu tartibda):
1. Admin panelda **qo'lda kiritilgani**;
2. **iBox ma'lumotidan** — tovar ma'lumotida karobka/qadoq soni bo'lsa, avtomatik olinadi;
3. **Tovar nomidan taklif** (masalan "Kubik 1/48", "24 dona/karobka") — faqat admin "tasdiqlash"ni bosgandan keyin ishlatiladi.

Birinchi sinxronlashdan keyin admin panel → Tovarlar → filtr "Karobka soni yo'q" ni oching: iBox'dan kelmaganlarini qo'lda yoki Excel'dan to'ldirasiz. Agar iBox'da karobka soni bor-u, ilova uni ko'rmayotgan bo'lsa — Sozlamalar → "iBox javob namunalari" dagi `sample_product` va `stock_sample` ni menga yuboring, moslab beraman.

Ilova ochilganda qaysi birlik tanlangan turishi — Sozlamalar → "Ilovada birinchi tanlangan birlik" (standart: Karobka).

## Admin panel

Manzil: `https://USERNAME.github.io/REPO/admin/` — telefon raqamingizni kiritasiz, 6 xonali kod Telegram botga keladi.

- **Karobkada nechta dona** — iBox API buni bermaydi. Admin panel → Tovarlar: har biriga yozing yoki **Excel'dan ikki ustunni (artikul/shtrix-kod va son) nusxalab** "Karobka sonini Excel'dan ko'chirib qo'yish" maydoniga qo'ying.
- **Aksiya** — Tovarlar bo'limida aksiya belgisi (`-15%`) va eski narx; Bannerlar bo'limida bosh sahifadagi rangli banner (rasm, muddat, bosilganda kategoriya/tovar ochiladi). Hammaga e'lon — "Xabar yuborish".
- **Minimal buyurtma summasi** — Sozlamalarda umumiy, Mijozlar bo'limida har bir mijozga alohida.
- **Logotip** — `web/icons/` dagi fayllar vaqtinchalik. Asl logotipni yuborsangiz, almashtirib beraman.

## Oldi-berdi (qarz) ni yoqish

iBox'da mijoz balansini beradigan API yo'q, shuning uchun qarz quyidagicha hisoblanadi: **boshlang'ich qoldiq + iBox'dagi jo'natmalar − to'lovlar − qaytarishlar** (har 5 daqiqada yangilanadi). Qoralama va bekor qilingan hujjatlar hisobga olinmaydi.

1. Admin panel → **Mijozlar** → har bir mijozni ochib, iBox'dagi akt-sverkadan **boshlang'ich qoldiq va sanani** kiriting (masalan, 01.11.2026 holatiga qarz). Kredit limiti va kredit muddatini ham shu yerda ko'rasiz.
2. Sinxronlash o'sha sanadan keyingi hujjatlarni olib keladi. **Bir nechta mijozning qarzini iBox bilan solishtiring.**
3. Mos kelsa — Sozlamalar → "Oldi-berdi bo'limini mijozlarga ko'rsatish" ni yoqing. Shundan keyin mijozlarda qarz kartasi, hujjatlar, akt-sverka, kredit limiti tekshiruvi va qarz eslatmasi ishlaydi.

**Muhim:** iBox hujjatida jo'natma/to'lov/qaytarish ro'yxatlarining javob shakli ko'rsatilmagan, shuning uchun keng tarqalgan maydon nomlarini tekshiradigan qilib yozdim. Qarz iBox bilan mos kelmasa, admin panel → Sozlamalar → "iBox javob namunalari" ni oching va matnini menga yuboring — moslab beraman.

## Holatni tekshirish

```sql
select key, value, updated_at from mijoz.sync_state order by key;               -- oxirgi sinxronlash, xatolar
select no, status, ibox_number, ibox_error, created_at from mijoz.orders order by created_at desc limit 20;
```

`status`: `sent` — iBox'ga yetib bordi; `failed` — xato (`ibox_error` ga qarang), avtomatik qayta yuboriladi.

## Kompyuterda sinash (dasturchi uchun)

```bash
# Postgres (port 54322) ishlab turishi kerak; jadvallarni yarating:
psql -h localhost -p 54322 -U postgres -f supabase/migrations/20261120000001_mijozlar_ilovasi.sql
set -a; . dev/.env.test; set +a
deno run -A dev/mock-ibox.ts &                                         # soxta iBox :8787
PORT=8001 deno run -A dev/serve.ts supabase/functions/ibox-sync/index.ts &
PORT=8002 deno run -A dev/serve.ts supabase/functions/api/index.ts &
PORT=8004 deno run -A dev/serve.ts supabase/functions/admin/index.ts &
deno run -A dev/mock-telegram.ts &                                     # soxta Telegram :8788 (yuborilganlar: /_sent)
curl -X POST localhost:8001 -H "Authorization: Bearer sync-secret" -d '{}'
python3 -m http.server 8090 -d web    # config.js da API_URL=http://localhost:8002/functions/v1/api
```

Sinov rejimida (`DEV_MODE=1`) kirish kodi ekranda ko'rinadi. Sinov raqami: `90 123 45 67`, admin: `93 555 44 33` (`insert into mijoz.admins (phone_key, name) values ('935554433', 'Sinov');`).
