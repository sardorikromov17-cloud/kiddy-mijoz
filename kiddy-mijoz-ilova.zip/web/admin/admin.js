// Kiddy Toys admin panel
const CFG = window.KIDDY_CONFIG || {};
const API = (CFG.API_URL || "").replace(/\/+$/, "");
const ADMIN = API.replace(/\/api$/, "/admin");
const fileUrl = (rel) => (rel ? `${API}/${rel}` : "");

const $root = document.getElementById("root");
const $toast = document.getElementById("toast");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => (n == null || n === "" ? "—" : Math.round(Number(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " "));
const dt = (iso) => { if (!iso) return "—"; const d = new Date(iso); return d.toLocaleDateString("ru-RU") + " " + d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }); };
// datetime-local maydon uchun mahalliy vaqt
const toLocalInput = (iso) => { if (!iso) return ""; const d = new Date(iso); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };
const ago = (iso) => {
  if (!iso) return "hech qachon";
  const m = Math.round((Date.now() - new Date(iso)) / 60000);
  if (m < 2) return "hozir"; if (m < 60) return `${m} daq oldin`;
  const h = Math.round(m / 60); if (h < 24) return `${h} soat oldin`;
  return `${Math.round(h / 24)} kun oldin`;
};
let toastT;
const toast = (t, bad = false) => { $toast.textContent = t; $toast.className = "toast" + (bad ? " bad" : ""); $toast.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => ($toast.hidden = true), 2800); };

const store = {
  get token() { try { return JSON.parse(localStorage.getItem("kt_admin_token")); } catch { return null; } },
  set token(v) { v ? localStorage.setItem("kt_admin_token", JSON.stringify(v)) : localStorage.removeItem("kt_admin_token"); },
  get name() { return localStorage.getItem("kt_admin_name") || ""; },
  set name(v) { localStorage.setItem("kt_admin_name", v || ""); },
};

async function api(path, { method = "GET", body } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (store.token) headers.Authorization = `Bearer ${store.token}`;
  let res;
  try { res = await fetch(ADMIN + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }); }
  catch { throw new Error("Internet aloqasi yo'q"); }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { store.token = null; render(); throw new Error(data.message || "Qayta kiring"); }
  if (!res.ok) throw Object.assign(new Error(data.message || "Xatolik"), { data });
  return data;
}
const fail = (e) => toast(e.message || "Xatolik", true);

/** Rasmni brauzerda kichraytirib, data URL qilib qaytaradi */
function readImage(file, max = 1280) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => reject(new Error("Rasmni o'qib bo'lmadi"));
    img.src = URL.createObjectURL(file);
  });
}

// ---------- hodisalar ----------
let actions = {};
$root.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (el && actions[el.dataset.act]) { e.preventDefault(); actions[el.dataset.act](el, e); }
});
$root.addEventListener("submit", (e) => {
  const fn = actions[e.target.dataset.submit];
  if (fn) { e.preventDefault(); fn(e.target, new FormData(e.target)); }
});
let armed = { key: "", at: 0 };
const twice = (key, msg) => { if (armed.key === key && Date.now() - armed.at < 3000) { armed = { key: "", at: 0 }; return true; } armed = { key, at: Date.now() }; toast(msg); return false; };

// ---------- kirish ----------
function viewLogin() {
  const st = { step: "phone", phone: "", err: "", dev: "" };
  const draw = () => {
    $root.innerHTML = `<div class="login"><form class="card" data-submit="${st.step}">
      <div class="row"><img src="../icons/logo.svg" width="44" height="44" alt=""><div><h1 style="font-size:20px">Kiddy Toys</h1><span class="muted">Admin panel</span></div></div>
      ${st.step === "phone" ? `
        <label class="f">Telefon raqam<input class="input" name="phone" inputmode="tel" placeholder="90 123 45 67" value="${esc(st.phone)}" required autofocus></label>
        <span class="muted small">Kod Telegram botga keladi. Raqamingiz adminlar ro'yxatida bo'lishi va botga ulangan bo'lishi kerak.</span>
        <button class="btn">Kod olish</button>`
      : `<label class="f">Telegram'ga kelgan 6 xonali kod<input class="input" name="code" inputmode="numeric" maxlength="6" required autofocus style="letter-spacing:8px;font-size:20px;text-align:center"></label>
        ${st.dev ? `<span class="pill amber">Sinov rejimi: ${esc(st.dev)}</span>` : ""}
        <button class="btn">Kirish</button><button type="button" class="btn soft" data-act="back">Raqamni o'zgartirish</button>`}
      ${st.err ? `<div class="err">${esc(st.err)}</div>` : ""}
    </form></div>`;
  };
  actions = {
    phone: async (f, d) => { st.phone = d.get("phone"); st.err = ""; try { const r = await api("/auth/request", { method: "POST", body: { phone: st.phone } }); st.dev = r.dev_code || ""; st.step = "code"; } catch (e) { st.err = e.message; } draw(); },
    code: async (f, d) => { try { const r = await api("/auth/verify", { method: "POST", body: { phone: st.phone, code: d.get("code") } }); store.token = r.token; store.name = r.admin.name; location.hash = "#/"; render(); } catch (e) { st.err = e.message; draw(); } },
    back: () => { st.step = "phone"; draw(); },
  };
  draw();
}

// ---------- karkas ----------
const NAV = [
  ["/", "Bosh panel"], ["/buyurtmalar", "Buyurtmalar"], ["/mijozlar", "Mijozlar"], ["/tovarlar", "Tovarlar"],
  ["/bannerlar", "Aksiya bannerlari"], ["/shikoyatlar", "Qaytarish / shikoyat"], ["/chat", "Chat"],
  ["/bolimlar", "Katalog bo'limlari"], ["/qidiruv", "Qidiruv va sinonimlar"], ["/xabar", "Xabar yuborish"], ["/sozlamalar", "Sozlamalar"],
];
let badges = { chat: 0, cmp: 0 };
function shell(path, inner) {
  $root.innerHTML = `<div class="layout">
    <nav class="side" aria-label="Bo'limlar">
      <div class="brand"><img src="../icons/logo.svg" width="34" height="34" alt="">Kiddy Toys</div>
      ${NAV.map(([p, t]) => {
        const n = p === "/chat" ? badges.chat : p === "/shikoyatlar" ? badges.cmp : 0;
        return `<a href="#${p}" class="${path === p ? "on" : ""}">${t}${n ? `<span class="cnt">${n}</span>` : ""}</a>`;
      }).join("")}
      <div class="foot">${esc(store.name)}<br><button data-act="logout">Chiqish</button></div>
    </nav>
    <main class="main" id="main">${inner}</main></div>`;
}
const main = () => document.getElementById("main");
const loading = '<div class="empty">Yuklanmoqda…</div>';
const statusPill = (s, t) => `<span class="pill ${{ failed: "red", new: "amber", cancelled: "red", delivered: "green", shipped: "green", accepted: "", sent: "gray" }[s] ?? ""}">${esc(t)}</span>`;

// ---------- bosh panel ----------
async function viewDash() {
  const d = await api("/stats");
  badges = { chat: d.unread_messages, cmp: d.open_complaints };
  const syncLine = (k, label) => {
    const ok = d.sync[`last_ok_${k}`], er = d.sync[`last_error_${k}`];
    const bad = er && (!ok || new Date(er.at) > new Date(ok.at));
    return `<tr><td>${label}</td><td>${bad ? `<span class="pill red">Xato</span> <span class="small">${esc(er.value)}</span>` : ok ? `<span class="pill green">OK</span> ${ago(ok.value)}` : '<span class="pill gray">hali yo\'q</span>'}</td></tr>`;
  };
  return `<h1>Bosh panel</h1>
    <div class="kpis">
      <div class="kpi"><span>Bugun</span><b>${d.orders.today_n} ta</b><span>${fmt(d.orders.today_sum)} so'm</span></div>
      <div class="kpi"><span>7 kun</span><b>${d.orders.week_n} ta</b><span>${fmt(d.orders.week_sum)} so'm</span></div>
      <div class="kpi"><span>30 kun</span><b>${d.orders.month_n} ta</b><span>${fmt(d.orders.month_sum)} so'm</span></div>
      <div class="kpi"><span>Faol mijozlar (7 kun)</span><b>${d.clients.active_7d}</b><span>jami ${d.clients.total}, ilovada ${d.clients.ever}, Telegram ${d.clients.linked}</span></div>
      <a class="kpi" href="#/chat"><span>O'qilmagan xabarlar</span><b>${d.unread_messages}</b></a>
      <a class="kpi" href="#/shikoyatlar"><span>Yangi shikoyatlar</span><b>${d.open_complaints}</b></a>
    </div>
    ${d.failed_orders.length ? `<div class="card" style="border:2px solid var(--red-soft)"><h2>⚠️ iBox'ga yetib bormagan buyurtmalar</h2>
      ${d.failed_orders.map((o) => `<div class="row" style="margin-top:8px"><b>№${o.no}</b><span class="small muted grow">${esc(o.ibox_error || "kutilmoqda")}</span><button class="btn sm" data-act="resend" data-id="${o.id}">Qayta yuborish</button></div>`).join("")}</div>` : ""}
    <div class="grid2">
      <div class="tbl-wrap"><table><thead><tr><th>Top tovarlar (30 kun)</th><th class="num">Dona</th><th class="num">Summa</th></tr></thead><tbody>
        ${d.top_products.map((p) => `<tr><td>${esc(p.name)}</td><td class="num">${fmt(p.qty)}</td><td class="num">${fmt(p.total)}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">Hali buyurtma yo\'q</td></tr>'}</tbody></table></div>
      <div class="tbl-wrap"><table><thead><tr><th>Eng faol mijozlar (30 kun)</th><th class="num">Buyurtma</th><th class="num">Summa</th></tr></thead><tbody>
        ${d.top_clients.map((c) => `<tr class="click" data-act="client" data-id="${c.client_id}"><td>${esc(c.name)}</td><td class="num">${c.n}</td><td class="num">${fmt(c.total)}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">—</td></tr>'}</tbody></table></div>
    </div>
    <div class="tbl-wrap"><table><thead><tr><th>iBox sinxronlash</th><th>Holat</th></tr></thead><tbody>
      ${syncLine("products", "Tovarlar")}${syncLine("stock", "Narx va qoldiq")}${syncLine("clients", "Mijozlar")}${syncLine("ledger", "Oldi-berdi hujjatlari")}${syncLine("order_status", "Buyurtma holatlari")}${syncLine("orders", "Buyurtmalarni yuborish")}
    </tbody></table></div>`;
}

// ---------- buyurtmalar ----------
let orderFilter = "";
async function viewOrders() {
  const d = await api(`/orders${orderFilter ? "?status=" + orderFilter : ""}`);
  const opts = [["", "Hammasi"], ["sent", "iBox'da"], ["accepted", "Tasdiqlangan"], ["shipped", "Jo'natilgan"], ["failed", "Xato"], ["cancelled", "Bekor"]];
  return `<div class="row between"><h1>Buyurtmalar</h1>
      <select class="input" data-change="ofilter">${opts.map(([v, t]) => `<option value="${v}" ${v === orderFilter ? "selected" : ""}>${t}</option>`).join("")}</select></div>
    <div class="tbl-wrap"><table><thead><tr><th>№</th><th>Sana</th><th>Mijoz</th><th class="num">Xil</th><th class="num">Summa</th><th>Holat</th><th>iBox</th></tr></thead><tbody>
    ${d.items.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td><b>${o.no}</b></td><td>${dt(o.created_at)}</td><td>${esc(o.client_name)}</td>
      <td class="num">${o.lines}</td><td class="num">${fmt(o.total)}</td><td>${statusPill(o.status, o.status_text)}</td><td class="small muted">${o.ibox_number ? "№" + esc(o.ibox_number) : esc(o.ibox_error || "")}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Buyurtma yo\'q</td></tr>'}
    </tbody></table></div>`;
}
async function openOrder(id) {
  const o = await api(`/orders/${id}`);
  drawer(`<div class="row between"><h1>Buyurtma №${o.no}</h1><button class="btn soft sm" data-act="close">Yopish</button></div>
    <div class="card stack"><div class="row between"><b>${esc(o.client_name)}</b>${statusPill(o.status, o.status_text)}</div>
      <span class="muted">${esc(o.phone || "")} · ${dt(o.created_at)}${o.ibox_number ? ` · iBox №${esc(o.ibox_number)}` : ""}</span>
      ${o.comment ? `<span>Izoh: ${esc(o.comment)}</span>` : ""}${o.ibox_error ? `<span class="err">${esc(o.ibox_error)}</span>` : ""}
      ${["failed", "new"].includes(o.status) ? `<button class="btn" data-act="resend" data-id="${o.id}">iBox'ga qayta yuborish</button>` : ""}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th class="num">Miqdor</th><th class="num">Narx</th><th class="num">Summa</th></tr></thead><tbody>
      ${o.items.map((i) => `<tr><td>${esc(i.name)}</td><td class="num">${i.mode === "box" && i.box_qty ? `${Math.floor(i.qty / i.box_qty)} kar.${i.qty % i.box_qty ? ` + ${i.qty % i.box_qty}` : ""}<br><span class="small muted">${fmt(i.qty)} dona</span>` : `${fmt(i.qty)} dona`}</td><td class="num">${fmt(i.price)}</td><td class="num">${fmt(i.total)}</td></tr>`).join("")}
      <tr><td colspan="3"><b>Jami</b></td><td class="num"><b>${fmt(o.total)}</b></td></tr></tbody></table></div>`);
}

// ---------- mijozlar ----------
let clientQ = "";
async function viewClients() {
  const d = await api(`/clients?q=${encodeURIComponent(clientQ)}`);
  return `<div class="row between"><h1>Mijozlar</h1>
      <form data-submit="csearch" class="row"><input class="input" name="q" placeholder="Nomi, kodi yoki telefon" value="${esc(clientQ)}"><button class="btn soft">Qidirish</button></form></div>
    <div class="tbl-wrap"><table><thead><tr><th>Mijoz</th><th>Telefon</th><th>Telegram</th><th class="num">Balans</th><th class="num">Limit</th><th>Ilovaga kirgan</th><th class="num">Buyurtma</th></tr></thead><tbody>
    ${d.items.map((c) => `<tr class="click" data-act="client" data-id="${c.id}"><td><b>${esc(c.name)}</b><br><span class="small muted">${esc(c.code || "")}</span></td>
      <td>${esc(c.phone || "—")}</td><td>${c.telegram ? '<span class="pill green">ulangan</span>' : '<span class="pill gray">yo\'q</span>'}</td>
      <td class="num ${c.balance > 0 ? "pos" : c.balance < 0 ? "neg" : ""}">${fmt(c.balance)}</td><td class="num">${fmt(c.credit_limit)}</td>
      <td>${ago(c.last_seen)}</td><td class="num">${c.orders_n}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Topilmadi</td></tr>'}
    </tbody></table></div>`;
}
async function openClient(id) {
  const c = await api(`/clients/${id}`);
  const l = c.ledger;
  drawer(`<div class="row between"><h1 style="font-size:20px">${esc(c.name)}</h1><button class="btn soft sm" data-act="close">Yopish</button></div>
    <span class="muted">${esc(c.phone || "")} · kod ${esc(c.code || "—")} · Telegram: ${c.telegram ? "ulangan" : "yo'q"} · kredit muddati: ${c.credit_days ?? "—"} kun</span>
    ${l ? `<div class="kpis"><div class="kpi"><span>Balans</span><b class="${l.balance > 0 ? "pos" : "neg"}">${fmt(l.balance)}</b><span>${l.balance > 0 ? "qarz" : l.balance < 0 ? "haq (avans)" : ""}${l.parts && Math.abs(l.parts.usd) >= 0.01 ? ` · so'm ${fmt(l.parts.uzs)}, $${l.parts.usd}` : ""}</span></div>
      <div class="kpi"><span>Muddati o'tgan</span><b>${fmt(l.overdue)}</b><span>${l.overdue_since ? "eng eskisi " + l.overdue_since : ""}</span></div></div>` : ""}
    <form class="card stack" data-submit="csave" data-id="${c.id}"><h2>Limitlar va boshlang'ich qoldiq</h2>
      <div class="form">
        <label class="f">Kredit limiti, so'm<input class="input" name="credit_limit" inputmode="numeric" value="${c.credit_limit ?? ""}" placeholder="limitsiz"></label>
        <label class="f">Minimal buyurtma, so'm<input class="input" name="min_order_sum" inputmode="numeric" value="${c.min_order_sum ?? ""}" placeholder="umumiy sozlama"></label>
        <label class="f">Boshlang'ich qoldiq, so'm (+ qarz, − haq)<input class="input" name="opening_balance" inputmode="numeric" value="${c.opening_balance ?? 0}"></label>
        <label class="f">Boshlang'ich qoldiq, dollar<input class="input" name="opening_balance_usd" inputmode="decimal" value="${c.opening_balance_usd ?? 0}"></label>
        <label class="f">Qaysi sanadan<input class="input" type="date" name="opening_balance_date" value="${c.opening_balance_date ? String(c.opening_balance_date).slice(0, 10) : ""}"></label>
      </div>
      <span class="small muted">Boshlang'ich qoldiq — iBox'dagi shu sanadagi qarz (akt-sverkadan). Undan keyingi jo'natma, to'lov va qaytarishlar iBox'dan avtomatik qo'shiladi.</span>
      <div class="row"><button class="btn">Saqlash</button><button type="button" class="btn soft" data-act="chatwith" data-id="${c.id}">Chatga yozish</button></div></form>
    ${l && l.entries.length ? `<div class="tbl-wrap"><table><thead><tr><th>Sana</th><th>Hujjat</th><th class="num">Summa</th><th class="num">Qoldiq</th></tr></thead><tbody>
      ${l.entries.map((e) => `<tr><td>${e.date}</td><td>${esc(e.title)} ${esc(e.number || "")}</td><td class="num ${e.amount > 0 ? "pos" : "neg"}">${e.currency === "USD" ? "$" + e.amount : fmt(e.amount)}</td><td class="num">${e.currency === "USD" ? "$" + e.balance : fmt(e.balance)}</td></tr>`).join("")}</tbody></table></div>` : ""}
    <div class="tbl-wrap"><table><thead><tr><th>Oxirgi buyurtmalar</th><th class="num">Summa</th><th>Holat</th></tr></thead><tbody>
      ${c.orders.map((o) => `<tr class="click" data-act="order" data-id="${o.id}"><td>№${o.no} · ${dt(o.created_at)}</td><td class="num">${fmt(o.total)}</td><td>${statusPill(o.status, o.status_text)}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">Yo\'q</td></tr>'}</tbody></table></div>`);
}

// ---------- tovarlar ----------
let prodQ = "", prodFilter = "";
async function viewProducts() {
  const d = await api(`/products?q=${encodeURIComponent(prodQ)}&filter=${prodFilter}`);
  const opts = [["", "Hammasi"], ["no_box", "Karobka soni yo'q"], ["suggest", "Nomidan topilgan taklif bor"], ["promo", "Aksiyadagilar"], ["no_price", "Narxi yo'q"]];
  const nSuggest = d.items.filter((p) => !p.box_qty && p.box_qty_suggest).length;
  return `<div class="row between"><h1>Tovarlar</h1>
      <form data-submit="psearch" class="row"><input class="input" name="q" placeholder="Nomi, artikul, shtrix-kod" value="${esc(prodQ)}">
        <select class="input" name="filter">${opts.map(([v, t]) => `<option value="${v}" ${v === prodFilter ? "selected" : ""}>${t}</option>`).join("")}</select><button class="btn soft">Ko'rsatish</button></form></div>
    <details class="card"><summary style="cursor:pointer;font-weight:800">📋 Karobka sonini Excel'dan ko'chirib qo'yish</summary>
      <form data-submit="bulk" class="stack" style="margin-top:12px"><span class="muted small">Faqat iBox'da karobka soni yo'q tovarlar uchun kerak. Excel'da ikki ustun: <b>artikul yoki shtrix-kod</b> va <b>karobkadagi dona soni</b>. Ustunlarni belgilab nusxalang (Ctrl+C) va shu yerga qo'ying (Ctrl+V).</span>
      <textarea class="input" name="text" rows="6" placeholder="RC-01	12&#10;4600234100518	48"></textarea><div><button class="btn">Yuklash</button></div></form></details>
    <div class="card row between"><span class="muted">Karobkadagi son tartibi: <b>qo'lda kiritilgan</b> → <b>iBox'dagi</b>. Nomidan topilgani faqat tasdiqlasangiz ishlatiladi.</span>
      ${nSuggest ? `<button class="btn soft" data-act="accept">Nomidan topilgan ${nSuggest} tasini tasdiqlash</button>` : ""}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th class="num">Narx</th><th class="num">Karobka narxi</th><th class="num">Qoldiq</th><th>Karobkada (dona)</th><th>Aksiya belgisi</th><th>Eski narx</th><th></th></tr></thead><tbody>
    ${d.items.map((p) => `<tr><td><b>${esc(p.name)}</b><br><span class="small muted">${esc(p.sku || "")} ${esc(p.category_name || "")}</span></td>
      <td class="num">${fmt(p.price)}</td><td class="num">${p.box_qty && p.price ? fmt(p.price * p.box_qty) : "—"}</td>
      <td class="num">${fmt(p.stock)}${p.box_qty && p.stock ? `<br><span class="small muted">~${Math.floor(p.stock / p.box_qty)} kar.</span>` : ""}</td>
      <td><input class="input sm" data-f="box_qty" data-id="${p.id}" inputmode="numeric" value="${p.box_qty_manual ?? ""}" placeholder="${p.box_qty_ibox ?? ""}">
        <div class="small muted">${p.box_qty_manual ? "qo'lda" : p.box_qty_ibox ? `iBox: ${p.box_qty_ibox}` : p.box_qty_suggest ? `nomidan: ${p.box_qty_suggest}?` : "yo'q"}</div></td>
      <td><input class="input sm" data-f="promo_label" data-id="${p.id}" value="${esc(p.promo_label || "")}" placeholder="—"></td>
      <td><input class="input sm" style="width:110px" data-f="promo_old_price" data-id="${p.id}" inputmode="numeric" value="${p.promo_old_price ?? ""}"></td>
      <td><button class="btn sm" data-act="psave" data-id="${p.id}">Saqlash</button></td></tr>`).join("") || '<tr><td colspan="7" class="empty">Topilmadi</td></tr>'}
    </tbody></table></div>`;
}

// ---------- bannerlar ----------
let bannerEdit = null;
async function viewBanners() {
  const d = await api("/banners");
  const b = bannerEdit || { title: "", subtitle: "", color: "#3D4FE0", link_type: "none", link_value: "", active: true, sort: 0 };
  return `<h1>Aksiya bannerlari</h1>
    <form class="card stack" data-submit="bsave"><h2>${b.id ? "Bannerni tahrirlash" : "Yangi banner"}</h2>
      <div class="form">
        <label class="f">Sarlavha<input class="input" name="title" maxlength="80" value="${esc(b.title)}" required></label>
        <label class="f">Qo'shimcha matn<input class="input" name="subtitle" maxlength="160" value="${esc(b.subtitle || "")}"></label>
        <label class="f">Rang<input class="input" type="color" name="color" value="${esc(b.color)}" style="padding:4px"></label>
        <label class="f">Bosilganda<select class="input" name="link_type">
          ${[["none", "Hech narsa"], ["category", "Kategoriya (ID)"], ["product", "Tovar (ID)"], ["search", "Qidiruv so'zi"]].map(([v, t]) => `<option value="${v}" ${b.link_type === v ? "selected" : ""}>${t}</option>`).join("")}</select></label>
        <label class="f">Havola qiymati<input class="input" name="link_value" value="${esc(b.link_value || "")}" placeholder="masalan 3 yoki ayiq"></label>
        <label class="f">Tartib<input class="input" name="sort" type="number" value="${b.sort || 0}"></label>
        <label class="f">Boshlanishi<input class="input" type="datetime-local" name="starts_at" value="${toLocalInput(b.starts_at)}"></label>
        <label class="f">Tugashi<input class="input" type="datetime-local" name="ends_at" value="${toLocalInput(b.ends_at)}"></label>
        <label class="f">Rasm (ixtiyoriy)<input class="input" type="file" name="image" accept="image/*" style="padding:6px"></label>
      </div>
      <label class="chk"><input type="checkbox" name="active" ${b.active ? "checked" : ""}> Faol</label>
      <div class="row"><button class="btn">${b.id ? "Saqlash" : "Qo'shish"}</button>${b.id ? '<button type="button" class="btn soft" data-act="bnew">Bekor qilish</button>' : ""}</div></form>
    <div class="grid2">${d.items.map((x) => `<div class="card stack">
      <div class="banner-prev" style="background:${esc(x.color)}">${x.image_url ? `<img src="${esc(fileUrl(x.image_url))}" alt="">` : ""}<div><b style="font-size:18px">${esc(x.title)}</b><br>${esc(x.subtitle || "")}</div></div>
      <div class="row between"><span>${x.active ? '<span class="pill green">faol</span>' : '<span class="pill gray">o\'chiq</span>'} <span class="small muted">${x.link_type !== "none" ? esc(x.link_type + ": " + x.link_value) : ""}</span></span>
        <span class="row"><button class="btn soft sm" data-act="bedit" data-id="${x.id}">Tahrirlash</button><button class="btn danger sm" data-act="bdel" data-id="${x.id}">O'chirish</button></span></div></div>`).join("") || '<div class="empty card">Hali banner yo\'q</div>'}</div>`;
}
let bannersCache = [];

// ---------- shikoyatlar ----------
let cmpFilter = "new";
async function viewComplaints() {
  const d = await api(`/complaints${cmpFilter ? "?status=" + cmpFilter : ""}`);
  const opts = [["new", "Yangi"], ["accepted", "Qabul qilingan"], ["done", "Hal qilingan"], ["rejected", "Rad etilgan"], ["", "Hammasi"]];
  return `<div class="row between"><h1>Qaytarish va shikoyatlar</h1>
      <select class="input" data-change="cfilter">${opts.map(([v, t]) => `<option value="${v}" ${v === cmpFilter ? "selected" : ""}>${t}</option>`).join("")}</select></div>
    ${d.items.map((c) => `<form class="card stack" data-submit="cmpsave" data-id="${c.id}">
      <div class="row between"><b>${c.kind === "return" ? "↩️ Qaytarish" : "⚠️ Shikoyat"} #${c.id} · ${esc(c.client_name)}</b><span class="small muted">${dt(c.created_at)}</span></div>
      <span class="muted">${esc(c.phone || "")}${c.order_no ? ` · buyurtma №${c.order_no}` : ""}${c.product_name ? ` · ${esc(c.product_name)}` : ""}${c.qty ? `, ${fmt(c.qty)} dona` : ""}</span>
      <div style="white-space:pre-wrap">${esc(c.reason)}</div>
      ${c.images.length ? `<div class="thumbs">${c.images.map((u) => `<a href="${esc(fileUrl(u))}" target="_blank" rel="noopener"><img src="${esc(fileUrl(u))}" alt="Rasm"></a>`).join("")}</div>` : ""}
      <div class="row"><select class="input" name="status">${[["new", "Yangi"], ["accepted", "Qabul qilindi"], ["rejected", "Rad etildi"], ["done", "Hal qilindi"]].map(([v, t]) => `<option value="${v}" ${c.status === v ? "selected" : ""}>${t}</option>`).join("")}</select>
        <input class="input grow" name="admin_note" placeholder="Mijozga izoh (ixtiyoriy)" value="${esc(c.admin_note || "")}"><button class="btn">Saqlash va xabar berish</button></div>
    </form>`).join("") || '<div class="empty card">Bu bo\'limda hech narsa yo\'q</div>'}`;
}

// ---------- chat ----------
let chatClient = null, chatTimer = null;
async function viewChat() {
  const d = await api("/chats");
  badges.chat = d.items.reduce((s, c) => s + c.unread, 0);
  if (!chatClient && d.items[0]) chatClient = d.items[0].client_id;
  return `<h1>Chat</h1><div class="chat">
    <div class="list">${d.items.map((c) => `<button data-act="pick" data-id="${c.client_id}" class="${c.client_id === chatClient ? "on" : ""}">
      <span class="row between"><b>${esc(c.name)}</b>${c.unread ? `<span class="pill red">${c.unread}</span>` : ""}</span>
      <span class="small muted">${c.last_dir === "out" ? "Siz: " : ""}${esc((c.last_text || "[rasm]").slice(0, 60))}</span><span class="small muted">${ago(c.last_at)}</span></button>`).join("") || '<div class="empty">Hali xabar yo\'q</div>'}</div>
    <div class="conv" id="conv">${chatClient ? loading : '<div class="empty">Mijozni tanlang</div>'}</div></div>`;
}
async function loadConv() {
  const el = document.getElementById("conv");
  if (!el || !chatClient) return;
  const d = await api(`/chats/${chatClient}`);
  el.innerHTML = `<div class="row between" style="padding:12px 16px;border-bottom:1px solid var(--line)"><b>${esc(d.client?.name)}</b><span class="small muted">${esc(d.client?.phone || "")} · Telegram: ${d.client?.telegram ? "ulangan" : "yo'q"}</span></div>
    <div class="msgs" id="msgs">${d.items.map((m) => `<div class="bubble ${m.direction}">${esc(m.text || "")}${m.image_url ? `<a href="${esc(fileUrl(m.image_url))}" target="_blank" rel="noopener"><img src="${esc(fileUrl(m.image_url))}" alt="Rasm"></a>` : ""}
      <div class="t">${m.direction === "out" ? esc(m.author || "Menejer") + " · " : ""}${dt(m.created_at)}${m.direction === "out" && m.read_at ? " · o'qildi" : ""}</div></div>`).join("") || '<div class="empty">Xabar yo\'q</div>'}</div>
    <form data-submit="send"><input class="input grow" name="text" placeholder="Javob yozing…" autocomplete="off"><label class="btn soft" style="cursor:pointer">📎<input type="file" name="image" accept="image/*" hidden></label><button class="btn">Yuborish</button></form>`;
  const msgs = document.getElementById("msgs");
  msgs.scrollTop = msgs.scrollHeight;
}

// ---------- qidiruv: sinonimlar, sinash, tahlil ----------
let searchTestQ = "";
async function viewSearch() {
  const [d, syn, test] = await Promise.all([
    api("/search-stats?days=30"), api("/synonyms"),
    searchTestQ ? api(`/search-test?q=${encodeURIComponent(searchTestQ)}`) : Promise.resolve(null),
  ]);
  return `<h1>Qidiruv va sinonimlar</h1>
    <p class="muted" style="margin:0">Ilova qidiruvi lotin va kirillni bir xil tushunadi (машина = mashina), apostrofsiz yozilsa ham topadi (qogirchoq = qo'g'irchoq), xato yozilsa yaqin variantlarni taklif qiladi. Sinonimlar — mijozlar boshqacha ataydigan so'zlar.</p>
    <form class="card stack" data-submit="stest"><h2>Qidiruvni sinash</h2>
      <div class="row"><input class="input" name="q" placeholder="Mijoz nima yozadi? Masalan: кукла, mashna, ayiqcha" value="${esc(searchTestQ)}"><button class="btn soft">Sinash</button></div>
      ${test ? `<span class="small">Tushunildi: ${test.understood.map((g) => `<b>${g.map(esc).join(" / ")}</b>`).join(" + ") || "—"}
        · ${test.fuzzy ? `aniq topilmadi, o'xshashlari` : `${test.total} ta tovar`}${test.did_you_mean.length ? ` · Balki: ${test.did_you_mean.map(esc).join(", ")}` : ""}</span>
        <div class="tbl-wrap"><table><thead><tr><th>Tovar</th><th>Guruh</th><th>Kategoriya</th><th>Brend</th></tr></thead><tbody>
        ${test.items.map((p) => `<tr><td>${esc(p.name)}</td><td>${esc(p.group_name || "")}</td><td>${esc(p.category_name || "")}</td><td>${esc(p.brand_name || "")}</td></tr>`).join("") || '<tr><td colspan="4" class="muted">Hech narsa chiqmadi — pastda sinonim qo\'shing</td></tr>'}</tbody></table></div>` : ""}
    </form>
    <form class="card stack" data-submit="synsave" id="synform"><h2>Sinonim qo'shish</h2>
      <input type="hidden" name="id" value="">
      <label class="f">Bir xil ma'noli so'zlar, vergul bilan<input class="input" name="words" placeholder="qo'g'irchoq, kukla, кукла, barbie" required></label>
      <span class="small muted">Birortasi qidirilsa, qolganlari bo'yicha ham topiladi. Ruscha, inglizcha va xalq orasidagi nomlarni yozing.</span>
      <div class="row"><button class="btn">Saqlash</button><button type="button" class="btn soft" data-act="synnew">Tozalash</button></div></form>
    <div class="tbl-wrap"><table><thead><tr><th>Sinonimlar (${syn.items.length})</th><th></th></tr></thead><tbody>
      ${syn.items.map((x) => `<tr><td>${x.words.map(esc).join(", ")}</td><td class="num" style="white-space:nowrap">
        <button class="btn soft sm" data-act="synedit" data-id="${x.id}" data-words="${esc(x.words.join(", "))}">Tahrirlash</button>
        <button class="btn soft sm" data-act="syndel" data-id="${x.id}">O'chirish</button></td></tr>`).join("") || '<tr><td colspan="2" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
    <h2 style="margin-top:8px">Tahlil — 30 kun</h2>
    <p class="muted" style="margin:0">Topilmagan so'zlar: yo sinonim qo'shing, yo bu tovarni olib kelish kerak.</p>
    <div class="grid2">
      <div class="tbl-wrap"><table><thead><tr><th>Topilmagan so'zlar</th><th class="num">Marta</th><th class="num">Mijoz</th><th></th></tr></thead><tbody>
        ${d.not_found.map((r) => `<tr><td>${esc(r.q)}</td><td class="num">${r.n}</td><td class="num">${r.clients}</td>
          <td class="num"><button class="btn soft sm" data-act="synfrom" data-q="${esc(r.q)}">+ sinonim</button></td></tr>`).join("") || '<tr><td colspan="4" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
      <div class="tbl-wrap"><table><thead><tr><th>Eng ko'p qidirilgan</th><th class="num">Marta</th><th class="num">O'rtacha natija</th></tr></thead><tbody>
        ${d.top.map((r) => `<tr><td>${esc(r.q)}</td><td class="num">${r.n}</td><td class="num">${r.avg_results}</td></tr>`).join("") || '<tr><td colspan="3" class="muted">Yo\'q</td></tr>'}</tbody></table></div>
    </div>`;
}

// ---------- katalog bo'limlari ----------
let secKind = "group";
async function viewSections() {
  const d = await api("/sections");
  const tabs = [["group", "Guruhlar"], ["category", "Kategoriyalar"], ["brand", "Brendlar"]];
  const list = d[secKind];
  return `<h1>Katalog bo'limlari</h1>
    <p class="muted" style="margin:0">Ilovada tovarlar iBox'dagi guruh, kategoriya va brend bo'yicha ajratiladi. Nomlarni iBox'da o'zgartirasiz — 5 daqiqada ilovaga o'tadi. Bu yerda keraksiz bo'limni ilovada yashirish mumkin (tovarlar ham ko'rinmaydi).</p>
    <div class="row">${tabs.map(([k, t]) => `<button class="btn ${k === secKind ? "" : "soft"} sm" data-act="seckind" data-k="${k}">${t} (${d[k].length})</button>`).join("")}</div>
    <div class="tbl-wrap"><table><thead><tr><th>Nomi</th><th class="num">Tovarlar</th><th>Ilovada</th></tr></thead><tbody>
      ${list.map((r) => `<tr><td>${esc(r.name)}</td><td class="num">${r.n}</td><td>
        <label class="chk" style="margin:0"><input type="checkbox" data-change="sechide" data-kind="${secKind}" data-key="${esc(r.key)}" ${r.hidden ? "" : "checked"}> ${r.hidden ? '<span class="pill gray">yashirilgan</span>' : "ko'rinadi"}</label></td></tr>`).join("") || '<tr><td colspan="3" class="muted">iBox\'da bo\'lim yo\'q</td></tr>'}</tbody></table></div>`;
}

// ---------- xabar yuborish ----------
async function viewBroadcast() {
  const d = await api("/broadcast", { method: "POST", body: { text: "...", dry_run: true } });
  return `<h1>Barcha mijozlarga xabar</h1>
    <form class="card stack" data-submit="bcast" style="max-width:680px">
      <span class="muted">Xabar Telegram botga ulangan <b>${d.recipients}</b> ta mijozga boradi. Aksiya, yangi tovar yoki ish tartibi haqida e'lon uchun.</span>
      <textarea class="input" name="text" rows="6" maxlength="3000" required placeholder="Masalan: Yangi yil munosabati bilan 25-dekabrgacha barcha yumshoq o'yinchoqlarga 15% chegirma!"></textarea>
      <label class="f">Tugma bosilganda ochiladigan bo'lim (ixtiyoriy)<select class="input" name="link"><option value="/">Bosh sahifa</option><option value="/katalog?promo=1">Aksiyadagi tovarlar</option><option value="/katalog?sort=new">Yangi tovarlar</option></select></label>
      <div><button class="btn">Yuborish</button></div></form>`;
}

// ---------- sozlamalar ----------
async function viewSettings() {
  const d = await api("/settings");
  const s = d.settings;
  return `<h1>Sozlamalar</h1>
    <form class="card stack" data-submit="ssave" style="max-width:760px"><h2>Ilova</h2>
      <div class="form">
        <label class="f">Minimal buyurtma summasi, so'm (0 — cheklovsiz)<input class="input" name="min_order_sum" inputmode="numeric" value="${s.min_order_sum}"></label>
        <label class="f">"Yangi" belgisi necha kun turadi<input class="input" name="new_days" type="number" min="1" value="${s.new_days}"></label>
        <label class="f">Ilovada birinchi tanlangan birlik<select class="input" name="default_mode"><option value="box" ${s.default_mode === "box" ? "selected" : ""}>Karobka (ulgurji)</option><option value="unit" ${s.default_mode === "unit" ? "selected" : ""}>Dona</option></select></label>
        <label class="f">Dollar kursi (1 USD = … so'm)<input class="input" name="usd_rate" inputmode="decimal" value="${s.usd_rate}"></label>
      </div>
      <label class="chk"><input type="checkbox" name="usd_rate_auto" ${s.usd_rate_auto ? "checked" : ""}> Kursni iBox'dan avtomatik olish (iBox kursni API orqali bersa ishlaydi; hozircha qo'lda yangilang)</label>
      <label class="chk"><input type="checkbox" name="show_usd" ${s.show_usd ? "checked" : ""}> Dollarli tovarlarda asl narxni ($) ham ko'rsatish</label>
      <label class="chk"><input type="checkbox" name="ledger_enabled" ${s.ledger_enabled ? "checked" : ""}> Oldi-berdi (qarz, akt-sverka) bo'limini mijozlarga ko'rsatish</label>
      <label class="chk"><input type="checkbox" name="block_over_limit" ${s.block_over_limit ? "checked" : ""}> Kredit limitidan oshsa buyurtmani to'xtatish</label>
      <label class="chk"><input type="checkbox" name="overdue_reminder" ${s.overdue_reminder ? "checked" : ""}> Muddati o'tgan qarz haqida haftada bir eslatma</label>
      <label class="chk"><input type="checkbox" name="new_arrivals_notify" ${s.new_arrivals_notify ? "checked" : ""}> Yangi kelgan tovarlar haqida kuniga bir marta xabar</label>
      <span class="small muted">Qarz iBox'ning "Qarzdorlar" ro'yxatidan aniq olinadi (so'm va dollar alohida). Agar iBox kaliti bu ro'yxatga ruxsat bermasa, qarz hujjatlardan hisoblanadi — unda Mijozlar bo'limida boshlang'ich qoldiq va sanani kiriting. Yoqishdan oldin 2–3 mijozning qarzini iBox bilan solishtiring.</span>
      <div><button class="btn">Saqlash</button></div></form>
    <div class="card stack" style="max-width:760px"><h2>Adminlar</h2>
      ${d.admins.map((a) => `<div class="row between"><span><b>${esc(a.name)}</b> · …${esc(a.phone_key.slice(-4))}</span><span>${a.telegram ? '<span class="pill green">Telegram ulangan</span>' : '<span class="pill amber">botga raqam yubormagan</span>'} ${a.active ? "" : '<span class="pill gray">o\'chiq</span>'}</span></div>`).join("")}
      <form data-submit="addadmin" class="row"><input class="input" name="name" placeholder="Ism" required><input class="input" name="phone" placeholder="Telefon" required><button class="btn soft">Admin qo'shish</button></form>
      <span class="small muted">Yangi admin Telegram botga o'z raqamini yuborgach, panelga kira oladi.</span></div>
    <details class="card" style="max-width:760px"><summary style="cursor:pointer;font-weight:800">🔧 iBox javob namunalari (dasturchi uchun)</summary>
      <div class="stack" style="margin-top:10px">${Object.entries(d.samples).map(([k, v]) => `<div><b>${esc(k)}</b><pre>${esc(v || "— hali yo'q —")}</pre></div>`).join("")}</div></details>`;
}

// ---------- drawer ----------
function drawer(html) {
  closeDrawer();
  const bg = document.createElement("div"); bg.className = "drawer-bg"; bg.onclick = closeDrawer;
  const d = document.createElement("div"); d.className = "drawer"; d.setAttribute("role", "dialog"); d.innerHTML = html;
  document.getElementById("main").append(bg, d);
}
function closeDrawer() { document.querySelectorAll(".drawer, .drawer-bg").forEach((x) => x.remove()); }

// ---------- marshrut ----------
const VIEWS = { "/": viewDash, "/buyurtmalar": viewOrders, "/mijozlar": viewClients, "/tovarlar": viewProducts, "/bannerlar": viewBanners,
  "/shikoyatlar": viewComplaints, "/chat": viewChat, "/qidiruv": viewSearch, "/bolimlar": viewSections, "/xabar": viewBroadcast, "/sozlamalar": viewSettings };

async function render() {
  clearInterval(chatTimer);
  if (!store.token) return viewLogin();
  const path = (location.hash.slice(1) || "/").split("?")[0];
  const view = VIEWS[path] || viewDash;
  shell(path, loading);
  actions = commonActions();
  try {
    const html = await view();
    shell(path, html);
    if (path === "/chat") { await loadConv(); chatTimer = setInterval(() => loadConv().catch(() => {}), 10000); }
  } catch (e) { main().innerHTML = `<div class="empty card">${esc(e.message)}</div>`; }
}

function commonActions() {
  return {
    logout: async () => { if (!twice("logout", "Chiqish uchun yana bir marta bosing")) return; try { await api("/auth/logout", { method: "POST" }); } catch { /* */ } store.token = null; render(); },
    close: closeDrawer,
    resend: async (el) => { el.disabled = true; try { const r = await api(`/orders/${el.dataset.id}/resend`, { method: "POST" }); toast(r.ok ? "iBox'ga yuborildi" : "Yana xato: " + (r.error || ""), !r.ok); render(); } catch (e) { fail(e); el.disabled = false; } },
    order: (el) => openOrder(el.dataset.id).catch(fail),
    client: (el) => openClient(el.dataset.id).catch(fail),
    chatwith: (el) => { chatClient = Number(el.dataset.id); closeDrawer(); location.hash = "#/chat"; },
    csearch: (f, d) => { clientQ = d.get("q").trim(); render(); },
    csave: async (f, d) => { try { await api(`/clients/${f.dataset.id}`, { method: "POST", body: Object.fromEntries(d) }); toast("Saqlandi"); openClient(f.dataset.id); } catch (e) { fail(e); } },
    psearch: (f, d) => { prodQ = d.get("q").trim(); prodFilter = d.get("filter"); render(); },
    psave: async (el) => {
      const id = el.dataset.id, body = {};
      document.querySelectorAll(`[data-id="${id}"][data-f]`).forEach((i) => (body[i.dataset.f] = i.value));
      try { await api(`/products/${id}`, { method: "POST", body }); toast("Saqlandi"); } catch (e) { fail(e); }
    },
    accept: async () => { try { const r = await api("/products/accept-suggestions", { method: "POST", body: {} }); toast(`${r.updated} ta tovarga karobka soni qo'yildi`); render(); } catch (e) { fail(e); } },
    bulk: async (f, d) => { try { const r = await api("/products/box-bulk", { method: "POST", body: { text: d.get("text") } }); toast(`${r.updated} ta tovar yangilandi${r.missing_count ? `, ${r.missing_count} ta topilmadi: ${r.missing.slice(0, 5).join(", ")}` : ""}`, !!r.missing_count && !r.updated); render(); } catch (e) { fail(e); } },
    bsave: async (f, d) => {
      const body = Object.fromEntries(d);
      body.active = d.get("active") === "on";
      for (const k of ["starts_at", "ends_at"]) body[k] = body[k] ? new Date(body[k]).toISOString() : null;
      const file = d.get("image");
      delete body.image;
      try {
        if (file && file.size) body.image = await readImage(file, 1200);
        if (bannerEdit?.id) { body.id = bannerEdit.id; body.image_id = bannerEdit.image_id; }
        await api("/banners", { method: "POST", body }); bannerEdit = null; toast("Saqlandi"); render();
      } catch (e) { fail(e); }
    },
    bnew: () => { bannerEdit = null; render(); },
    bedit: async (el) => { const d = await api("/banners"); bannerEdit = d.items.find((x) => String(x.id) === el.dataset.id); render(); },
    bdel: async (el) => { if (!twice("bdel" + el.dataset.id, "O'chirish uchun yana bir marta bosing")) return; try { await api(`/banners/${el.dataset.id}/delete`, { method: "POST" }); render(); } catch (e) { fail(e); } },
    cmpsave: async (f, d) => { try { await api(`/complaints/${f.dataset.id}`, { method: "POST", body: Object.fromEntries(d) }); toast("Saqlandi, mijozga xabar yuborildi"); render(); } catch (e) { fail(e); } },
    pick: (el) => { chatClient = Number(el.dataset.id); document.querySelectorAll(".chat .list button").forEach((b) => b.classList.toggle("on", b === el)); loadConv().catch(fail); },
    send: async (f, d) => {
      const text = String(d.get("text") || "").trim(), file = d.get("image");
      if (!text && !(file && file.size)) return;
      const body = { text };
      try { if (file && file.size) body.image = await readImage(file); const r = await api(`/chats/${chatClient}`, { method: "POST", body }); if (!r.telegram) toast("Ilovaga yozildi (mijozning Telegram'i ulanmagan)"); await loadConv(); } catch (e) { fail(e); }
    },
    bcast: async (f, d) => {
      if (!twice("bcast", "Hammaga yuborish uchun yana bir marta bosing")) return;
      try { const r = await api("/broadcast", { method: "POST", body: { text: d.get("text"), link: d.get("link") } }); toast(`${r.sent} / ${r.recipients} mijozga yuborildi`); f.reset(); } catch (e) { fail(e); }
    },
    ssave: async (f, d) => {
      const body = { min_order_sum: d.get("min_order_sum"), new_days: d.get("new_days"), default_mode: d.get("default_mode"), usd_rate: d.get("usd_rate") };
      for (const k of ["ledger_enabled", "block_over_limit", "overdue_reminder", "new_arrivals_notify", "usd_rate_auto", "show_usd"]) body[k] = d.get(k) === "on";
      try { await api("/settings", { method: "POST", body }); toast("Saqlandi"); } catch (e) { fail(e); }
    },
    addadmin: async (f, d) => { try { await api("/admins", { method: "POST", body: Object.fromEntries(d) }); toast("Admin qo'shildi"); render(); } catch (e) { fail(e); } },
    stest: (f, d) => { searchTestQ = String(d.get("q") || "").trim(); render(); },
    synsave: async (f, d) => { try { await api("/synonyms", { method: "POST", body: { id: d.get("id"), words: d.get("words") } }); toast("Saqlandi"); render(); } catch (e) { fail(e); } },
    synnew: () => { const f = document.getElementById("synform"); f.elements.id.value = ""; f.elements.words.value = ""; },
    synedit: (el) => { const f = document.getElementById("synform"); f.elements.id.value = el.dataset.id; f.elements.words.value = el.dataset.words; f.scrollIntoView({ behavior: "smooth" }); f.elements.words.focus(); },
    synfrom: (el) => { const f = document.getElementById("synform"); f.elements.id.value = ""; f.elements.words.value = el.dataset.q + ", "; f.scrollIntoView({ behavior: "smooth" }); f.elements.words.focus(); },
    syndel: async (el) => { if (!twice("syndel" + el.dataset.id, "O'chirish uchun yana bir marta bosing")) return; try { await api(`/synonyms/${el.dataset.id}/delete`, { method: "POST" }); render(); } catch (e) { fail(e); } },
    seckind: (el) => { secKind = el.dataset.k; render(); },
  };
}
$root.addEventListener("change", (e) => {
  const k = e.target.dataset.change;
  if (k === "ofilter") { orderFilter = e.target.value; render(); }
  if (k === "cfilter") { cmpFilter = e.target.value; render(); }
  if (k === "sechide") {
    api("/sections", { method: "POST", body: { kind: e.target.dataset.kind, key: e.target.dataset.key, hidden: !e.target.checked } })
      .then(() => { toast(e.target.checked ? "Ilovada ko'rinadi" : "Ilovada yashirildi"); render(); }).catch(fail);
  }
});
window.addEventListener("hashchange", render);
render();
