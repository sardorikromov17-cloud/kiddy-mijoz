// Telegram bot webhook.
//  • Shaxsiy chat: mijoz/menejer raqamini (kontaktini) yuborib ulanadi; ulangan mijoz yozgan xabar menejerlarga boradi.
//  • Menejerlar guruhi: mijoz xabari yoki shikoyatiga "Reply" qilinsa — javob mijozga (ilova chatiga va Telegram'ga) boradi.
//  • Istalgan guruhda /id — guruh raqamini ko'rsatadi (MANAGER_CHAT_ID sozlash uchun).
import { db } from "../_shared/db.ts";
import { config } from "../_shared/config.ts";
import { phoneKey } from "../_shared/ibox.ts";
import { escapeHtml, sendMessage, tg } from "../_shared/telegram.ts";
import { notifyClient, notifyManagers } from "../_shared/notify.ts";

const contactKeyboard = {
  reply_markup: { keyboard: [[{ text: "📱 Raqamimni yuborish", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true },
};

async function downloadPhoto(fileId: string): Promise<string | null> {
  try {
    const f = await tg("getFile", { file_id: fileId });
    const res = await fetch(`${config.tgApiBase()}/file/bot${config.tgToken()}/${f.file_path}`);
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes.length > 3 * 1024 * 1024) return null;
    const [row] = await db()`insert into mijoz.files (mime, bytes, size, owner) values ('image/jpeg', ${bytes}, ${bytes.length}, 'telegram') returning id`;
    return row.id;
  } catch (e) { console.error("photo", e); return null; }
}

async function handleContact(msg: any) {
  const chatId = msg.chat.id;
  if (msg.contact.user_id !== msg.from?.id) {
    await sendMessage(chatId, "Iltimos, pastdagi tugma orqali <b>o'zingizning</b> raqamingizni yuboring.", contactKeyboard);
    return;
  }
  const key = phoneKey(msg.contact.phone_number);
  const sql = db();
  const [admin] = key ? await sql`select name from mijoz.admins where phone_key = ${key} and active` : [];
  if (admin) await sql`update mijoz.admins set tg_chat_id = ${chatId} where phone_key = ${key}`;
  const clients = key ? await sql`select id, name from mijoz.clients where phone_key = ${key} and active and not in_black_list order by id` : [];
  if (clients.length) {
    await sql.begin(async (tx: any) => {
      await tx`update mijoz.clients set tg_chat_id = null where tg_chat_id = ${chatId}`;
      await tx`update mijoz.clients set tg_chat_id = ${chatId} where phone_key = ${key} and active`;
    });
  }
  const parts: string[] = [];
  if (clients.length) parts.push(`✅ Siz ${clients.map((c: any) => (/[«"]/.test(c.name) ? escapeHtml(c.name) : `«${escapeHtml(c.name)}»`)).join(", ")} sifatida ulandingiz.\n\nEndi ilovaga qaytib, «Kod olish» tugmasini bosing — kirish kodi shu yerga keladi. Buyurtma holati va javoblar ham shu yerga keladi.`);
  if (admin) parts.push(`🛠 Admin sifatida ulandingiz (${escapeHtml(admin.name)}). Admin panelga kirish kodi shu yerga keladi.`);
  if (!parts.length) {
    const mgr = config.managerPhone();
    parts.push("Bu raqam mijozlar bazasida topilmadi." + (mgr ? `\nMenejerga murojaat qiling: ${escapeHtml(mgr)}` : ""));
  }
  await sendMessage(chatId, parts.join("\n\n"), { reply_markup: { remove_keyboard: true } });
}

/** Menejerlar guruhida mijoz xabariga berilgan javob */
async function handleManagerReply(msg: any) {
  const sql = db();
  const replyTo = msg.reply_to_message?.message_id;
  if (!replyTo) return;
  const [m] = await sql`select client_id from mijoz.messages where tg_message_id = ${replyTo} limit 1`;
  const [c] = m ? [] : await sql`select client_id, id from mijoz.complaints where tg_message_id = ${replyTo} limit 1`;
  const clientId = m?.client_id ?? c?.client_id;
  if (!clientId) return; // boshqa xabarga javob — e'tibor bermaymiz
  const text = (msg.text ?? msg.caption ?? "").trim().slice(0, 2000);
  const photo = msg.photo?.length ? await downloadPhoto(msg.photo[msg.photo.length - 1].file_id) : null;
  if (!text && !photo) return;
  const author = [msg.from?.first_name, msg.from?.last_name].filter(Boolean).join(" ") || "Menejer";
  await sql`insert into mijoz.messages (client_id, direction, text, file_id, author) values (${clientId}, 'out', ${text || null}, ${photo}, ${author})`;
  const delivered = await notifyClient(Number(clientId),
    `💬 <b>Menejer javobi</b>${c ? ` (so'rov #${c.id})` : ""}:\n${escapeHtml(text || "[rasm]")}`,
    { text: "Chatni ochish", path: "/chat" });
  await tg("setMessageReaction", { chat_id: msg.chat.id, message_id: msg.message_id, reaction: [{ type: "emoji", emoji: delivered ? "👍" : "👀" }] }).catch(() => {});
}

/** Ulangan mijoz botga to'g'ridan-to'g'ri yozsa — menejerlarga yuboramiz */
async function handleClientText(msg: any) {
  const sql = db();
  const [client] = await sql`select id, name, phone from mijoz.clients where tg_chat_id = ${msg.chat.id} and active order by id limit 1`;
  if (!client) {
    await sendMessage(msg.chat.id, "Assalomu alaykum! Bu <b>Kiddy Toys</b> buyurtma ilovasining boti.\n\nIlovaga kirish kodlari va buyurtma xabarlarini olish uchun raqamingizni yuboring 👇", contactKeyboard);
    return;
  }
  const text = (msg.text ?? msg.caption ?? "").trim().slice(0, 2000);
  const photo = msg.photo?.length ? await downloadPhoto(msg.photo[msg.photo.length - 1].file_id) : null;
  if (!text && !photo) return;
  const [row] = await sql`insert into mijoz.messages (client_id, direction, text, file_id) values (${client.id}, 'in', ${text || null}, ${photo}) returning id`;
  const tgId = await notifyManagers(
    `💬 <b>${escapeHtml(client.name)}</b> (${escapeHtml(client.phone ?? "")}) · Telegram orqali\n${text ? escapeHtml(text) : "[rasm]"}\n\n<i>Javob berish uchun shu xabarga "Reply" qiling.</i>`,
    photo ? [photo] : []);
  if (tgId) await sql`update mijoz.messages set tg_message_id = ${tgId} where id = ${row.id}`;
  await sendMessage(msg.chat.id, tgId ? "✉️ Xabaringiz menejerga yuborildi. Javob shu yerga va ilovadagi chatga keladi." : "Xabaringiz saqlandi, menejer tez orada javob beradi.");
}

Deno.serve(async (req) => {
  const secret = config.tgWebhookSecret();
  if (!secret || req.headers.get("x-telegram-bot-api-secret-token") !== secret) return new Response("forbidden", { status: 403 });
  const update = await req.json().catch(() => null);
  const msg = update?.message;
  if (!msg?.chat?.id) return new Response("ok");
  try {
    const isGroup = msg.chat.type === "group" || msg.chat.type === "supergroup";
    const text: string = msg.text ?? "";
    if (isGroup && /^\/id(@\w+)?$/.test(text)) {
      await sendMessage(msg.chat.id, `Bu guruh raqami: <code>${msg.chat.id}</code>\nUni Supabase Secrets'dagi MANAGER_CHAT_ID ga yozing.`);
    } else if (isGroup) {
      if (String(msg.chat.id) === config.managerChatId()) await handleManagerReply(msg);
    } else if (msg.chat.type === "private") {
      if (msg.contact) await handleContact(msg);
      else if (/^\/start/.test(text)) {
        await sendMessage(msg.chat.id, "Assalomu alaykum! Bu <b>Kiddy Toys</b> buyurtma ilovasining boti.\n\nIlovaga kirish kodlari, buyurtma holati va menejer javoblarini olish uchun raqamingizni yuboring 👇", contactKeyboard);
      } else await handleClientText(msg);
    }
  } catch (e) {
    console.error(e);
  }
  return new Response("ok");
});
