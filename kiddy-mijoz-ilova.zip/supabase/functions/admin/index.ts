// Admin panel API (…/functions/v1/admin/…). Faqat mijoz.admins jadvalidagi raqamlar kira oladi.
import { db, getState } from "../_shared/db.ts";
import { config } from "../_shared/config.ts";
import { phoneKey } from "../_shared/ibox.ts";
import { handle, HttpError, json, randomCode, randomToken, readJson, sha256 } from "../_shared/http.ts";
import { sendMessage } from "../_shared/telegram.ts";
import { getSettings, setSettings } from "../_shared/settings.ts";
import { didYouMean, dropSynonymCache, fuzzyCond, fuzzyOrder, matchCond, norm as searchNorm, plan as searchPlan } from "../_shared/search.ts";
import { clientLedger } from "../_shared/ledger.ts";
import { saveImage } from "../_shared/files.ts";
import { esc, fmt, notifyClient } from "../_shared/notify.ts";
import { sendOrderToIbox } from "../_shared/orders.ts";

const SESSION_DAYS = 30;
const num = (v: unknown) => (v === null || v === undefined || v === "" ? null : Number(String(v).replace(/\s/g, "").replace(",", ".")));
const STATUS_UZ: Record<string, string> = {
  new: "Yuborilmoqda", sent: "iBox'da", failed: "Xato", accepted: "Tasdiqlandi", shipped: "Jo'natildi",
  on_way: "Yo'lda", delivered: "Yetkazildi", cancelled: "Bekor",
};

async function currentAdmin(req: Request) {
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) throw new HttpError(401, "no_session", "Qayta kiring");
  const rows = await db()`
    update mijoz.admin_sessions s set last_seen_at = now(), expires_at = greatest(s.expires_at, now() + ${SESSION_DAYS + " days"}::interval)
    from mijoz.admins a
    where s.token_hash = ${await sha256(token)} and s.expires_at > now() and a.phone_key = s.phone_key and a.active
    returning a.phone_key, a.name`;
  if (!rows.length) throw new HttpError(401, "no_session", "Qayta kiring");
  return rows[0];
}

// ---------- kirish ----------
async function authRequest(req: Request) {
  const key = phoneKey((await readJson(req)).phone);
  if (!key) throw new HttpError(400, "bad_phone", "Raqamni to'liq kiriting");
  const sql = db();
  const [a] = await sql`select tg_chat_id from mijoz.admins where phone_key = ${key} and active`;
  if (!a) throw new HttpError(403, "not_admin", "Bu raqam adminlar ro'yxatida yo'q");
  if (!a.tg_chat_id && !config.devMode()) {
    const u = config.tgBotUsername().replace(/^@/, "");
    throw new HttpError(400, "need_telegram", `Avval Telegram botga (${u ? "@" + u : "bot"}) raqamingizni yuboring.`);
  }
  const lk = "a:" + key; // admin kodlari mijoz kodlaridan alohida
  const code = randomCode(6);
  await sql`insert into mijoz.login_codes (phone_key, code_hash, attempts, expires_at, created_at)
    values (${lk}, ${await sha256(lk + ":" + code)}, 0, now() + interval '5 minutes', now())
    on conflict (phone_key) do update set code_hash = excluded.code_hash, attempts = 0, expires_at = excluded.expires_at, created_at = now()`;
  if (a.tg_chat_id) await sendMessage(a.tg_chat_id, `🛠 Admin panelga kirish kodi: <b>${code}</b>\nKodni hech kimga bermang.`);
  return json(req, { sent: true, ...(config.devMode() ? { dev_code: code } : {}) });
}

async function authVerify(req: Request) {
  const b = await readJson(req);
  const key = phoneKey(b.phone);
  if (!key || !/^\d{6}$/.test(String(b.code ?? ""))) throw new HttpError(400, "bad_code", "Kodni to'g'ri kiriting");
  const lk = "a:" + key;
  const sql = db();
  const [row] = await sql`select * from mijoz.login_codes where phone_key = ${lk}`;
  if (!row || new Date(row.expires_at) < new Date()) throw new HttpError(400, "code_expired", "Kod eskirgan");
  if (row.attempts >= 5) throw new HttpError(429, "too_many", "Ko'p urinish. Yangi kod oling.");
  if (row.code_hash !== await sha256(lk + ":" + String(b.code))) {
    await sql`update mijoz.login_codes set attempts = attempts + 1 where phone_key = ${lk}`;
    throw new HttpError(400, "wrong_code", "Kod noto'g'ri");
  }
  await sql`delete from mijoz.login_codes where phone_key = ${lk}`;
  const token = randomToken();
  await sql`insert into mijoz.admin_sessions (token_hash, phone_key, expires_at) values (${await sha256(token)}, ${key}, now() + ${SESSION_DAYS + " days"}::interval)`;
  const [a] = await sql`select name from mijoz.admins where phone_key = ${key}`;
  return json(req, { token, admin: { name: a.name } });
}

// ---------- bosh panel ----------
async function stats(req: Request) {
  await currentAdmin(req);
  const sql = db();
  const [[o], [c], [m], [cmp], topProducts, topClients, failed, syncRows] = await Promise.all([
    sql`select
      count(*) filter (where created_at >= date_trunc('day', now() at time zone 'Asia/Tashkent') at time zone 'Asia/Tashkent')::int as today_n,
      coalesce(sum(total) filter (where created_at >= date_trunc('day', now() at time zone 'Asia/Tashkent') at time zone 'Asia/Tashkent'),0)::float8 as today_sum,
      count(*) filter (where created_at > now() - interval '7 days')::int as week_n,
      coalesce(sum(total) filter (where created_at > now() - interval '7 days'),0)::float8 as week_sum,
      count(*) filter (where created_at > now() - interval '30 days')::int as month_n,
      coalesce(sum(total) filter (where created_at > now() - interval '30 days'),0)::float8 as month_sum
      from mijoz.orders where status <> 'cancelled'`,
    sql`select count(*)::int total,
      count(*) filter (where tg_chat_id is not null)::int linked,
      (select count(distinct client_id)::int from mijoz.sessions where last_seen_at > now() - interval '7 days') active_7d,
      (select count(distinct client_id)::int from mijoz.sessions) ever
      from mijoz.clients where active`,
    sql`select count(*)::int unread from mijoz.messages where direction = 'in' and admin_read_at is null`,
    sql`select count(*)::int open from mijoz.complaints where status = 'new'`,
    sql`select i.product_id, i.name, sum(i.qty)::float8 qty, sum(i.total)::float8 total from mijoz.order_items i
        join mijoz.orders o on o.id = i.order_id where o.created_at > now() - interval '30 days' and o.status <> 'cancelled'
        group by i.product_id, i.name order by total desc limit 10`,
    sql`select o.client_id, c.name, count(*)::int n, sum(o.total)::float8 total from mijoz.orders o join mijoz.clients c on c.id = o.client_id
        where o.created_at > now() - interval '30 days' and o.status <> 'cancelled' group by o.client_id, c.name order by total desc limit 10`,
    sql`select id, no, ibox_error, created_at from mijoz.orders where status in ('failed','new') and created_at < now() - interval '2 minutes' order by created_at desc limit 10`,
    sql`select key, value, updated_at from mijoz.sync_state where key like 'last_%'`,
  ]);
  const sync: Record<string, any> = {};
  for (const r of syncRows) sync[r.key] = { value: r.value, at: r.updated_at };
  return json(req, { orders: o, clients: c, unread_messages: m.unread, open_complaints: cmp.open, top_products: topProducts, top_clients: topClients, failed_orders: failed, sync });
}

// ---------- buyurtmalar ----------
async function orders(req: Request, url: URL) {
  await currentAdmin(req);
  const status = url.searchParams.get("status");
  const rows = await db()`
    select o.id, o.no, o.status, o.total::float8 total, o.units::float8 units, o.comment, o.created_at, o.ibox_number, o.ibox_error,
      c.id client_id, c.name client_name, c.phone,
      (select count(*)::int from mijoz.order_items i where i.order_id = o.id) lines
    from mijoz.orders o join mijoz.clients c on c.id = o.client_id
    where ${status ? db()`o.status = ${status}` : db()`true`}
    order by o.created_at desc limit 200`;
  return json(req, { items: rows.map((r: any) => ({ ...r, status_text: STATUS_UZ[r.status] ?? r.status })) });
}

async function orderDetail(req: Request, id: string) {
  await currentAdmin(req);
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new HttpError(404, "not_found");
  const sql = db();
  const [o] = await sql`select o.*, o.total::float8 total, c.name client_name, c.phone from mijoz.orders o join mijoz.clients c on c.id = o.client_id where o.id = ${id}`;
  if (!o) throw new HttpError(404, "not_found");
  const items = await sql`select product_id, name, qty::float8 qty, price::float8 price, total::float8 total, box_qty, mode from mijoz.order_items where order_id = ${id} order by id`;
  return json(req, { ...o, status_text: STATUS_UZ[o.status], items });
}

async function orderResend(req: Request, id: string) {
  await currentAdmin(req);
  await db()`update mijoz.orders set status = 'failed', send_attempts = 0 where id = ${id} and status in ('failed','new')`;
  return json(req, await sendOrderToIbox(id));
}

// ---------- mijozlar ----------
async function clients(req: Request, url: URL) {
  await currentAdmin(req);
  const sql = db();
  const q = (url.searchParams.get("q") ?? "").trim().toLowerCase();
  const digits = q.replace(/\D/g, "");
  const rows = await sql`
    select c.id, c.name, c.code, c.phone, c.tg_chat_id is not null as telegram, c.credit_limit::float8 credit_limit,
      c.min_order_sum::float8 min_order_sum, c.credit_days, b.balance::float8 balance,
      (select max(last_seen_at) from mijoz.sessions s where s.client_id = c.id) last_seen,
      (select count(*)::int from mijoz.orders o where o.client_id = c.id) orders_n,
      (select max(created_at) from mijoz.orders o where o.client_id = c.id) last_order
    from mijoz.clients c left join mijoz.client_balance b on b.client_id = c.id
    where c.active and (${q} = '' or lower(c.name) like ${"%" + q + "%"} or lower(coalesce(c.code,'')) = ${q}
      or (${digits.length >= 4} and c.phone_key like ${"%" + digits.slice(-9) + "%"}))
    order by last_seen desc nulls last, c.name limit 300`;
  return json(req, { items: rows });
}

async function clientDetail(req: Request, id: number) {
  await currentAdmin(req);
  const sql = db();
  const [c] = await sql`select id, name, code, phone, credit_days, credit_limit::float8 credit_limit, min_order_sum::float8 min_order_sum,
      opening_balance::float8 opening_balance, opening_balance_usd::float8 opening_balance_usd, opening_balance_date, tg_chat_id is not null as telegram, notify_news
    from mijoz.clients where id = ${id}`;
  if (!c) throw new HttpError(404, "not_found");
  const l = await clientLedger(id);
  const recent = await sql`select id, no, status, total::float8 total, created_at from mijoz.orders where client_id = ${id} order by created_at desc limit 10`;
  return json(req, { ...c, ledger: l && { balance: l.balance, parts: l.parts, overdue: l.overdue, overdue_since: l.overdue_since, entries: l.entries.slice(-30).reverse() },
    orders: recent.map((r: any) => ({ ...r, status_text: STATUS_UZ[r.status] })) });
}

async function clientUpdate(req: Request, id: number) {
  await currentAdmin(req);
  const b = await readJson(req);
  const date = b.opening_balance_date && /^\d{4}-\d{2}-\d{2}$/.test(b.opening_balance_date) ? b.opening_balance_date : null;
  await db()`update mijoz.clients set
      credit_limit = ${num(b.credit_limit)}, min_order_sum = ${num(b.min_order_sum)},
      opening_balance = ${num(b.opening_balance) ?? 0}, opening_balance_usd = ${num(b.opening_balance_usd) ?? 0}, opening_balance_date = ${date}
    where id = ${id}`;
  return json(req, { ok: true });
}

// ---------- tovarlar ----------
async function products(req: Request, url: URL) {
  await currentAdmin(req);
  const sql = db();
  const q = (url.searchParams.get("q") ?? "").trim().toLowerCase();
  const filter = url.searchParams.get("filter");
  const rows = await sql`
    select id, name, sku, category_name, price::float8 price, stock::float8 stock, box_qty, box_qty_manual, box_qty_ibox, box_qty_suggest,
      promo_label, promo_old_price::float8 promo_old_price, barcodes
    from mijoz.products p
    where active and (${q} = '' or name_lc like ${"%" + q + "%"} or lower(coalesce(sku,'')) = ${q} or ${q} = any(barcodes))
      and ${filter === "no_box" ? sql`box_qty is null` : filter === "suggest" ? sql`box_qty is null and box_qty_suggest is not null` : filter === "promo" ? sql`promo_label is not null` : filter === "no_price" ? sql`(price is null or price = 0)` : sql`true`}
    order by name_lc limit 300`;
  return json(req, { items: rows });
}

async function productUpdate(req: Request, id: number) {
  await currentAdmin(req);
  const b = await readJson(req);
  const box = num(b.box_qty);
  const manual = box && box > 0 ? Math.round(box) : null;
  await db()`update mijoz.products set
      box_qty_manual = ${manual}, box_qty = coalesce(${manual}::int, box_qty_ibox),
      promo_label = ${b.promo_label ? String(b.promo_label).trim().slice(0, 20) : null},
      promo_old_price = ${num(b.promo_old_price)}
    where id = ${id}`;
  return json(req, { ok: true });
}

/** Excel'dan nusxalangan "artikul/shtrix-kod <TAB> karobkadagi son" qatorlari */
async function boxBulk(req: Request) {
  await currentAdmin(req);
  const { text } = await readJson(req);
  const sql = db();
  let updated = 0;
  const missing: string[] = [];
  for (const line of String(text ?? "").split(/\r?\n/).slice(0, 5000)) {
    const parts = line.split(/[\t;,]/).map((s) => s.trim()).filter(Boolean);
    if (parts.length < 2) continue;
    const key = parts[0], qty = Math.round(Number(parts[parts.length - 1].replace(/\s/g, "")));
    if (!key || !(qty > 0)) continue;
    const r = await sql`update mijoz.products set box_qty_manual = ${qty}, box_qty = ${qty}
      where lower(sku) = ${key.toLowerCase()} or ${key} = any(barcodes) or id::text = ${key} returning id`;
    if (r.length) updated += r.length; else missing.push(key);
  }
  return json(req, { updated, missing: missing.slice(0, 50), missing_count: missing.length });
}

/** Nomidan topilgan karobka sonlarini tasdiqlash (faqat karobka soni yo'q tovarlar uchun) */
async function acceptSuggestions(req: Request) {
  await currentAdmin(req);
  const b = await readJson(req);
  const ids: number[] | null = Array.isArray(b.ids) ? b.ids.map(Number).filter(Number.isInteger) : null;
  const r = await db()`update mijoz.products set box_qty_manual = box_qty_suggest, box_qty = box_qty_suggest
    where box_qty is null and box_qty_suggest is not null and ${ids ? db()`id = any(${ids}::bigint[])` : db()`true`} returning id`;
  return json(req, { updated: r.length });
}

// ---------- bannerlar ----------
async function banners(req: Request) {
  await currentAdmin(req);
  const rows = await db()`select * from mijoz.banners order by sort, id desc`;
  return json(req, { items: rows.map((b: any) => ({ ...b, image_url: b.image_id ? `files/${b.image_id}` : null })) });
}

async function bannerSave(req: Request) {
  const admin = await currentAdmin(req);
  const b = await readJson(req);
  const title = String(b.title ?? "").trim().slice(0, 80);
  if (!title) throw new HttpError(400, "no_title", "Sarlavha yozing");
  const linkType = ["none", "product", "category", "search"].includes(b.link_type) ? b.link_type : "none";
  const imageId = b.image ? await saveImage(b.image, `admin:${admin.phone_key}`) : (b.image_id ?? null);
  const color = /^#[0-9a-f]{6}$/i.test(b.color ?? "") ? b.color : "#3D4FE0";
  const ts = (v: any) => (v ? new Date(v).toISOString() : null);
  const sql = db();
  const vals = { title, subtitle: b.subtitle ? String(b.subtitle).slice(0, 160) : null, image_id: imageId, color, link_type: linkType,
    link_value: b.link_value ? String(b.link_value).slice(0, 200) : null, active: b.active !== false, sort: Number(b.sort) || 0,
    starts_at: ts(b.starts_at), ends_at: ts(b.ends_at) };
  if (b.id) {
    await sql`update mijoz.banners set ${sql(vals)} where id = ${Number(b.id)}`;
    return json(req, { id: Number(b.id) });
  }
  const [r] = await sql`insert into mijoz.banners ${sql(vals)} returning id`;
  return json(req, { id: r.id }, 201);
}

async function bannerDelete(req: Request, id: number) {
  await currentAdmin(req);
  await db()`delete from mijoz.banners where id = ${id}`;
  return json(req, { ok: true });
}

// ---------- shikoyatlar ----------
const CMP_UZ: Record<string, string> = { new: "Yangi", accepted: "Qabul qilindi", rejected: "Rad etildi", done: "Hal qilindi" };
async function complaints(req: Request, url: URL) {
  await currentAdmin(req);
  const st = url.searchParams.get("status");
  const rows = await db()`
    select c.*, c.qty::float8 qty, cl.name client_name, cl.phone, o.no order_no, p.name product_name
    from mijoz.complaints c join mijoz.clients cl on cl.id = c.client_id
    left join mijoz.orders o on o.id = c.order_id left join mijoz.products p on p.id = c.product_id
    where ${st ? db()`c.status = ${st}` : db()`true`} order by c.created_at desc limit 200`;
  return json(req, { items: rows.map((r: any) => ({ ...r, status_text: CMP_UZ[r.status], images: (r.file_ids ?? []).map((f: string) => `files/${f}`) })) });
}

async function complaintUpdate(req: Request, id: number) {
  const admin = await currentAdmin(req);
  const b = await readJson(req);
  if (!CMP_UZ[b.status]) throw new HttpError(400, "bad_status");
  const note = b.admin_note ? String(b.admin_note).slice(0, 1000) : null;
  const sql = db();
  const [c] = await sql`update mijoz.complaints set status = ${b.status}, admin_note = ${note}, updated_at = now() where id = ${id} returning client_id, kind`;
  if (!c) throw new HttpError(404, "not_found");
  const text = `${c.kind === "return" ? "Qaytarish so'rovingiz" : "Shikoyatingiz"} #${id}: ${CMP_UZ[b.status].toLowerCase()}.${note ? "\n" + note : ""}`;
  await sql`insert into mijoz.messages (client_id, direction, text, author) values (${c.client_id}, 'out', ${text}, ${admin.name})`;
  await notifyClient(Number(c.client_id), `📋 ${esc(text)}`, { text: "Ilovada ko'rish", path: "/kabinet?tab=complaints" });
  return json(req, { ok: true });
}

// ---------- chat ----------
async function chats(req: Request) {
  await currentAdmin(req);
  const rows = await db()`
    select c.id client_id, c.name, c.phone, m.text last_text, m.direction last_dir, m.created_at last_at,
      (select count(*)::int from mijoz.messages u where u.client_id = c.id and u.direction = 'in' and u.admin_read_at is null) unread
    from mijoz.clients c
    join lateral (select text, direction, created_at from mijoz.messages where client_id = c.id order by id desc limit 1) m on true
    order by m.created_at desc limit 200`;
  return json(req, { items: rows });
}

async function chatMessages(req: Request, clientId: number) {
  await currentAdmin(req);
  const sql = db();
  const rows = await sql`select id, direction, text, file_id, author, created_at, read_at from mijoz.messages where client_id = ${clientId} order by id desc limit 200`;
  await sql`update mijoz.messages set admin_read_at = now() where client_id = ${clientId} and direction = 'in' and admin_read_at is null`;
  const [c] = await sql`select id, name, phone, tg_chat_id is not null as telegram from mijoz.clients where id = ${clientId}`;
  return json(req, { client: c, items: rows.reverse().map((m: any) => ({ ...m, image_url: m.file_id ? `files/${m.file_id}` : null })) });
}

async function chatSend(req: Request, clientId: number) {
  const admin = await currentAdmin(req);
  const b = await readJson(req);
  const text = String(b.text ?? "").trim().slice(0, 2000);
  if (!text && !b.image) throw new HttpError(400, "empty", "Xabar bo'sh");
  const fileId = b.image ? await saveImage(b.image, `admin:${admin.phone_key}`) : null;
  const sql = db();
  const [m] = await sql`insert into mijoz.messages (client_id, direction, text, file_id, author) values (${clientId}, 'out', ${text || null}, ${fileId}, ${admin.name}) returning id`;
  const delivered = await notifyClient(clientId, `💬 <b>Menejer javobi</b>:\n${esc(text || "[rasm]")}`, { text: "Chatni ochish", path: "/chat" });
  return json(req, { id: m.id, telegram: delivered }, 201);
}

// ---------- qidiruv tahlili ----------
async function searchStats(req: Request, url: URL) {
  await currentAdmin(req);
  const days = Math.min(Number(url.searchParams.get("days") ?? 30) || 30, 365);
  const sql = db();
  const since = sql`now() - ${days + " days"}::interval`;
  const [notFound, top] = await Promise.all([
    sql`select q, count(*)::int n, count(distinct client_id)::int clients, max(created_at) last_at from mijoz.search_log
        where results = 0 and created_at > ${since} group by q order by n desc limit 50`,
    sql`select q, count(*)::int n, round(avg(results))::int avg_results from mijoz.search_log
        where created_at > ${since} group by q order by n desc limit 50`,
  ]);
  return json(req, { not_found: notFound, top });
}

// ---------- sinonimlar va qidiruvni sinash ----------
async function synonymsList(req: Request) {
  await currentAdmin(req);
  const rows = await db()`select id, words, updated_at from mijoz.synonyms order by updated_at desc, id desc`;
  return json(req, { items: rows });
}

async function synonymSave(req: Request) {
  await currentAdmin(req);
  const b = await readJson(req);
  const words = [...new Set(String(b.words ?? "").split(/[,;\n]+/).map((w) => w.trim()).filter(Boolean))].slice(0, 30);
  const normed = [...new Set(words.map(searchNorm).filter(Boolean))];
  if (normed.length < 2) throw new HttpError(400, "few_words", "Kamida 2 ta so'z yozing (vergul bilan ajrating)");
  const sql = db();
  const id = Number(b.id) || null;
  if (id) await sql`update mijoz.synonyms set words = ${words}, words_norm = ${normed}, updated_at = now() where id = ${id}`;
  else await sql`insert into mijoz.synonyms (words, words_norm) values (${words}, ${normed})`;
  await sql`select mijoz.refresh_vocab()`;
  dropSynonymCache();
  return json(req, { ok: true });
}

async function synonymDelete(req: Request, id: number) {
  await currentAdmin(req);
  await db()`delete from mijoz.synonyms where id = ${id}`;
  dropSynonymCache();
  return json(req, { ok: true });
}

/** Mijoz nima ko'rishini sinab ko'rish: so'rov qanday tushunildi va qaysi tovarlar chiqadi */
async function searchTest(req: Request, url: URL) {
  await currentAdmin(req);
  const sql = db();
  const pl = await searchPlan(url.searchParams.get("q") ?? "");
  if (!pl.q) return json(req, { understood: [], items: [], did_you_mean: [] });
  let items = await sql`select p.id, p.name, p.group_name, p.category_name, p.brand_name from mijoz.products p
    where p.active and ${matchCond(sql, pl)} order by (coalesce(p.stock,0) > 0) desc, p.name_lc limit 20`;
  let fuzzy = false, did_you_mean: string[] = [];
  if (!items.length) {
    did_you_mean = await didYouMean(pl);
    items = await sql`select p.id, p.name, p.group_name, p.category_name, p.brand_name from mijoz.products p
      where p.active and ${fuzzyCond(sql, pl)} order by ${fuzzyOrder(sql, pl)} limit 20`;
    fuzzy = items.length > 0;
  }
  const [{ n }] = await sql`select count(*)::int n from mijoz.products p where p.active and ${matchCond(sql, pl)}`;
  return json(req, { understood: pl.groups, total: n, items, fuzzy, did_you_mean });
}

// ---------- katalog bo'limlari ----------
async function sections(req: Request) {
  await currentAdmin(req);
  const sql = db();
  const [groups, categories, brands, hidden] = await Promise.all([
    sql`select group_id::text key, group_name name, count(*)::int n from mijoz.products where active and group_id is not null group by 1, 2 order by n desc`,
    sql`select category_id::text key, category_name name, count(*)::int n from mijoz.products where active and category_id is not null group by 1, 2 order by n desc`,
    sql`select brand_name key, brand_name name, count(*)::int n from mijoz.products where active and brand_name is not null and brand_name <> '' group by 1, 2 order by n desc`,
    sql`select kind, key from mijoz.hidden_sections`,
  ]);
  const h = new Set(hidden.map((x: any) => `${x.kind}:${x.key}`));
  const mark = (kind: string, rows: any[]) => rows.map((r) => ({ ...r, hidden: h.has(`${kind}:${r.key}`) }));
  return json(req, { group: mark("group", groups), category: mark("category", categories), brand: mark("brand", brands) });
}

async function sectionHide(req: Request) {
  await currentAdmin(req);
  const b = await readJson(req);
  const kind = String(b.kind), key = String(b.key ?? "").slice(0, 200);
  if (!["group", "category", "brand"].includes(kind) || !key) throw new HttpError(400, "bad_section");
  if (b.hidden) await db()`insert into mijoz.hidden_sections (kind, key) values (${kind}, ${key}) on conflict do nothing`;
  else await db()`delete from mijoz.hidden_sections where kind = ${kind} and key = ${key}`;
  return json(req, { ok: true });
}

// ---------- umumiy xabar ----------
async function broadcast(req: Request) {
  await currentAdmin(req);
  const b = await readJson(req);
  const text = String(b.text ?? "").trim().slice(0, 3000);
  if (text.length < 3) throw new HttpError(400, "empty", "Xabar matnini yozing");
  const sql = db();
  const targets = await sql`select distinct on (tg_chat_id) id from mijoz.clients where tg_chat_id is not null and active order by tg_chat_id, id`;
  if (b.dry_run) return json(req, { recipients: targets.length });
  let sent = 0;
  for (const t of targets) {
    if (await notifyClient(Number(t.id), `📢 ${esc(text)}`, b.link ? { text: "Ilovada ko'rish", path: String(b.link) } : { text: "Ilovani ochish", path: "/" })) sent++;
    await new Promise((r) => setTimeout(r, 40));
  }
  return json(req, { recipients: targets.length, sent });
}

// ---------- sozlamalar ----------
async function settingsGet(req: Request) {
  await currentAdmin(req);
  const sql = db();
  const admins = await sql`select phone_key, name, tg_chat_id is not null as telegram, active from mijoz.admins order by name`;
  const samples: Record<string, unknown> = {};
  for (const k of ["sample_product", "stock_sample", "sample_shipment", "sample_payment", "sample_return", "sample_order"]) samples[k] = await getState(k);
  return json(req, { settings: await getSettings(), admins, samples });
}

async function settingsSave(req: Request) {
  await currentAdmin(req);
  const before = Number((await getSettings()).usd_rate);
  await setSettings(await readJson(req));
  const st = await getSettings();
  // Kurs o'zgarsa — dollarli tovarlar narxini darhol qayta hisoblaymiz
  if (Number(st.usd_rate) > 0 && Number(st.usd_rate) !== before) {
    await db()`update mijoz.products set price = round(price_orig * ${Number(st.usd_rate)}::numeric, 0)
      where currency = 'USD' and price_orig is not null`;
  }
  return json(req, { ok: true, settings: st });
}

async function adminAdd(req: Request) {
  await currentAdmin(req);
  const b = await readJson(req);
  const key = phoneKey(b.phone);
  const name = String(b.name ?? "").trim().slice(0, 60);
  if (!key || !name) throw new HttpError(400, "bad", "Ism va raqamni kiriting");
  await db()`insert into mijoz.admins (phone_key, name, active) values (${key}, ${name}, ${b.active !== false})
    on conflict (phone_key) do update set name = excluded.name, active = excluded.active`;
  return json(req, { ok: true });
}

// ---------- marshrutlash ----------
Deno.serve(handle(async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^.*?\/admin(?=\/|$)/, "") || "/";
  const m = req.method;
  let r: RegExpMatchArray | null;

  if (m === "POST" && path === "/auth/request") return authRequest(req);
  if (m === "POST" && path === "/auth/verify") return authVerify(req);
  if (m === "POST" && path === "/auth/logout") {
    const t = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
    if (t) await db()`delete from mijoz.admin_sessions where token_hash = ${await sha256(t)}`;
    return json(req, { ok: true });
  }
  if (m === "GET" && path === "/me") return json(req, await currentAdmin(req));
  if (m === "GET" && path === "/stats") return stats(req);
  if (m === "GET" && path === "/orders") return orders(req, url);
  if (m === "GET" && (r = path.match(/^\/orders\/([0-9a-f-]{36})$/i))) return orderDetail(req, r[1]);
  if (m === "POST" && (r = path.match(/^\/orders\/([0-9a-f-]{36})\/resend$/i))) return orderResend(req, r[1]);
  if (m === "GET" && path === "/clients") return clients(req, url);
  if (m === "GET" && (r = path.match(/^\/clients\/(\d+)$/))) return clientDetail(req, Number(r[1]));
  if (m === "POST" && (r = path.match(/^\/clients\/(\d+)$/))) return clientUpdate(req, Number(r[1]));
  if (m === "GET" && path === "/products") return products(req, url);
  if (m === "POST" && path === "/products/box-bulk") return boxBulk(req);
  if (m === "POST" && path === "/products/accept-suggestions") return acceptSuggestions(req);
  if (m === "POST" && (r = path.match(/^\/products\/(\d+)$/))) return productUpdate(req, Number(r[1]));
  if (m === "GET" && path === "/banners") return banners(req);
  if (m === "POST" && path === "/banners") return bannerSave(req);
  if (m === "POST" && (r = path.match(/^\/banners\/(\d+)\/delete$/))) return bannerDelete(req, Number(r[1]));
  if (m === "GET" && path === "/complaints") return complaints(req, url);
  if (m === "POST" && (r = path.match(/^\/complaints\/(\d+)$/))) return complaintUpdate(req, Number(r[1]));
  if (m === "GET" && path === "/chats") return chats(req);
  if (m === "GET" && (r = path.match(/^\/chats\/(\d+)$/))) return chatMessages(req, Number(r[1]));
  if (m === "POST" && (r = path.match(/^\/chats\/(\d+)$/))) return chatSend(req, Number(r[1]));
  if (m === "GET" && path === "/search-stats") return searchStats(req, url);
  if (m === "GET" && path === "/search-test") return searchTest(req, url);
  if (m === "GET" && path === "/synonyms") return synonymsList(req);
  if (m === "POST" && path === "/synonyms") return synonymSave(req);
  if (m === "POST" && (r = path.match(/^\/synonyms\/(\d+)\/delete$/))) return synonymDelete(req, Number(r[1]));
  if (m === "GET" && path === "/sections") return sections(req);
  if (m === "POST" && path === "/sections") return sectionHide(req);
  if (m === "POST" && path === "/broadcast") return broadcast(req);
  if (m === "GET" && path === "/settings") return settingsGet(req);
  if (m === "POST" && path === "/settings") return settingsSave(req);
  if (m === "POST" && path === "/admins") return adminAdd(req);
  throw new HttpError(404, "not_found", "Bunday manzil yo'q");
}));
