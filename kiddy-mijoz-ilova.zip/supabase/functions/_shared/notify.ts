// Telegram xabarnomalari: mijozga va menejerlar guruhiga.
import { db } from "./db.ts";
import { config } from "./config.ts";
import { escapeHtml, sendMessage, tg } from "./telegram.ts";

export const fmt = (n: number) => Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
export const esc = escapeHtml;

function appButton(text: string, path: string) {
  const base = config.appUrl();
  return base ? { reply_markup: { inline_keyboard: [[{ text, url: base + "#" + path }]] } } : {};
}

/** Mijozga xabar (Telegram ulangan bo'lsa). true — yuborildi */
export async function notifyClient(clientId: number, html: string, button?: { text: string; path: string }): Promise<boolean> {
  if (!config.tgToken()) return false;
  const [c] = await db()`select tg_chat_id from mijoz.clients where id = ${clientId}`;
  if (!c?.tg_chat_id) return false;
  try {
    await sendMessage(c.tg_chat_id, html, button ? appButton(button.text, button.path) : {});
    return true;
  } catch (e) {
    console.error("notifyClient", clientId, (e as Error).message);
    // Mijoz botni bloklagan bo'lsa — bog'lanishni olib tashlaymiz
    if (/blocked|deactivated|chat not found/i.test((e as Error).message)) {
      await db()`update mijoz.clients set tg_chat_id = null where tg_chat_id = ${c.tg_chat_id}`;
    }
    return false;
  }
}

/** Menejerlar guruhiga xabar. Qaytaradi: Telegram xabar id (javobni bog'lash uchun) */
export async function notifyManagers(html: string, photoFileIds: string[] = []): Promise<number | null> {
  const chat = config.managerChatId();
  if (!chat || !config.tgToken()) return null;
  try {
    const msg = await sendMessage(chat, html);
    // Rasmlarni ham yuboramiz (bazadan)
    for (const id of photoFileIds.slice(0, 5)) {
      const [f] = await db()`select mime, bytes from mijoz.files where id = ${id}`;
      if (!f) continue;
      const form = new FormData();
      form.append("chat_id", chat);
      form.append("reply_to_message_id", String(msg.message_id));
      form.append("photo", new Blob([f.bytes], { type: f.mime }), "rasm.jpg");
      await fetch(`${config.tgApiBase()}/bot${config.tgToken()}/sendPhoto`, { method: "POST", body: form }).catch(() => {});
    }
    return msg.message_id as number;
  } catch (e) {
    console.error("notifyManagers", (e as Error).message);
    return null;
  }
}

export { tg };
