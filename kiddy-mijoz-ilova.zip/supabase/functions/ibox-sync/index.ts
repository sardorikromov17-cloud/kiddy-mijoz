// iBox → Supabase sinxronlash. Har 5 daqiqada pg_cron chaqiradi (README'ga qarang).
// Faqat o'zgarganlarni oladi (changed_since), narx/qoldiqni har safar to'liq yangilaydi,
// yuborilmay qolgan buyurtmalarni qayta yuboradi.
import { db, getState, setState } from "../_shared/db.ts";
import { config } from "../_shared/config.ts";
import { setDeadline, timeUp, iboxKeyset, iboxPaged, iboxRequest, mapClient, mapProduct, mapStock, phoneKey } from "../_shared/ibox.ts";
import { sendOrderToIbox } from "../_shared/orders.ts";
import { newArrivals, overdueReminders, stockAlerts, syncLedger, syncOrderStatuses } from "../_shared/sync-extra.ts";
import { handle, HttpError, json } from "../_shared/http.ts";
import { getSettings, setSettings } from "../_shared/settings.ts";

const CLIENT_COLS = ["id", "name", "code", "phone", "phone_key", "active", "in_black_list", "category_name",
  "counter_party", "parent_id", "credit_days", "ibox_updated_at"] as const;
const PRODUCT_COLS = ["id", "name", "sku", "comment", "type", "active", "unit", "category_id", "category_name",
  "group_id", "group_name", "brand_name", "photo_url", "photos", "barcodes", "box_qty_ibox", "box_qty_suggest", "ibox_updated_at"] as const;

function maxTs(a: string | null, b: string | null): string | null {
  if (!a) return b;
  if (!b) return a;
  return Date.parse(b) > Date.parse(a) ? b : a;
}

async function syncClients(): Promise<number> {
  const sql = db();
  const since = await getState("clients_changed_since");
  // Davom ettirish: "active:after_id:eng_yangi_vaqt" — oldingi chaqiruv vaqt tugab to'xtagan joy
  const cur = (await getState("clients_cursor"))?.split("|") ?? null;
  let latest = cur?.[2] || since, count = 0;
  for (const active of [true, false]) {
    if (cur && cur[0] === "false" && active) continue;
    const start = cur && String(active) === cur[0] ? Number(cur[1]) || null : null;
    for await (const page of iboxKeyset("outlet/client/list", { changed_since: since ?? undefined, active }, start)) {
      const rows = page.map(mapClient).map((r) => ({ ...r, counter_party: r.counter_party ? sql.json(r.counter_party) : null }));
      await sql`
        insert into mijoz.clients ${sql(rows, ...CLIENT_COLS)}
        on conflict (id) do update set
          name = excluded.name, code = excluded.code, phone = excluded.phone, phone_key = excluded.phone_key,
          active = excluded.active, in_black_list = excluded.in_black_list, category_name = excluded.category_name,
          counter_party = excluded.counter_party, parent_id = excluded.parent_id, credit_days = excluded.credit_days,
          ibox_updated_at = excluded.ibox_updated_at, synced_at = now()`;
      for (const r of page) latest = maxTs(latest, r.updated_at ?? null);
      count += rows.length;
      if (page.next != null && timeUp()) { await setState("clients_cursor", `${active}|${page.next}|${latest ?? ""}`); return count; }
    }
  }
  await setState("clients_cursor", "");
  if (latest) await setState("clients_changed_since", latest);
  return count;
}

async function syncProducts(): Promise<number> {
  const sql = db();
  let sampledProduct = false;
  const since = await getState("products_changed_since");
  const cur = (await getState("products_cursor"))?.split("|") ?? null;
  let latest = cur?.[2] || since, count = 0;
  for (const active of [true, false]) {
    if (cur && cur[0] === "false" && active) continue;
    const start = cur && String(active) === cur[0] ? Number(cur[1]) || null : null;
    // type=1 — faqat tovarlar (xizmatlar va to'plamlar emas)
    for await (const page of iboxKeyset("product/list", { changed_since: since ?? undefined, active, type: 1 }, start)) {
      const rows = page.map(mapProduct).map((r) => ({ ...r, photos: sql.json(r.photos) }));
      await sql`
        insert into mijoz.products ${sql(rows, ...PRODUCT_COLS)}
        on conflict (id) do update set
          name = excluded.name, sku = excluded.sku, comment = excluded.comment, type = excluded.type,
          active = excluded.active, unit = excluded.unit, category_id = excluded.category_id,
          category_name = excluded.category_name, group_id = excluded.group_id, group_name = excluded.group_name,
          brand_name = excluded.brand_name, photo_url = excluded.photo_url, photos = excluded.photos,
          barcodes = excluded.barcodes, box_qty_ibox = coalesce(excluded.box_qty_ibox, mijoz.products.box_qty_ibox),
          box_qty_suggest = excluded.box_qty_suggest, ibox_updated_at = excluded.ibox_updated_at, synced_at = now()`;
      if (!sampledProduct && page[0]) { await setState("sample_product", JSON.stringify(page[0]).slice(0, 4000)); sampledProduct = true; }
      for (const r of page) latest = maxTs(latest, r.updated_at ?? null);
      count += rows.length;
      if (page.next != null && timeUp()) {
        await setState("products_cursor", `${active}|${page.next}|${latest ?? ""}`);
        await applyBoxQty();
        return count;
      }
    }
  }
  await setState("products_cursor", "");
  if (latest) await setState("products_changed_since", latest);
  await applyBoxQty();
  if (count > 0) await db()`select mijoz.refresh_vocab()`; // qidiruv lug'ati
  return count;
}

/** Ishlatiladigan karobka soni: qo'lda kiritilgani → iBox'dagisi */
async function applyBoxQty() {
  await db()`update mijoz.products set box_qty = coalesce(box_qty_manual, box_qty_ibox)
    where box_qty is distinct from coalesce(box_qty_manual, box_qty_ibox)`;
}

async function syncStock(): Promise<number> {
  const sql = db();
  const started = new Date().toISOString();
  let count = 0, sampled = false;
  const rate = await syncRate();
  const query = {
    price_type_id: config.iboxPriceTypeId(),
    warehouse_id: config.iboxWarehouseId(),
    search_by: ["name"],
  };
  for await (const { rows, raw } of iboxPaged("document/stock/selection", query, 500)) {
    if (!sampled) {
      // Javob shaklini tekshirish uchun bitta namunani saqlaymiz
      await setState("stock_sample", JSON.stringify(rows[0] ?? raw).slice(0, 4000));
      sampled = true;
    }
    const mapped = rows.map(mapStock).filter((x): x is NonNullable<typeof x> => !!x);
    if (!mapped.length) continue;
    // Narx: dollarda bo'lsa kurs bo'yicha so'mga o'giriladi, asl narx price_orig'da qoladi
    await sql`
      update mijoz.products p set
        price_orig = coalesce(v.price::numeric, p.price_orig),
        currency = coalesce(v.currency, p.currency, 'UZS'),
        price = case when v.price is null then p.price
                     when coalesce(v.currency, p.currency) = 'USD' then round(v.price::numeric * ${rate}::numeric, 0)
                     else v.price::numeric end,
        stock = coalesce(v.stock::numeric, p.stock),
        min_qty = v.min_qty::numeric,
        box_qty_ibox = coalesce(v.box::int, p.box_qty_ibox),
        stock_synced_at = now()
      from (select * from jsonb_to_recordset(${sql.json(mapped)}::jsonb)
            as x(id bigint, price numeric, stock numeric, box int, currency text, min_qty numeric)) v
      where p.id = v.id`;
    count += mapped.length;
  }
  // Bu safar ro'yxatda chiqmagan tovarlar — omborda yo'q
  if (count > 0) {
    await sql`update mijoz.products set stock = 0 where active and (stock_synced_at is null or stock_synced_at < ${started})`;
  }
  await applyBoxQty();
  return count;
}

/**
 * Papkalar: iBox'dagi papka daraxti va har papkadagi tovarlar.
 * Integratsiya API tovar ro'yxatida papka yo'q — stock/selection'ni papka bo'yicha filtrlab olamiz.
 */
async function syncFolders(): Promise<number> {
  const sql = db();
  const res = await iboxRequest("GET", "core/directory", { query: { data: "product_folder_tree" } });
  const tree: any[] = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
  const flat: { id: number; parent_id: number | null; name: string; sort: number }[] = [];
  const walk = (list: any[]) => { for (const f of list ?? []) { flat.push({ id: Number(f.id), parent_id: f.parent_id ?? null, name: String(f.name ?? "").trim(), sort: flat.length }); walk(f.children); } };
  walk(tree);
  if (!flat.length) { await sql`update mijoz.products set folder_id = null where folder_id is not null`; return 0; }
  await sql`insert into mijoz.folders ${sql(flat, "id", "parent_id", "name", "sort")}
    on conflict (id) do update set name = excluded.name, parent_id = excluded.parent_id, sort = excluded.sort, synced_at = now()`;
  await sql`delete from mijoz.folders where not (id = any(${flat.map((f) => f.id)}::bigint[]))`;
  const assign: { id: number; folder: number }[] = [];
  const priceType = config.iboxPriceTypeId(), warehouse = config.iboxWarehouseId();
  for (const f of flat) {
    if (timeUp()) return -2; // keyingi chaqiruvda davom etadi
    for await (const { rows } of iboxPaged("document/stock/selection",
      { price_type_id: priceType, warehouse_id: warehouse || undefined, product_folder_id: f.id }, 500)) {
      for (const r of rows) if (r?.id) assign.push({ id: Number(r.id), folder: f.id });
    }
  }
  await sql.begin(async (tx: any) => {
    await tx`update mijoz.products set folder_id = null where folder_id is not null`;
    if (assign.length) {
      await tx`update mijoz.products p set folder_id = v.folder
        from (select * from jsonb_to_recordset(${tx.json(assign)}::jsonb) as x(id bigint, folder bigint)) v where p.id = v.id`;
    }
  });
  return assign.length;
}

/** Dollar kursi: iBox valyutalar ma'lumotnomasidan (sozlamada avtomatik yoqilgan bo'lsa) */
async function syncRate(): Promise<number> {
  const s = await getSettings();
  let rate = Number(s.usd_rate) || 12300;
  if (!s.usd_rate_auto) return rate;
  try {
    const res = await iboxRequest("GET", "core/directory", { query: { data: "core_currency", per_page: 100 } });
    const list: any[] = Array.isArray(res?.data) ? res.data : Array.isArray(res?.data?.data) ? res.data.data : [];
    const usd = list.find((c) => String(c?.code ?? c?.name ?? "").toUpperCase().includes("USD"));
    const r = Number(usd?.exchange_rate ?? usd?.rate ?? usd?.current_rate ?? usd?.default_exchange_rate);
    if (Number.isFinite(r) && r > 1000 && r < 100000 && Math.abs(r - rate) > 0.009) {
      rate = r;
      await setSettings({ usd_rate: r });
      // Kurs o'zgardi — barcha dollarli narxlarni qayta hisoblaymiz
      await db()`update mijoz.products set price = round(price_orig * ${r}::numeric, 0)
        where currency = 'USD' and price_orig is not null`;
    }
  } catch (e) {
    console.error("kurs", (e as Error).message);
  }
  return rate;
}

/** "-17529500.0000 UZS, -120.5000 USD" → { UZS: -17529500, USD: -120.5 } */
function parseMulti(s: unknown): Record<string, number> {
  const out: Record<string, number> = {};
  for (const m of String(s ?? "").matchAll(/(-?[\d\s.,]+?)\s*([A-Z]{3})/g)) {
    const n = Number(m[1].replace(/\s/g, "").replace(",", "."));
    if (Number.isFinite(n)) out[m[2]] = (out[m[2]] ?? 0) + n;
  }
  return out;
}

/**
 * Mijozlarning aniq qoldig'i — iBox "Qarzdorlar" ro'yxatidan.
 * Integratsiya tokeni bu ro'yxatga ruxsat bermasa, jim o'tkazib yuboriladi (hujjatlardan hisoblangani qoladi).
 */
async function syncDebts(): Promise<number> {
  const sql = db();
  const rows: any[] = [];
  try {
    for await (const { rows: page } of iboxPaged("/outlet/client/debtors", {}, 200)) rows.push(...page);
  } catch (e) {
    const st = (e as any)?.status;
    if (st === 401 || st === 403 || st === 404) { await setState("debts_unavailable", String(st)); return -1; }
    throw e;
  }
  const rate = Number((await getSettings()).usd_rate) || 12300;
  const data = rows.map((r) => {
    const t = parseMulti(r.total);
    const base = Number(r.total_in_base);
    // iBox'da manfiy = mijoz qarzdor. Bizda + = qarz.
    return {
      id: Number(r.id),
      uzs: -(t.UZS ?? 0), usd: -(t.USD ?? 0),
      base: Number.isFinite(base) ? -Math.round(base * 100) / 100 : -((t.UZS ?? 0) + (t.USD ?? 0) * rate),
    };
  }).filter((r) => Number.isFinite(r.id));
  await sql.begin(async (tx: any) => {
    if (data.length) {
      await tx`
        update mijoz.clients c set ibox_debt_uzs = v.uzs, ibox_debt_usd = v.usd, ibox_debt_base = v.base, ibox_debt_at = now()
        from (select * from jsonb_to_recordset(${tx.json(data)}::jsonb) as x(id bigint, uzs numeric, usd numeric, base numeric)) v
        where c.id = v.id`;
    }
    // Ro'yxatda yo'q mijozlar — qarzi yo'q
    await tx`update mijoz.clients set ibox_debt_uzs = 0, ibox_debt_usd = 0, ibox_debt_base = 0, ibox_debt_at = now()
      where not (id = any(${data.map((d) => d.id)}::bigint[]))`;
  });
  await setState("debts_unavailable", "");
  return data.length;
}

async function retryOrders(): Promise<number> {
  const rows = await db()`
    select id from mijoz.orders
    where (status = 'new' and created_at < now() - interval '1 minute')
       or (status = 'failed' and send_attempts < 5)
    order by created_at limit 20`;
  let ok = 0;
  for (const r of rows) if ((await sendOrderToIbox(r.id)).ok) ok++;
  return ok;
}

Deno.serve(handle(async (req) => {
  const auth = req.headers.get("authorization") ?? "";
  if (auth !== `Bearer ${config.syncSecret()}`) throw new HttpError(401, "unauthorized");

  const body = req.method === "POST" ? await req.json().catch(() => ({})) : {};

  // O'rnatish yordamchisi (setup/ornatish.mjs): birinchi admin va avtomatik sinxronlash (pg_cron)
  if (body?.setup) {
    const sql = db();
    const out: Record<string, unknown> = {};
    const st = body.setup;
    const key = phoneKey(st.admin_phone);
    if (key && st.admin_name) {
      await sql`insert into mijoz.admins (phone_key, name) values (${key}, ${String(st.admin_name).slice(0, 60)})
        on conflict (phone_key) do update set name = excluded.name, active = true`;
      out.admin = "ok";
    }
    if (st.cron_url) {
      try {
        await sql.unsafe("create extension if not exists pg_cron");
        await sql.unsafe("create extension if not exists pg_net");
        const secrets: [string, string][] = [["kiddy_sync_secret", config.syncSecret()], ["kiddy_sync_url", String(st.cron_url)]];
        for (const [name, value] of secrets) {
          const [ex] = await sql`select id from vault.secrets where name = ${name}`;
          if (ex) await sql`select vault.update_secret(${ex.id}::uuid, ${value})`;
          else await sql`select vault.create_secret(${value}, ${name})`;
        }
        await sql`select cron.unschedule('kiddy-ibox-sync') where exists (select 1 from cron.job where jobname = 'kiddy-ibox-sync')`;
        await sql.unsafe(`select cron.schedule('kiddy-ibox-sync', '*/5 * * * *', $job$
          select net.http_post(
            url := (select decrypted_secret from vault.decrypted_secrets where name = 'kiddy_sync_url'),
            headers := jsonb_build_object('Content-Type', 'application/json',
              'Authorization', 'Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name = 'kiddy_sync_secret')),
            body := '{}'::jsonb, timeout_milliseconds := 120000);
        $job$)`);
        out.cron = "ok";
      } catch (e) {
        out.cron = `xato: ${(e as Error).message}. supabase/cron.sql ni SQL Editor'da qo'lda bajaring.`;
      }
    }
    return json(req, out);
  }

  // Sozlash yordamchisi: narx turlari, omborlar, valyutalar va filiallar ro'yxatini ko'rsatadi
  if (body?.show === "directories") {
    const out: Record<string, unknown> = {};
    for (const d of ["product_price_type", "core_warehouse", "core_currency"]) {
      try { out[d] = (await iboxRequest("GET", "core/directory", { query: { data: d, per_page: 100 } }))?.data; }
      catch (e) { out[d] = { error: String((e as Error).message) }; }
    }
    try { out.filials = (await iboxRequest("GET", "core/directory/filial"))?.data; }
    catch (e) { out.filials = { error: String((e as Error).message) }; }
    for (const k of ["sample_product", "stock_sample", "sample_shipment", "sample_payment", "sample_return", "sample_order"]) out[k] = await getState(k);
    return json(req, out);
  }

  const only: string[] | undefined = body?.only;
  const steps: Record<string, () => Promise<number>> = {
    clients: syncClients, products: syncProducts, stock: syncStock, folders: syncFolders, orders: retryOrders, debts: syncDebts,
    ledger: () => syncLedger(!!body?.full), order_status: syncOrderStatuses,
    stock_alerts: stockAlerts, news: newArrivals, overdue: overdueReminders,
  };
  const result: Record<string, unknown> = {};
  setDeadline(Number(body?.budget_ms) || 100_000);
  for (const [name, fn] of Object.entries(steps)) {
    if (only && !only.includes(name)) continue;
    if (timeUp()) { result[name] = { ok: true, skipped: true }; continue; } // keyingi chaqiruvda
    const t = Date.now();
    try {
      result[name] = { ok: true, count: await fn(), ms: Date.now() - t };
      await setState(`last_ok_${name}`, new Date().toISOString());
    } catch (e) {
      const msg = String((e as Error)?.message ?? e).slice(0, 1000);
      console.error(name, msg);
      result[name] = { ok: false, error: msg };
      await setState(`last_error_${name}`, `${new Date().toISOString()} ${msg}`);
    }
  }
  return json(req, result);
}));
