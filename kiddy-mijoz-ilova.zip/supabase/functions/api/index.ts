// Mijozlar ilovasi uchun API (…/functions/v1/api/…)
//
// Kirish:      GET /config · POST /auth/request · POST /auth/verify · POST /auth/logout · GET /me
// Katalog:     GET /home · GET /categories · GET /catalog · GET /suggest?q= · GET /products · GET /products/:id · GET /barcode/:code
// Shaxsiy:     POST /favorites · POST /alerts · POST /me/settings
// Buyurtma:    POST /orders · GET /orders · GET /orders/:id
// Oldi-berdi:  GET /ledger · POST /ledger/akt · GET /akt?t=…  (imzolangan havola orqali PDF)
// Aloqa:       GET /messages · POST /messages · GET /complaints · POST /complaints
// Fayllar:     GET /files/:id
import { db } from "../_shared/db.ts";
import { config } from "../_shared/config.ts";
import { phoneKey } from "../_shared/ibox.ts";
import { corsHeaders, handle, HttpError, json, randomCode, randomToken, readJson, sha256 } from "../_shared/http.ts";
import { sendOrderToIbox } from "../_shared/orders.ts";
import { sendDocument, sendMessage } from "../_shared/telegram.ts";
import { getSettings } from "../_shared/settings.ts";
import { clientBalance, clientLedger } from "../_shared/ledger.ts";
import { fileResponse, saveImage } from "../_shared/files.ts";
import { esc, fmt, notifyClient, notifyManagers } from "../_shared/notify.ts";
import { aktPdf } from "../_shared/pdf.ts";
import { didYouMean, fuzzyCond, fuzzyOrder, matchCond, norm as searchNorm, plan as searchPlan } from "../_shared/search.ts";
import { signPayload, verifyPayload } from "../_shared/sign.ts";

const SESSION_DAYS = 90;
const CODE_TTL_MIN = 5;
const CODE_RESEND_SEC = 60;
const CODE_MAX_ATTEMPTS = 5;
const COMPANY = "Kiddy Toys Kokand";

const PRODUCT_FIELDS = `p.id, p.name, p.sku, p.unit, p.category_id, p.category_name, p.brand_name, p.group_id, p.group_name, p.photo_url, p.photos,
  p.barcodes, p.box_qty, p.price::float8 as price, p.stock::float8 as stock, p.promo_label,
  p.price_orig::float8 as price_orig, coalesce(p.currency, 'UZS') as currency, p.min_qty::float8 as min_qty,
  p.promo_old_price::float8 as promo_old_price, p.first_seen_at`;

// ---------- yordamchilar ----------

function botUrl(): string | null {
  const u = config.tgBotUsername().replace(/^@/, "");
  return u ? `https://t.me/${u}` : null;
}

async function currentClient(req: Request) {
  const m = (req.headers.get("authorization") ?? "").match(/^Bearer\s+(.+)$/i);
  const token = req.headers.get("x-session") ?? m?.[1];
  if (!token) throw new HttpError(401, "no_session", "Qayta kiring");
  const hash = await sha256(token);
  const rows = await db()`
    update mijoz.sessions s set last_seen_at = now(),
      -- har foydalanganda muddat uzayadi: ilovani ishlatib turgan mijoz qayta kod so'ramaydi
      expires_at = greatest(s.expires_at, now() + ${SESSION_DAYS + " days"}::interval)
    from mijoz.clients c
    where s.token_hash = ${hash} and s.expires_at > now() and c.id = s.client_id and c.active and not c.in_black_list
    returning c.id, c.name, c.code, c.phone, c.category_name, c.credit_days, c.tg_chat_id, c.notify_news,
      c.credit_limit::float8 as credit_limit, c.min_order_sum::float8 as min_order_sum`;
  if (!rows.length) throw new HttpError(401, "no_session", "Qayta kiring");
  return rows[0];
}

function clientView(c: any) {
  return {
    id: c.id, name: c.name, code: c.code, phone: c.phone, category: c.category_name,
    credit_days: c.credit_days, telegram_linked: !!c.tg_chat_id, notify_news: c.notify_news !== false,
  };
}

let setCache = { v: { new_days: 14, show_usd: true }, at: 0 };
async function cachedSettings() {
  if (Date.now() - setCache.at > 60_000) {
    const st = await getSettings();
    setCache = { v: { new_days: st.new_days, show_usd: !!st.show_usd }, at: Date.now() };
  }
  return setCache.v;
}
async function newDays() { return (await cachedSettings()).new_days; }

async function decorate(rows: any[], clientId: number) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const sql = db();
  const [favs, alerts, baseline] = await Promise.all([
    sql`select product_id from mijoz.favorites where client_id = ${clientId} and product_id = any(${ids}::bigint[])`,
    sql`select product_id from mijoz.stock_alerts where client_id = ${clientId} and notified_at is null and product_id = any(${ids}::bigint[])`,
    sql`select value from mijoz.sync_state where key = 'catalog_baseline'`,
  ]);
  const fav = new Set(favs.map((r: any) => Number(r.product_id)));
  const al = new Set(alerts.map((r: any) => Number(r.product_id)));
  const base = baseline[0]?.value ? Date.parse(baseline[0].value) : Infinity;
  const cs = await cachedSettings();
  const newSince = Date.now() - cs.new_days * 86400_000;
  return rows.map((p) => {
    const seen = p.first_seen_at ? new Date(p.first_seen_at).getTime() : 0;
    const { first_seen_at: _f, price_orig: _po, ...rest } = p;
    return {
      ...rest, photos: Array.isArray(p.photos) ? p.photos : [],
      // Dollarli tovar: asl narx ($) — ixtiyoriy ko'rsatiladi
      usd: cs.show_usd && p.currency === "USD" && p.price_orig ? Number(p.price_orig) : null,
      can_order: p.price !== null && p.price > 0,
      is_fav: fav.has(Number(p.id)), alert_on: al.has(Number(p.id)),
      is_new: seen > base && seen > newSince,
    };
  });
}

async function effectiveMinOrder(client: any) {
  if (client.min_order_sum != null) return Number(client.min_order_sum);
  return (await getSettings()).min_order_sum;
}

// ---------- kirish ----------

async function authRequest(req: Request) {
  const { phone } = await readJson(req);
  const key = phoneKey(phone);
  if (!key) throw new HttpError(400, "bad_phone", "Telefon raqamni to'liq kiriting");
  const sql = db();
  const clients = await sql`select id, tg_chat_id from mijoz.clients where phone_key = ${key} and active and not in_black_list`;
  if (!clients.length) throw new HttpError(404, "not_registered", "Bu raqam mijozlar bazasida yo'q. Menejerga murojaat qiling.");
  const chatId = clients.find((c: any) => c.tg_chat_id)?.tg_chat_id;
  if (!chatId && !config.devMode()) return json(req, { sent: false, need_telegram: true, bot_url: botUrl() });

  const [prev] = await sql`select created_at from mijoz.login_codes where phone_key = ${key}`;
  if (prev && Date.now() - new Date(prev.created_at).getTime() < CODE_RESEND_SEC * 1000) {
    throw new HttpError(429, "too_soon", "Kod yaqinda yuborildi. Bir daqiqadan keyin qayta so'rang.");
  }
  const code = randomCode(4);
  await sql`
    insert into mijoz.login_codes (phone_key, code_hash, attempts, expires_at, created_at)
    values (${key}, ${await sha256(key + ":" + code)}, 0, now() + ${CODE_TTL_MIN + " minutes"}::interval, now())
    on conflict (phone_key) do update set code_hash = excluded.code_hash, attempts = 0, expires_at = excluded.expires_at, created_at = now()`;
  if (chatId) {
    try { await sendMessage(chatId, `🔐 Kiddy Toys ilovasiga kirish kodi: <b>${code}</b>\n\nKod ${CODE_TTL_MIN} daqiqa amal qiladi. Uni hech kimga aytmang.`); }
    catch (e) {
      console.error("tg code", e);
      await sql`delete from mijoz.login_codes where phone_key = ${key}`;
      throw new HttpError(502, "telegram_failed", "Telegram'ga kod yuborib bo'lmadi. Botni bloklamaganingizni tekshiring va qayta urinib ko'ring.");
    }
  }
  return json(req, { sent: true, via: chatId ? "telegram" : "dev", ...(config.devMode() ? { dev_code: code } : {}) });
}

async function authVerify(req: Request) {
  const { phone, code, client_id } = await readJson(req);
  const key = phoneKey(phone);
  if (!key || !/^\d{4}$/.test(String(code ?? ""))) throw new HttpError(400, "bad_code", "Kodni to'g'ri kiriting");
  const sql = db();
  const [row] = await sql`select * from mijoz.login_codes where phone_key = ${key}`;
  if (!row || new Date(row.expires_at) < new Date()) throw new HttpError(400, "code_expired", "Kod eskirgan. Yangi kod oling.");
  if (row.attempts >= CODE_MAX_ATTEMPTS) throw new HttpError(429, "too_many", "Ko'p urinish. Yangi kod oling.");
  if (row.code_hash !== await sha256(key + ":" + String(code))) {
    await sql`update mijoz.login_codes set attempts = attempts + 1 where phone_key = ${key}`;
    throw new HttpError(400, "wrong_code", "Kod noto'g'ri");
  }
  const clients = await sql`
    select id, name, code, phone, category_name, credit_days, tg_chat_id, notify_news
    from mijoz.clients where phone_key = ${key} and active and not in_black_list order by name`;
  if (!clients.length) throw new HttpError(404, "not_registered", "Mijoz topilmadi");
  let client = clients[0];
  if (clients.length > 1) {
    const chosen = clients.find((c: any) => Number(c.id) === Number(client_id));
    if (!chosen) return json(req, { choose: clients.map((c: any) => ({ id: c.id, name: c.name })) });
    client = chosen;
  }
  await sql`delete from mijoz.login_codes where phone_key = ${key}`;
  const token = randomToken();
  await sql`insert into mijoz.sessions (token_hash, client_id, expires_at)
    values (${await sha256(token)}, ${client.id}, now() + ${SESSION_DAYS + " days"}::interval)`;
  return json(req, { token, client: clientView(client) });
}

async function authLogout(req: Request) {
  const token = req.headers.get("x-session") ?? (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (token) await db()`delete from mijoz.sessions where token_hash = ${await sha256(token)}`;
  return json(req, { ok: true });
}

// ---------- bosh sahifa va katalog ----------

async function home(req: Request) {
  const client = await currentClient(req);
  const sql = db();
  const s = await getSettings();
  const [banners, frequent, unread, lastOrder] = await Promise.all([
    sql`select id, title, subtitle, image_id, color, link_type, link_value from mijoz.banners
        where active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())
        order by sort, id desc limit 10`,
    // Tez-tez oladiganlarim: so'nggi 180 kundagi buyurtmalar bo'yicha
    sql`select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p
        join (select i.product_id, count(distinct i.order_id) n, sum(i.qty) q from mijoz.order_items i
              join mijoz.orders o on o.id = i.order_id
              where o.client_id = ${client.id} and o.created_at > now() - interval '180 days' and o.status <> 'cancelled'
              group by i.product_id) f on f.product_id = p.id
        where p.active order by f.n desc, f.q desc limit 10`,
    sql`select count(*)::int n from mijoz.messages where client_id = ${client.id} and direction = 'out' and read_at is null`,
    sql`select id, no, status, total::float8 as total, created_at from mijoz.orders where client_id = ${client.id} order by created_at desc limit 1`,
  ]);
  let ledger = null;
  if (s.ledger_enabled) {
    const l = await clientLedger(Number(client.id));
    if (l) ledger = { debt: l.debt, advance: l.advance, overdue: l.overdue, credit_limit: l.client.credit_limit, parts: l.parts };
  }
  return json(req, {
    banners: banners.map((b: any) => ({ ...b, image_url: b.image_id ? `files/${b.image_id}` : null })),
    frequent: await decorate(frequent, client.id),
    unread_messages: unread[0].n,
    last_order: lastOrder[0] ?? null,
    min_order_sum: await effectiveMinOrder(client),
    default_mode: s.default_mode,
    ledger_enabled: s.ledger_enabled,
    ledger,
  });
}

async function listProducts(req: Request, url: URL) {
  const client = await currentClient(req);
  const sql = db();
  // Savatni yangilash: ?ids=1,2,3 — joriy narx, qoldiq va karobka soni
  const idsParam = url.searchParams.get("ids");
  if (idsParam !== null) {
    const ids = idsParam.split(",").map(Number).filter(Number.isInteger).slice(0, 300);
    const rows = ids.length ? await sql`select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p where p.active and p.id = any(${ids}::bigint[])` : [];
    return json(req, { items: await decorate(rows, client.id), has_more: false, next_offset: 0 });
  }
  const rawQ = (url.searchParams.get("q") ?? "").trim().slice(0, 100);
  const qLower = rawQ.toLowerCase();
  const category = Number(url.searchParams.get("category") ?? "") || null;
  const group = Number(url.searchParams.get("group") ?? "") || null;
  const brand = (url.searchParams.get("brand") ?? "").trim().slice(0, 100) || null;
  const inStock = url.searchParams.get("in_stock") === "1";
  const favOnly = url.searchParams.get("fav") === "1";
  const promoOnly = url.searchParams.get("promo") === "1";
  const sort = url.searchParams.get("sort") === "new" ? "new" : "name";
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? 30) || 30, 1), 100);
  const offset = Math.max(Number(url.searchParams.get("offset") ?? 0) || 0, 0);

  const pl = await searchPlan(rawQ);
  const filters = sql`p.active and not mijoz.is_hidden(p.group_id, p.category_id, p.brand_name)
      and ${category ? sql`p.category_id = ${category}` : sql`true`}
      and ${group ? sql`p.group_id = ${group}` : sql`true`}
      and ${brand ? sql`p.brand_name = ${brand}` : sql`true`}
      and ${inStock ? sql`coalesce(p.stock, 0) > 0` : sql`true`}
      and ${promoOnly ? sql`p.promo_label is not null` : sql`true`}
      and ${favOnly ? sql`exists (select 1 from mijoz.favorites f where f.client_id = ${client.id} and f.product_id = p.id)` : sql`true`}`;
  const exact = rawQ ? sql`(lower(p.sku) = ${qLower} or ${rawQ} = any(p.barcodes))` : sql`false`;
  const searchCond = pl.q ? sql`(${exact} or (${matchCond(sql, pl)}))` : sql`true`;

  let rows = await sql`
    select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p
    where ${filters} and ${searchCond}
    order by ${pl.q ? sql`${exact} desc,` : sql``} ${sort === "new" ? sql`p.first_seen_at desc, p.id desc` : sql`(coalesce(p.stock,0) > 0) desc, p.name_lc`}
    limit ${limit + 1} offset ${offset}`;

  // Hech narsa topilmasa: xatoli yozuvga o'xshash tovarlar + "Balki siz … ni qidirdingiz?"
  let fuzzy = false;
  let did_you_mean: string[] = [];
  if (pl.q && offset === 0 && rows.length === 0) {
    did_you_mean = await didYouMean(pl);
    rows = await sql`
      select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p
      where ${filters} and ${fuzzyCond(sql, pl)}
      order by ${fuzzyOrder(sql, pl)}, (coalesce(p.stock,0) > 0) desc
      limit ${limit}`;
    fuzzy = rows.length > 0;
    // O'xshashi ham topilmasa — eng yaqin to'g'rilangan so'z bo'yicha qidiramiz
    if (!fuzzy && did_you_mean[0]) {
      const fixed = await searchPlan(did_you_mean[0]);
      rows = await sql`
        select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p
        where ${filters} and ${matchCond(sql, fixed)}
        order by (coalesce(p.stock,0) > 0) desc, p.name_lc limit ${limit}`;
      fuzzy = rows.length > 0;
    }
  }
  const has_more = !fuzzy && rows.length > limit;
  const items = await decorate(rows.slice(0, limit), client.id);
  if (rawQ && offset === 0) {
    sql`insert into mijoz.search_log (client_id, q, results) values (${client.id}, ${qLower}, ${fuzzy ? 0 : items.length})`.catch(() => {});
  }
  return json(req, { items, has_more, next_offset: offset + limit, fuzzy, did_you_mean });
}

/** Qidiruv maydoni ostidagi takliflar: bo'limlar, brendlar va so'zlar */
async function suggest(req: Request, url: URL) {
  await currentClient(req);
  const sql = db();
  const n = searchNorm(url.searchParams.get("q") ?? "").slice(0, 60);
  if (n.length < 2) return json(req, { items: [] });
  const last = n.split(" ").at(-1)!;
  const head = n.split(" ").slice(0, -1).join(" ");
  const pfx = `(^| )${last.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`;
  const [groups, cats, brands, words, syns] = await Promise.all([
    sql`select id, name, product_count n from mijoz.product_groups where mijoz.norm(name) ~ ${pfx} order by product_count desc limit 3`,
    sql`select category_id id, category_name name, count(*)::int n from mijoz.products where active and category_id is not null and not mijoz.is_hidden(group_id, category_id, brand_name) and mijoz.norm(category_name) ~ ${pfx} group by 1, 2 order by n desc limit 4`,
    sql`select name, product_count n from mijoz.brands where mijoz.norm(name) ~ ${pfx} order by product_count desc limit 3`,
    sql`select word from mijoz.search_vocab where word like ${last + "%"} and word <> ${last} order by n desc limit 5`,
    // Sinonim: "кукл" → "qo'g'irchoq"
    sql`select words[1] w from mijoz.synonyms where exists (select 1 from unnest(words_norm) x where x like ${last + "%"}) limit 2`,
  ]);
  let fixes: string[] = [];
  if (!words.length && last.length >= 3) {
    const r = await sql`select word from mijoz.search_vocab where extensions.similarity(word, ${last}) > 0.35
      order by extensions.similarity(word, ${last}) desc, n desc limit 3`;
    fixes = r.map((x: any) => x.word);
  }
  const items = [
    ...groups.map((g: any) => ({ type: "group", id: g.id, label: g.name, n: g.n })),
    ...cats.map((c: any) => ({ type: "category", id: c.id, label: c.name, n: c.n })),
    ...brands.map((b: any) => ({ type: "brand", id: b.name, label: b.name, n: b.n })),
    ...[...new Set([...syns.map((x: any) => String(x.w)), ...words.map((w: any) => w.word), ...fixes])]
      .map((w: string) => ({ type: "query", label: head ? `${head} ${w}` : w })),
  ].slice(0, 10);
  return json(req, { items });
}

/** Katalog bo'limlari: guruhlar, kategoriyalar (tanlangan guruh ichida), brendlar */
async function catalogTree(req: Request, url: URL) {
  await currentClient(req);
  const sql = db();
  const group = Number(url.searchParams.get("group") ?? "") || null;
  const inStock = url.searchParams.get("in_stock") === "1";
  const st = inStock ? sql`and coalesce(stock,0) > 0 and not mijoz.is_hidden(group_id, category_id, brand_name)` : sql`and not mijoz.is_hidden(group_id, category_id, brand_name)`;
  const g = group ? sql`and group_id = ${group}` : sql``;
  const [groups, categories, brands] = await Promise.all([
    sql`select group_id id, group_name name, count(*)::int n from mijoz.products
        where active and group_id is not null ${st} group by 1, 2 order by n desc, name`,
    sql`select category_id id, category_name name, count(*)::int n from mijoz.products
        where active and category_id is not null ${st} ${g} group by 1, 2 order by n desc, name`,
    sql`select brand_name name, count(*)::int n from mijoz.products
        where active and brand_name is not null and brand_name <> '' ${st} ${g} group by 1 order by n desc, name limit 200`,
  ]);
  return json(req, { groups, categories, brands });
}

async function getProduct(req: Request, id: number) {
  const client = await currentClient(req);
  const sql = db();
  const [p] = await sql`select ${sql.unsafe(PRODUCT_FIELDS)}, p.comment from mijoz.products p where p.id = ${id} and p.active`;
  if (!p) throw new HttpError(404, "not_found", "Tovar topilmadi");
  return json(req, (await decorate([p], client.id))[0]);
}

async function byBarcode(req: Request, code: string) {
  const client = await currentClient(req);
  const sql = db();
  const c = code.trim();
  const rows = await sql`
    select ${sql.unsafe(PRODUCT_FIELDS)} from mijoz.products p
    where p.active and (${c} = any(p.barcodes) or lower(p.sku) = ${c.toLowerCase()}) limit 5`;
  if (!rows.length) {
    sql`insert into mijoz.search_log (client_id, q, results) values (${client.id}, ${"[shtrix] " + c}, 0)`.catch(() => {});
    throw new HttpError(404, "not_found", "Bu shtrix-kod bo'yicha tovar topilmadi");
  }
  return json(req, { items: await decorate(rows, client.id) });
}

async function categories(req: Request) {
  await currentClient(req);
  const rows = await db()`select id, name, product_count from mijoz.categories order by product_count desc, name`;
  return json(req, { items: rows });
}

// ---------- sevimlilar, "kelganda xabar ber", sozlamalar ----------

async function toggle(req: Request, table: "favorites" | "stock_alerts") {
  const client = await currentClient(req);
  const { product_id, on } = await readJson(req);
  const pid = Number(product_id);
  if (!Number.isInteger(pid)) throw new HttpError(400, "bad_product");
  const sql = db();
  if (on) {
    const [p] = await sql`select id from mijoz.products where id = ${pid} and active`;
    if (!p) throw new HttpError(404, "not_found", "Tovar topilmadi");
    if (table === "favorites") {
      await sql`insert into mijoz.favorites (client_id, product_id) values (${client.id}, ${pid}) on conflict do nothing`;
    } else {
      await sql`insert into mijoz.stock_alerts (client_id, product_id) values (${client.id}, ${pid})
        on conflict (client_id, product_id) do update set notified_at = null, created_at = now()`;
    }
  } else {
    if (table === "favorites") await sql`delete from mijoz.favorites where client_id = ${client.id} and product_id = ${pid}`;
    else await sql`delete from mijoz.stock_alerts where client_id = ${client.id} and product_id = ${pid}`;
  }
  return json(req, { ok: true, on: !!on, telegram_linked: !!client.tg_chat_id });
}

async function meSettings(req: Request) {
  const client = await currentClient(req);
  const b = await readJson(req);
  if (typeof b.notify_news === "boolean") await db()`update mijoz.clients set notify_news = ${b.notify_news} where id = ${client.id}`;
  return json(req, { ok: true });
}

// ---------- buyurtmalar ----------

const STATUS_UZ: Record<string, string> = {
  new: "Yuborilmoqda", sent: "Qabul qilindi", failed: "Yuborilmoqda", accepted: "Tasdiqlandi",
  shipped: "Jo'natishga tayyor", on_way: "Yo'lda", delivered: "Yetkazildi", cancelled: "Bekor qilindi",
};

/** "12 karobka + 5 dona (293 dona)" ko'rinishidagi qisqa matn */
function packText(lines: { qty: number; box_qty: number | null; mode: string }[]) {
  let boxes = 0, loose = 0, total = 0;
  for (const l of lines) {
    total += l.qty;
    if (l.mode === "box" && l.box_qty) { boxes += Math.floor(l.qty / l.box_qty); loose += l.qty % l.box_qty; }
    else loose += l.qty;
  }
  if (!boxes) return `${fmt(total)} dona`;
  return `${fmt(boxes)} karobka${loose ? ` + ${fmt(loose)} dona` : ""} (${fmt(total)} dona)`;
}

async function createOrder(req: Request) {
  const client = await currentClient(req);
  const body = await readJson(req);
  const comment = typeof body.comment === "string" ? body.comment.trim().slice(0, 500) : null;
  if (!Array.isArray(body.items) || !body.items.length) throw new HttpError(400, "empty", "Savat bo'sh");
  if (body.items.length > 200) throw new HttpError(400, "too_many", "Bitta buyurtmada 200 tadan ko'p tovar bo'lmasin");

  // qty — har doim dona hisobida; mode — mijoz qaysi birlikda tanlagani (karobka/dona)
  const qtyById = new Map<number, number>();
  const modeById = new Map<number, string>();
  for (const it of body.items) {
    const id = Number(it?.product_id), qty = Number(it?.qty);
    if (!Number.isInteger(id) || !Number.isFinite(qty) || qty <= 0 || qty > 1000000) throw new HttpError(400, "bad_item", "Miqdor noto'g'ri");
    qtyById.set(id, (qtyById.get(id) ?? 0) + qty);
    modeById.set(id, it?.mode === "box" ? "box" : "unit");
  }
  const sql = db();
  const ids = [...qtyById.keys()];
  const products = await sql`
    select id, name, price::float8 as price, box_qty, price_orig::float8 as price_orig, coalesce(currency, 'UZS') as currency from mijoz.products
    where id = any(${ids}::bigint[]) and active and price is not null and price > 0`;
  if (products.length !== ids.length) {
    const found = new Set(products.map((p: any) => Number(p.id)));
    return json(req, { error: "unavailable", message: "Ba'zi tovarlar endi sotuvda yo'q yoki narxi qo'yilmagan", product_ids: ids.filter((id) => !found.has(id)) }, 409);
  }
  const lines = products.map((p: any) => {
    const qty = qtyById.get(Number(p.id))!;
    const box = p.box_qty && p.box_qty > 1 ? Number(p.box_qty) : null;
    const mode = box && modeById.get(Number(p.id)) === "box" ? "box" : "unit";
    return { product_id: p.id, name: p.name, qty, price: p.price, total: Math.round(p.price * qty * 100) / 100, box_qty: box, mode,
      price_orig: p.price_orig ?? p.price, currency: p.currency };
  });
  const total = lines.reduce((s: number, l: any) => s + l.total, 0);
  const units = lines.reduce((s: number, l: any) => s + l.qty, 0);

  // Minimal summa
  const minSum = await effectiveMinOrder(client);
  if (minSum > 0 && total < minSum) {
    return json(req, { error: "min_order", message: `Minimal buyurtma summasi — ${fmt(minSum)} so'm. Yana ${fmt(minSum - total)} so'mlik tovar qo'shing.`, min_order_sum: minSum }, 409);
  }
  // Kredit limiti
  const s = await getSettings();
  if (s.ledger_enabled && s.block_over_limit && client.credit_limit != null) {
    const bal = await clientBalance(Number(client.id));
    if (bal + total > Number(client.credit_limit)) {
      const room = Math.max(0, Number(client.credit_limit) - bal);
      return json(req, {
        error: "over_limit",
        message: `Kredit limitingiz ${fmt(client.credit_limit)} so'm. Hozirgi qarz ${fmt(bal)} so'm, yana ${fmt(room)} so'mlik buyurtma berish mumkin. Qarzni to'lang yoki menejerga yozing.`,
      }, 409);
    }
  }

  const order = await sql.begin(async (tx: any) => {
    const [o] = await tx`insert into mijoz.orders (client_id, comment, total, units, usd_rate)
      values (${client.id}, ${comment}, ${total}, ${units}, ${Number(s.usd_rate) || null}) returning id, no, created_at`;
    await tx`insert into mijoz.order_items ${tx(lines.map((l: any) => ({ ...l, order_id: o.id })), "order_id", "product_id", "name", "qty", "price", "total", "box_qty", "mode", "price_orig", "currency")}`;
    return o;
  });
  const sent = await sendOrderToIbox(order.id).catch((e) => ({ ok: false, error: String(e) }));

  const qtyText = packText(lines);
  notifyClient(Number(client.id),
    `🧾 Buyurtma <b>№${order.no}</b> qabul qilindi\n${lines.length} xil, ${qtyText}\nSumma: <b>${fmt(total)} so'm</b>\n\nMenejer tasdiqlagach xabar beramiz.` +
    (comment ? `\nIzoh: ${esc(comment)}` : ""), { text: "Buyurtmani ko'rish", path: `/buyurtma/${order.id}` }).catch(() => {});
  notifyManagers(`🆕 Yangi buyurtma <b>№${order.no}</b> (iBox: M-${order.no})\n${esc(client.name)}\n${lines.length} xil, ${qtyText} — <b>${fmt(total)} so'm</b>` +
    (comment ? `\nIzoh: ${esc(comment)}` : "") + (sent.ok ? "" : "\n⚠️ iBox'ga hali yetib bormadi, qayta yuboriladi")).catch(() => {});

  return json(req, { id: order.id, no: order.no, status: sent.ok ? "sent" : "new", total, units }, 201);
}

async function listOrders(req: Request) {
  const client = await currentClient(req);
  const rows = await db()`
    select o.id, o.no, o.status, o.total::float8 as total, o.units::float8 as units, o.comment, o.created_at, o.ibox_number,
      (select count(*)::int from mijoz.order_items i where i.order_id = o.id) as lines
    from mijoz.orders o where o.client_id = ${client.id} order by o.created_at desc limit 50`;
  return json(req, { items: rows.map((r: any) => ({ ...r, status_text: STATUS_UZ[r.status] ?? r.status })) });
}

async function getOrder(req: Request, id: string) {
  const client = await currentClient(req);
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new HttpError(404, "not_found");
  const sql = db();
  const [o] = await sql`select id, no, status, total::float8 as total, units::float8 as units, comment, created_at, ibox_number, status_changed_at
    from mijoz.orders where id = ${id} and client_id = ${client.id}`;
  if (!o) throw new HttpError(404, "not_found", "Buyurtma topilmadi");
  const items = await sql`
    select i.product_id, i.name, i.qty::float8 as qty, i.price::float8 as price, i.total::float8 as total, i.box_qty, i.mode,
      p.photo_url, p.box_qty as current_box_qty, p.unit
    from mijoz.order_items i left join mijoz.products p on p.id = i.product_id where i.order_id = ${id} order by i.id`;
  return json(req, { ...o, status_text: STATUS_UZ[o.status] ?? o.status, items });
}

// ---------- oldi-berdi ----------

const dateParam = (v: string | null) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);

async function ledger(req: Request, url: URL) {
  const client = await currentClient(req);
  if (!(await getSettings()).ledger_enabled) throw new HttpError(403, "ledger_off", "Oldi-berdi bo'limi tez orada ishga tushadi");
  const l = await clientLedger(Number(client.id), dateParam(url.searchParams.get("from")), dateParam(url.searchParams.get("to")));
  if (!l) throw new HttpError(404, "not_found");
  const { client: _c, ...rest } = l;
  return json(req, { ...rest, entries: rest.entries.slice().reverse().slice(0, 300) });
}

async function buildAkt(clientId: number, from: string | null, to: string | null) {
  const toDate = to ?? new Date(Date.now() + 5 * 3600_000).toISOString().slice(0, 10);
  const l = await clientLedger(clientId, from, toDate);
  if (!l) throw new HttpError(404, "not_found");
  const pdf = await aktPdf({
    company: COMPANY, client: l.client, from, to: toDate,
    sections: (l.usd_used ? ["UZS", "USD"] as const : ["UZS"] as const).map((cur) => ({
      cur, ...l.period.cur[cur], entries: l.entries.filter((e) => e.currency === cur),
    })),
  });
  return { pdf, name: `akt-sverka_${toDate}.pdf`, closing: l.period.closing };
}

/** POST /ledger/akt {from, to, via: 'telegram'|'link'} */
async function aktRequest(req: Request) {
  const client = await currentClient(req);
  if (!(await getSettings()).ledger_enabled) throw new HttpError(403, "ledger_off", "Oldi-berdi bo'limi hali yoqilmagan");
  const b = await readJson(req);
  const from = dateParam(b.from), to = dateParam(b.to);
  if (b.via === "telegram") {
    if (!client.tg_chat_id) throw new HttpError(400, "no_telegram", "Telegram ulanmagan");
    const akt = await buildAkt(Number(client.id), from, to);
    await sendDocument(client.tg_chat_id, akt.pdf, akt.name, `📄 Akt-sverka · ${esc(client.name)}`);
    return json(req, { ok: true, via: "telegram" });
  }
  const t = await signPayload({ c: Number(client.id), f: from, t: to }, 300);
  return json(req, { ok: true, via: "link", url: `akt?t=${encodeURIComponent(t)}` });
}

/** GET /akt?t=… — imzolangan havola orqali PDF (5 daqiqa amal qiladi) */
async function aktDownload(req: Request, url: URL) {
  const p = await verifyPayload(url.searchParams.get("t") ?? "");
  if (!p) throw new HttpError(403, "expired", "Havola eskirgan. Ilovadan qayta oching.");
  const akt = await buildAkt(Number(p.c), p.f ?? null, p.t ?? null);
  return new Response(akt.pdf as BodyInit, {
    headers: { ...corsHeaders(req), "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="${akt.name}"`, "Cache-Control": "no-store" },
  });
}

// ---------- chat va shikoyatlar ----------

async function listMessages(req: Request, url: URL) {
  const client = await currentClient(req);
  const sql = db();
  const after = Number(url.searchParams.get("after") ?? 0) || 0;
  const rows = await sql`
    select id, direction, text, file_id, author, created_at from mijoz.messages
    where client_id = ${client.id} and id > ${after} order by id desc limit 100`;
  await sql`update mijoz.messages set read_at = now() where client_id = ${client.id} and direction = 'out' and read_at is null`;
  return json(req, { items: rows.reverse().map((m: any) => ({ ...m, image_url: m.file_id ? `files/${m.file_id}` : null })) });
}

async function postMessage(req: Request) {
  const client = await currentClient(req);
  const b = await readJson(req);
  const text = typeof b.text === "string" ? b.text.trim().slice(0, 2000) : "";
  if (!text && !b.image) throw new HttpError(400, "empty", "Xabar bo'sh");
  const sql = db();
  const [{ n }] = await sql`select count(*)::int n from mijoz.messages where client_id = ${client.id} and direction = 'in' and created_at > now() - interval '1 minute'`;
  if (n >= 10) throw new HttpError(429, "too_fast", "Juda tez yozyapsiz. Biroz kuting.");
  const fileId = b.image ? await saveImage(b.image, `client:${client.id}`) : null;
  const [m] = await sql`insert into mijoz.messages (client_id, direction, text, file_id) values (${client.id}, 'in', ${text || null}, ${fileId}) returning id, created_at`;
  const tgId = await notifyManagers(
    `💬 <b>${esc(client.name)}</b> (${esc(client.phone ?? "")}) · #m${client.id}\n${text ? esc(text) : "[rasm]"}\n\n<i>Javob berish uchun shu xabarga "Reply" qiling.</i>`,
    fileId ? [fileId] : []);
  if (tgId) await sql`update mijoz.messages set tg_message_id = ${tgId} where id = ${m.id}`;
  return json(req, { id: m.id, created_at: m.created_at, delivered: !!tgId }, 201);
}

const COMPLAINT_STATUS: Record<string, string> = { new: "Ko'rib chiqilmoqda", accepted: "Qabul qilindi", rejected: "Rad etildi", done: "Hal qilindi" };

async function listComplaints(req: Request) {
  const client = await currentClient(req);
  const rows = await db()`
    select c.id, c.kind, c.qty::float8 as qty, c.reason, c.file_ids, c.status, c.admin_note, c.created_at,
      o.no as order_no, p.name as product_name
    from mijoz.complaints c left join mijoz.orders o on o.id = c.order_id left join mijoz.products p on p.id = c.product_id
    where c.client_id = ${client.id} order by c.created_at desc limit 50`;
  return json(req, { items: rows.map((r: any) => ({ ...r, status_text: COMPLAINT_STATUS[r.status], images: (r.file_ids ?? []).map((f: string) => `files/${f}`) })) });
}

async function postComplaint(req: Request) {
  const client = await currentClient(req);
  const b = await readJson(req);
  const reason = String(b.reason ?? "").trim().slice(0, 2000);
  if (reason.length < 3) throw new HttpError(400, "no_reason", "Sababini yozing");
  const kind = b.kind === "complaint" ? "complaint" : "return";
  const sql = db();
  let orderId: string | null = null, orderNo: number | null = null;
  if (b.order_id) {
    const [o] = await sql`select id, no from mijoz.orders where id = ${String(b.order_id)} and client_id = ${client.id}`;
    if (!o) throw new HttpError(404, "not_found", "Buyurtma topilmadi");
    orderId = o.id; orderNo = o.no;
  }
  let productName: string | null = null, productId: number | null = null;
  if (b.product_id) {
    const [p] = await sql`select id, name from mijoz.products where id = ${Number(b.product_id)}`;
    if (p) { productId = p.id; productName = p.name; }
  }
  const qty = b.qty != null && Number(b.qty) > 0 ? Number(b.qty) : null;
  const images: string[] = Array.isArray(b.images) ? b.images.slice(0, 4) : [];
  const fileIds: string[] = [];
  for (const img of images) fileIds.push(await saveImage(img, `client:${client.id}`));
  const [c] = await sql`
    insert into mijoz.complaints (client_id, order_id, product_id, kind, qty, reason, file_ids)
    values (${client.id}, ${orderId}, ${productId}, ${kind}, ${qty}, ${reason}, ${fileIds}::uuid[]) returning id`;
  const tgId = await notifyManagers(
    `${kind === "return" ? "↩️ <b>Qaytarish so'rovi</b>" : "⚠️ <b>Shikoyat</b>"} #${c.id}\n${esc(client.name)} (${esc(client.phone ?? "")})` +
    (orderNo ? `\nBuyurtma №${orderNo}` : "") + (productName ? `\nTovar: ${esc(productName)}` : "") + (qty ? `, ${fmt(qty)} dona` : "") +
    `\n\n${esc(reason)}`, fileIds);
  if (tgId) await sql`update mijoz.complaints set tg_message_id = ${tgId} where id = ${c.id}`;
  return json(req, { id: c.id }, 201);
}

// ---------- marshrutlash ----------

Deno.serve(handle(async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^.*?\/api(?=\/|$)/, "") || "/";
  const m = req.method;
  let r: RegExpMatchArray | null;

  if (m === "GET" && path === "/config") {
    const st = await getSettings();
    return json(req, { bot_url: botUrl(), manager_phone: config.managerPhone() || null, usd_rate: Number(st.usd_rate) || null, show_usd: !!st.show_usd });
  }
  if (m === "POST" && path === "/auth/request") return authRequest(req);
  if (m === "POST" && path === "/auth/verify") return authVerify(req);
  if (m === "POST" && path === "/auth/logout") return authLogout(req);
  if (m === "GET" && path === "/me") return json(req, clientView(await currentClient(req)));
  if (m === "POST" && path === "/me/settings") return meSettings(req);
  if (m === "GET" && path === "/home") return home(req);
  if (m === "GET" && path === "/categories") return categories(req);
  if (m === "GET" && path === "/catalog") return catalogTree(req, url);
  if (m === "GET" && path === "/suggest") return suggest(req, url);
  if (m === "GET" && path === "/products") return listProducts(req, url);
  if (m === "GET" && (r = path.match(/^\/products\/(\d+)$/))) return getProduct(req, Number(r[1]));
  if (m === "GET" && (r = path.match(/^\/barcode\/([^/]{1,64})$/))) return byBarcode(req, decodeURIComponent(r[1]));
  if (m === "POST" && path === "/favorites") return toggle(req, "favorites");
  if (m === "POST" && path === "/alerts") return toggle(req, "stock_alerts");
  if (m === "POST" && path === "/orders") return createOrder(req);
  if (m === "GET" && path === "/orders") return listOrders(req);
  if (m === "GET" && (r = path.match(/^\/orders\/([^/]+)$/))) return getOrder(req, r[1]);
  if (m === "GET" && path === "/ledger") return ledger(req, url);
  if (m === "POST" && path === "/ledger/akt") return aktRequest(req);
  if (m === "GET" && path === "/akt") return aktDownload(req, url);
  if (m === "GET" && path === "/messages") return listMessages(req, url);
  if (m === "POST" && path === "/messages") return postMessage(req);
  if (m === "GET" && path === "/complaints") return listComplaints(req);
  if (m === "POST" && path === "/complaints") return postComplaint(req);
  if (m === "GET" && (r = path.match(/^\/files\/([0-9a-f-]{36})$/i))) return fileResponse(r[1], corsHeaders(req));
  throw new HttpError(404, "not_found", "Bunday manzil yo'q");
}));
