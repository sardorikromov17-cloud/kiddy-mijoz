// Sinov uchun soxta iBox API. Javob shakllari docsify.smpro.uz hujjatidagi misollardan olingan.
// Ishga tushirish: deno run -A dev/mock-ibox.ts   (port 8787)
const TOKEN = "test-token";
const products = [
  { id: 101, name: "Radio boshqaruvli mashina", sku: "RC-01", barcodes: ["4600234100234"], cat: [1, "Mashinalar"] },
  { id: 102, name: "Inertsion mashina, 4 xil", sku: "IN-04", barcodes: ["4600234100518"], cat: [1, "Mashinalar"] },
  { id: 103, name: "Konstruktor, 500 detal", sku: "KN-500", barcodes: ["4600234100771"], cat: [2, "Konstruktorlar"] },
  { id: 104, name: "Yumshoq ayiq 40 sm", sku: "AY-40", barcodes: ["4600234100902"], cat: [3, "Yumshoq o'yinchoqlar"] },
  { id: 105, name: "Eski tovar (o'chirilgan)", sku: "OLD", barcodes: [], cat: [1, "Mashinalar"], active: false },
  { id: 107, name: "Yumshoq kubiklar 1/48", sku: "KB-48", barcodes: ["4600234101077"], cat: [2, "Konstruktorlar"] },
  // Kiddy Toys iBox'idagidek: narx dollarda, karobka "units" ichida, shtrix-kod satr ko'rinishida
  { id: 108, name: "008-959 TRYUMO", sku: null, barcodes: "40000305", cat: [4, "BOLALAR MEBELI"] },
  { id: 109, name: "Qo'g'irchoq Barbi 30 sm", sku: "BR-30", barcodes: ["4600234101091"], cat: [5, "QO'G'IRCHOQLAR"] },
].map((p, i) => ({
  id: p.id, name: p.name, sku: p.sku, comment: null, type: 1, active: p.active ?? true, vat_percent: 12,
  photo_url: null, photos: [], storage_unit: { id: 3, name: "dona", short_name: "dona" },
  product_category: { id: p.cat[0], name: p.cat[1] },
  product_group: [101, 102, 107].includes(p.id) ? { id: 20, name: "O'G'IL BOLALAR UCHUN" } : [109, 108].includes(p.id) ? { id: 26, name: "QIZLAR UCHUN" } : { id: 21, name: "RIVOJLANTIRUVCHI" },
  product_brand: p.id === 103 ? { id: 5, name: "LEGO" } : { id: 31, name: "XITOY TAVARLAR" },
  barcodes: p.barcodes, updated_at: `2026-11-20T10:0${i}:00+05:00`,
  // Karobka soni iBox'da turli ko'rinishda kelishi mumkin — sinov uchun ikki xil shakl
  ...(p.id === 102 ? { units: [{ name: "dona", coefficient: 1 }, { name: "Karobka", coefficient: 48 }] } : {}),
  ...(p.id === 103 ? { box_quantity: 20 } : {}),
  ...(p.id === 108 ? { pack: "4.0000 krb", pack_quantities: [{ coefficient: 4, bar_code: "40000399", unit: { id: 7, name: "karobka", short_name: "krb" } }] } : {}),
}));
const stock: Record<number, [number, number]> = { 101: [185000, 86], 102: [24000, 320], 103: [142000, 18], 104: [65000, 0], 107: [9000, 960], 108: [22.2, 40], 109: [55000, 120] };
const usdIds = new Set([108]);
const clients = [
  { id: 1024, name: "«Bolajon» do'koni", code: "C-1024", main_phone: "+998 90 123-45-67" },
  { id: 1025, name: "«Quvonch» market", code: "C-1025", main_phone: "998911112233" },
  { id: 1026, name: "«Quvonch» market — 2-filial", code: "C-1026", main_phone: "91 111 22 33" },
].map((c, i) => ({
  ...c, active: true, in_black_list: false, cashback_percentage: null, outlet_category: null,
  counter_party: { id: 300 + i, name: c.name, type: 1, credit_days: 30 }, parent: null,
  updated_at: `2026-11-19T12:0${i}:00+05:00`,
}));
export const orders: any[] = [];
// Oldi-berdi hujjatlari (hujjatda javob shakli yo'q — Laravel paginator shaklida taxmin qilingan)
const docs: Record<string, any[]> = {
  shipment: [
    { id: 501, number: "S-501", date: "2026-10-05", outlet_id: 1024, status: 23, total: 9_850_000, parent_id: null },
    { id: 502, number: "S-502", date: "2026-11-09", outlet_id: 1024, status: 23, total: 4_670_000, parent_id: null },
    { id: 503, number: "S-503", date: "2026-11-10", outlet_id: 1024, status: 21, total: 999_999, parent_id: null }, // qoralama
    // Haqiqiy iBox shakli: sana UTC vaqt bilan, valyuta alohida (bu jo'natma dollarda)
    { id: 504, number: "S-504", date: "2026-11-20T20:30:00.000000Z", currency_id: 2, currency_code: "USD", outlet_id: 1024, status: 24, total: 350.5, parent_id: null },
  ],
  payment: [
    { id: 701, number: "P-701", date: "2026-11-03", outlet: { id: 1024 }, status: 73, payment_details: [{ amount: 2_500_000 }] },
    { id: 702, number: "P-702", date: "2026-11-18", outlet: { id: 1024 }, status: 73, payment_details: [{ amount: 3_500_000 }] },
    { id: 703, number: "P-703", date: "2026-11-22T09:00:00.000000Z", currency_id: 2, currency_code: "USD", outlet_id: 1024, status: 73, total: 100 },
  ],
  return: [{ id: 901, number: "R-901", date: "2026-11-12", outlet_id: 1024, status: 33, total: 320_000 }],
};
function paged(rows: any[], url: URL) {
  const perPage = Number(url.searchParams.get("per_page") ?? 15), page = Number(url.searchParams.get("page") ?? 1);
  return { data: rows.slice((page - 1) * perPage, page * perPage), meta: { current_page: page, last_page: Math.max(1, Math.ceil(rows.length / perPage)), total: rows.length } };
}

function keyset(rows: any[], url: URL) {
  const limit = Number(url.searchParams.get("limit") ?? 100);
  const after = Number(url.searchParams.get("after_id") ?? 0);
  const active = !["0", "false", "no", "off"].includes(url.searchParams.get("active") ?? "1");
  const since = url.searchParams.get("changed_since");
  let list = rows.filter((r) => r.id > after && r.active === active);
  if (since) list = list.filter((r) => Date.parse(r.updated_at) >= Date.parse(since));
  const page = list.slice(0, limit);
  return { data: page, meta: { limit, count: page.length, next_after_id: page.at(-1)?.id ?? null, has_more: list.length > limit } };
}

Deno.serve({ port: 8787 }, async (req) => {
  const url = new URL(req.url);
  const j = (d: unknown, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });
  if (req.headers.get("authorization") !== `Bearer ${TOKEN}`) return j({ message: "token.invalid" }, 401);
  if (!req.headers.get("filial-id")) return j({ message: "bad.filial" }, 401);
  const p = url.pathname.replace("/api/integration/", "");
  if (p === "product/list") return j(keyset(products, url));
  if (p === "outlet/client/list") return j(keyset(clients, url));
  if (p === "document/stock/selection") {
    const perPage = Number(url.searchParams.get("per_page") ?? 20), page = Number(url.searchParams.get("page") ?? 1);
    // Haqiqiy iBox javobi shakli: stock, price, currency_code, units
    const all = Object.entries(stock).map(([id, [price, available]]) => ({
      id: Number(id), name: products.find((x) => x.id === Number(id))!.name, price, stock: available,
      currency_id: usdIds.has(Number(id)) ? 2 : 1, currency_code: usdIds.has(Number(id)) ? "USD" : "UZS", minimum_sales_quantity: null,
      units: Number(id) === 108 ? [{ id: 1, name: "Dona", short_name: "dn", coefficient: 1 }, { id: 7, name: "karobka", short_name: "krb", coefficient: 4 }] : [{ id: 1, name: "Dona", short_name: "dn", coefficient: 1 }],
    }));
    return j({ data: all.slice((page - 1) * perPage, page * perPage), meta: { current_page: page, last_page: Math.ceil(all.length / perPage) } });
  }
  if (p === "core/directory" && url.searchParams.get("data") === "core_currency") {
    return j({ data: [{ id: 1, name: "UZS", code: "UZS", is_base: true, default_exchange_rate: null },
      { id: 2, name: "Amerika dollari", code: "USD", is_base: false, default_exchange_rate: "12300.0000" }] });
  }
  // Haqiqiy iBox'da integratsiya kaliti bu ro'yxatga kira olmaydi (401)
  if (p === "/api/outlet/client/debtors" && !Deno.env.get("MOCK_DEBTORS")) return j({ message: "token.invalid" }, 401);
  if (p === "/api/outlet/client/debtors") {
    return j({ current_page: 1, last_page: 1, total: 1, data: [
      { id: 1024, name: "«Bolajon» do'koni", total: "-1500000.0000 UZS, -120.0000 USD", total_in_base: "-2976000.00000000" }] });
  }
  if (p === "document/order" && req.method === "POST") {
    const body = await req.json();
    if (!body.outlet_id || !Array.isArray(body.order_details) || !body.order_details.length) return j({ message: "error messages", errors: { order_details: ["required"] } }, 422);
    const id = orders.length + 1;
    orders.push({ id, ...body });
    console.log("ORDER", JSON.stringify(body));
    return j({ messages: "", data: { id, number: String(id), date: body.date, status: 42 } }, 201);
  }
  if (p === "_orders") return j(orders);
  if (p === "document/order/list") return j(paged(orders.map((o) => ({ id: o.id, number: o.number, date: o.date, outlet_id: o.outlet_id, status: o.status_now ?? 42 })), url));
  if (p === "document/shipment/list") return j(paged(docs.shipment, url));
  if (p === "document/payment-received/list") return j(paged(docs.payment, url));
  if (p === "document/return/list") return j(paged(docs.return, url));
  // Sinov uchun: buyurtma holatini o'zgartirish va jo'natma yaratish
  if (p === "_set_order" && req.method === "POST") {
    const b = await req.json(); const o = orders.find((x) => x.id === b.id); if (o) o.status_now = b.status;
    if (b.ship && o) docs.shipment.push({ id: 600 + o.id, number: "S-" + (600 + o.id), date: o.date, outlet_id: o.outlet_id, status: 23,
      total: o.order_details.reduce((s: number, d: any) => s + d.total, 0), parent_id: o.id });
    return j({ ok: true });
  }
  if (p === "_stock" && req.method === "POST") { const b = await req.json(); stock[b.id] = [stock[b.id]?.[0] ?? 10000, b.qty]; return j({ ok: true }); }
  if (p === "_new_product" && req.method === "POST") {
    const b = await req.json();
    products.push({ ...products[0], id: b.id, name: b.name, sku: "N-" + b.id, barcodes: [], updated_at: new Date().toISOString() });
    stock[b.id] = [b.price, 50]; return j({ ok: true });
  }
  return j({ message: "Not found" }, 404);
});
