#!/usr/bin/env node
// Kiddy Toys mijozlar ilovasi — o'rnatish yordamchisi.
// Ishga tushirish: Windows'da ORNATISH.bat ni ikki marta bosing, yoki terminalda:  node setup/ornatish.mjs
// Yordamchi savollar beradi va hammasini o'zi bajaradi. Qayta ishga tushirsangiz, oldingi javoblarni eslab qoladi.
// Maxfiy qiymatlar (tokenlar) faqat Supabase Secrets'ga yoziladi, diskda saqlanmaydi.

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdtempSync } from "node:fs";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import * as readline from "node:readline";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const STATE_FILE = join(ROOT, "setup", ".ornatish.json");
const IS_WIN = process.platform === "win32";
// Faqat sinov uchun: soxta Telegram / server manzillari
const TG_API = process.env.KT_TG_API || "https://api.telegram.org";

// ---------- ko'rinish ----------
const c = { g: (s) => `\x1b[32m${s}\x1b[0m`, r: (s) => `\x1b[31m${s}\x1b[0m`, y: (s) => `\x1b[33m${s}\x1b[0m`, b: (s) => `\x1b[36m${s}\x1b[0m`, d: (s) => `\x1b[2m${s}\x1b[0m` };
let stepNo = 0;
const step = (t) => console.log(`\n${c.b(`━━━ ${++stepNo}. ${t} ━━━`)}`);
const ok = (t) => console.log(c.g("✔ ") + t);
const warn = (t) => console.log(c.y("! ") + t);
const bad = (t) => console.log(c.r("✖ ") + t);
const info = (t) => console.log(c.d(t));

// ---------- savollar ----------
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
// Kiritilgan qatorlar navbati: javob savoldan oldin kelsa ham yo'qolmaydi
const lines = [], waiters = [];
let inputClosed = false;
rl.on("line", (l) => (waiters.length ? waiters.shift()(l) : lines.push(l)));
rl.on("close", () => { inputClosed = true; while (waiters.length) waiters.shift()(null); });
const nextLine = () => (lines.length ? Promise.resolve(lines.shift()) : inputClosed ? Promise.resolve(null) : new Promise((r) => waiters.push(r)));
async function ask(q, def = "") {
  process.stdout.write(`${q}${def ? c.d(` [${def}]`) : ""}: `);
  const a = await nextLine();
  if (a === null) { console.log(); bad("Kiritish to'xtadi"); process.exit(1); }
  if (!process.stdin.isTTY) console.log(a);
  return a.trim() || def;
}
async function askSecret(q) {
  // Yashirin kiritish: belgilar ekranda ko'rinmaydi
  if (!process.stdin.isTTY) return ask(q);
  process.stdout.write(`${q} ${c.d("(yozganingiz ko'rinmaydi)")}: `);
  rl.pause();
  return await new Promise((res) => {
    let v = "";
    const onData = (buf) => {
      for (const ch of buf.toString("utf8")) {
        if (ch === "\r" || ch === "\n") {
          process.stdin.setRawMode(false); process.stdin.off("data", onData); process.stdout.write("\n"); rl.resume(); res(v.trim()); return;
        }
        if (ch === "\u0003") process.exit(1);
        if (ch === "\u007f" || ch === "\b") v = v.slice(0, -1); else v += ch;
      }
    };
    process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.on("data", onData);
  });
}
// h = ha, y = yo'q
const yes = async (q, def = "h") => /^(h|ha|xa|ok)$/i.test(await ask(`${q} (h — ha, y — yo'q)`, def));
async function choose(q, items, label, def) {
  items.forEach((it, i) => console.log(`  ${c.b(String(i + 1).padStart(2))}. ${label(it)}`));
  for (;;) {
    const a = await ask(q, def ? String(def) : "1");
    const n = Number(a);
    if (Number.isInteger(n) && n >= 1 && n <= items.length) return items[n - 1];
    bad("Ro'yxatdagi raqamni kiriting");
  }
}

// ---------- buyruqlar ----------
function run(cmd, args, { capture = false, input } = {}) {
  const stdio = capture ? ["pipe", "pipe", "pipe"] : input !== undefined ? ["pipe", "inherit", "inherit"] : "inherit";
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio, shell: IS_WIN, encoding: "utf8", input });
  return { ok: r.status === 0, out: (r.stdout || "") + (r.stderr || "") };
}
const supa = (args, opts) => run("npx", ["--yes", "supabase@2", ...args], opts);

async function retry(title, fn) {
  for (;;) {
    try { return await fn(); }
    catch (e) {
      bad(`${title}: ${e.message}`);
      if (!(await yes("Qayta urinib ko'ramizmi?", "h"))) throw e;
    }
  }
}

// ---------- holat ----------
const state = existsSync(STATE_FILE) ? JSON.parse(readFileSync(STATE_FILE, "utf8")) : {};
const save = () => writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
const secret = (n = 24) => randomBytes(n).toString("base64url");
const phoneKey = (p) => { const d = String(p || "").replace(/\D/g, ""); return d.length >= 9 ? d.slice(-9) : null; };

// ---------- iBox ----------
async function ibox(base, token, filial, path, query = "") {
  const res = await fetch(`${base}/api/integration/${path}${query}`, {
    headers: { Authorization: `Bearer ${token}`, "Filial-Id": String(filial), Accept: "application/json" },
    signal: AbortSignal.timeout(30000),
  });
  const text = await res.text();
  let j = null; try { j = JSON.parse(text); } catch { /* */ }
  if (!res.ok) throw new Error(`iBox ${res.status}: ${(j && (j.message || j.messages)) || text.slice(0, 200)}`);
  return j;
}
const listOf = (r) => (Array.isArray(r?.data) ? r.data : Array.isArray(r?.data?.data) ? r.data.data : Array.isArray(r) ? r : []);

// ---------- Telegram ----------
async function tg(token, method, body) {
  const res = await fetch(`${TG_API}/bot${token}/${method}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}), signal: AbortSignal.timeout(20000),
  });
  const j = await res.json();
  if (!j.ok) throw new Error(j.description || `Telegram ${res.status}`);
  return j.result;
}

// =====================================================================
async function main() {
  console.log(c.b("\n  Kiddy Toys — mijozlar ilovasini o'rnatish yordamchisi\n"));
  info("  Har bir savolga javob yozib Enter bosing. Qavs ichidagi qiymat — standart, shunchaki Enter bosish mumkin.");
  info("  Istalgan vaqtda to'xtatib (Ctrl+C), keyin qayta ishga tushirish mumkin — javoblar eslab qolinadi.");

  // 1 ---------------------------------------------------------------
  step("Tekshiruv");
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 18) { bad(`Node.js ${process.versions.node} eski. nodejs.org dan 20 yoki undan yangisini o'rnating.`); process.exit(1); }
  ok(`Node.js ${process.versions.node}`);
  if (!existsSync(join(ROOT, "supabase", "migrations"))) { bad("Loyiha papkasi topilmadi. Yordamchini kiddy-mijoz papkasi ichidan ishga tushiring."); process.exit(1); }
  ok("Loyiha papkasi");

  // 2 ---------------------------------------------------------------
  step("Supabase loyihasi");
  info("supabase.com → loyihangiz → Settings → General → Project ID (yoki manzildagi https://XXXX.supabase.co dagi XXXX).");
  for (;;) {
    const a = await ask("Supabase Project ID yoki manzili", state.ref);
    const m = a.match(/([a-z0-9]{20})/);
    if (m) { state.ref = m[1]; save(); break; }
    bad("Project ID 20 ta kichik harf/raqamdan iborat bo'ladi, masalan abcdefghijklmnopqrst");
  }
  const apiBase = process.env.KT_API_BASE || `https://${state.ref}.supabase.co/functions/v1`;
  if (!supa(["projects", "list"], { capture: true }).ok) {
    info("Supabase'ga kirish kerak — brauzer ochiladi, ruxsat bering.");
    if (!supa(["login"]).ok) { bad("Supabase'ga kirib bo'lmadi"); process.exit(1); }
  }
  ok("Supabase'ga kirildi");
  info("Baza parolini so'rashi mumkin (loyiha ochilganda o'zingiz qo'ygan parol; Settings → Database'da yangilash mumkin).");
  if (!supa(["link", "--project-ref", state.ref]).ok) { bad("Loyihaga ulanib bo'lmadi. Project ID va parolni tekshiring."); process.exit(1); }
  ok("Loyihaga ulandi");

  // 3 ---------------------------------------------------------------
  step("Baza jadvallari");
  if (!supa(["db", "push", "--include-all"], { input: "y\n" }).ok) {
    bad("Jadvallarni yuklab bo'lmadi. Supabase → SQL Editor'da supabase/migrations dagi fayllarni tartib bilan bajaring, so'ng yordamchini qayta ishga tushiring.");
    process.exit(1);
  }
  ok("Jadvallar tayyor");

  // 4 ---------------------------------------------------------------
  step("iBox");
  state.ibox_base = (await ask("iBox manzili", state.ibox_base || "https://kiddytoys.ibox.io")).replace(/\/+$/, "");
  state.ibox_filial = await ask("Filial raqami (Filial-Id)", state.ibox_filial || "10");
  info("iBox API kaliti (token) kerak. iBox'da \"API kalitlar\" bo'limida XABIBIY SHOWROOM SOTUV filiali uchun yangi kalit yarating");
  info("(nomi masalan \"Kiddy mijoz ilova\"). Topa olmasangiz — iBox (SMPro) qo'llab-quvvatlashidan integratsiya tokenini so'rang.");
  let iboxToken = "", dirs = {};
  await retry("iBox tekshiruvi", async () => {
    iboxToken = await askSecret("iBox API token");
    const r = await ibox(state.ibox_base, iboxToken, state.ibox_filial, "product/list", "?limit=1");
    ok(`iBox ishlayapti (${listOf(r).length ? "tovarlar bor" : "tovar ro'yxati bo'sh"})`);
  });
  for (const d of ["product_price_type", "core_warehouse", "core_currency"]) {
    try { dirs[d] = listOf(await ibox(state.ibox_base, iboxToken, state.ibox_filial, "core/directory", `?data=${d}&per_page=100`)); }
    catch (e) { dirs[d] = []; warn(`${d} ro'yxatini olib bo'lmadi: ${e.message}`); }
  }
  const idx = (list, id) => Math.max(1, list.findIndex((x) => String(x.id) === String(id)) + 1);
  const nameOf = (x) => x?.name ?? x?.title ?? x?.short_name ?? x?.code ?? JSON.stringify(x).slice(0, 60);
  if (dirs.product_price_type.length) {
    console.log("Mijozlar ko'radigan narx turi (ulgurji):");
    state.price_type = String((await choose("Raqamni tanlang", dirs.product_price_type, (x) => `${nameOf(x)} (id ${x.id})`, idx(dirs.product_price_type, state.price_type || 1))).id);
  } else state.price_type = await ask("Narx turi id raqami (iBox'dan)", state.price_type || "1");
  if (dirs.core_warehouse.length) {
    console.log("Buyurtma qaysi ombordan chiqadi:");
    state.warehouse = String((await choose("Raqamni tanlang", dirs.core_warehouse, (x) => `${nameOf(x)} (id ${x.id})`, idx(dirs.core_warehouse, state.warehouse || 12))).id);
  } else state.warehouse = await ask("Ombor id raqami (iBox'dan)", state.warehouse || "12");
  if (dirs.core_currency.length > 1) {
    console.log("Buyurtma iBox'ga qaysi valyutada yozilsin (dollarli tovarlar kurs bo'yicha o'giriladi):");
    state.currency = String((await choose("Raqamni tanlang", dirs.core_currency, (x) => `${nameOf(x)} (id ${x.id})`, idx(dirs.core_currency, state.currency || 1))).id);
  } else state.currency = String(dirs.core_currency[0]?.id ?? state.currency ?? "1");
  state.reserve = (await yes("Buyurtma tushganda tovar omborda band qilinsinmi?", state.reserve === "1" ? "h" : "y")) ? "1" : "0";
  save();

  // 5 ---------------------------------------------------------------
  step("Telegram bot");
  info("Telegram'da @BotFather → /newbot → nom va username bering. Bergan tokenni shu yerga qo'ying.");
  let tgToken = "", me = null;
  await retry("Bot tekshiruvi", async () => {
    tgToken = await askSecret("Bot tokeni");
    me = await tg(tgToken, "getMe");
    ok(`Bot: @${me.username}`);
  });
  state.bot_username = me.username;
  console.log(`\nMenejerlar guruhi: Telegram'da guruh oching (masalan "Kiddy — mijozlar"), menejerlarni va @${me.username} ni qo'shing.`);
  info("Guruh tayyor bo'lgach, guruhga /start yozing va shu yerda Enter bosing. Guruh kerak bo'lmasa — \"y\" yozing.");
  await tg(tgToken, "deleteWebhook", { drop_pending_updates: false }).catch(() => {});
  for (;;) {
    const a = await ask("Enter (guruh tayyor) yoki y (o'tkazib yuborish)", "");
    if (/^y/i.test(a)) { state.manager_chat = ""; break; }
    const ups = await tg(tgToken, "getUpdates", { allowed_updates: ["message", "my_chat_member"] }).catch(() => []);
    const groups = new Map();
    for (const u of ups) {
      const chat = u.message?.chat ?? u.my_chat_member?.chat;
      if (chat && (chat.type === "group" || chat.type === "supergroup")) groups.set(chat.id, chat.title);
    }
    if (!groups.size) { warn("Guruh hali ko'rinmayapti. Botni guruhga qo'shganingizni va /start yozganingizni tekshiring."); continue; }
    const g = groups.size === 1 ? [...groups][0] : await choose("Qaysi guruh", [...groups], ([, t]) => t, 1);
    state.manager_chat = String(g[0]); ok(`Guruh: ${g[1]}`); break;
  }
  save();

  // 6 ---------------------------------------------------------------
  step("Admin va ilova manzili");
  for (;;) { state.admin_name = await ask("Ismingiz (admin)", state.admin_name || ""); if (state.admin_name) break; bad("Ismni yozing"); }
  for (;;) { state.admin_phone = await ask("Telefoningiz (admin panelga shu raqam bilan kirasiz)", state.admin_phone || ""); if (phoneKey(state.admin_phone)) break; bad("Raqamni to'liq kiriting"); }
  state.manager_phone = await ask("Mijozlar uchun menejer telefoni", state.manager_phone || state.admin_phone);
  info("Ilova GitHub Pages'da turadi: https://USERNAME.github.io/REPO/");
  state.gh_user = await ask("GitHub username", state.gh_user || "");
  state.gh_repo = await ask("Repozitoriy nomi", state.gh_repo || "kiddy-mijoz");
  const appUrl = `https://${state.gh_user.toLowerCase()}.github.io/${state.gh_repo}/`;
  save();

  // 7 ---------------------------------------------------------------
  step("Sozlamalarni Supabase'ga yozish");
  const syncSecret = process.env.KT_SYNC_SECRET || secret(), whSecret = secret(18);
  const env = {
    IBOX_BASE_URL: state.ibox_base, IBOX_TOKEN: iboxToken, IBOX_FILIAL_ID: state.ibox_filial,
    IBOX_PRICE_TYPE_ID: state.price_type, IBOX_WAREHOUSE_ID: state.warehouse, IBOX_CURRENCY_ID: state.currency, IBOX_RESERVE: state.reserve,
    SYNC_SECRET: syncSecret, TELEGRAM_BOT_TOKEN: tgToken, TELEGRAM_BOT_USERNAME: me.username, TELEGRAM_WEBHOOK_SECRET: whSecret,
    MANAGER_CHAT_ID: state.manager_chat, MANAGER_PHONE: state.manager_phone,
    ALLOWED_ORIGINS: `https://${state.gh_user.toLowerCase()}.github.io`, APP_URL: appUrl,
  };
  const dir = mkdtempSync(join(tmpdir(), "kt-"));
  const envFile = join(dir, "secrets.env");
  writeFileSync(envFile, Object.entries(env).filter(([, v]) => v !== "" && v != null).map(([k, v]) => `${k}=${String(v).replace(/\n/g, "")}`).join("\n"));
  const set = supa(["secrets", "set", "--env-file", envFile, "--project-ref", state.ref]);
  try { unlinkSync(envFile); } catch { /* */ }
  if (!set.ok) { bad("Sozlamalarni yozib bo'lmadi"); process.exit(1); }
  ok("Sozlamalar yozildi (tokenlar faqat Supabase'da saqlanadi)");

  // 8 ---------------------------------------------------------------
  step("Server funksiyalarini yuklash");
  if (!supa(["functions", "deploy", "api", "ibox-sync", "tg-bot", "admin", "--no-verify-jwt", "--project-ref", state.ref]).ok) {
    bad("Funksiyalarni yuklab bo'lmadi"); process.exit(1);
  }
  ok("Funksiyalar yuklandi");
  info("Funksiyalar ishga tushishi uchun 10 soniya kutamiz…");
  await new Promise((r) => setTimeout(r, 10000));

  // 9 ---------------------------------------------------------------
  step("Telegram botni ulash");
  await retry("Webhook", async () => {
    await tg(tgToken, "setWebhook", { url: `${apiBase}/tg-bot`, secret_token: whSecret, allowed_updates: ["message"], drop_pending_updates: true });
    ok("Bot serverga ulandi");
  });
  await tg(tgToken, "setMyCommands", { commands: [{ command: "start", description: "Raqamni ulash" }] }).catch(() => {});

  // 10 --------------------------------------------------------------
  step("Admin, avtomatik sinxronlash va birinchi yuklash");
  const callSync = async (body) => {
    const res = await fetch(`${apiBase}/ibox-sync`, {
      method: "POST", headers: { Authorization: `Bearer ${syncSecret}`, "Content-Type": "application/json" },
      body: JSON.stringify(body), signal: AbortSignal.timeout(150000),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(j.message || j.error || `HTTP ${res.status}`);
    return j;
  };
  await retry("Sozlash", async () => {
    const r = await callSync({ setup: { admin_phone: state.admin_phone, admin_name: state.admin_name, cron_url: `${apiBase}/ibox-sync` } });
    r.admin === "ok" ? ok("Admin qo'shildi") : warn("Admin qo'shilmadi");
    r.cron === "ok" ? ok("Har 5 daqiqada iBox bilan avtomatik sinxronlash yoqildi") : warn(String(r.cron));
  });
  info("iBox'dan tovarlar, narxlar va mijozlar yuklanmoqda (bir necha daqiqa olishi mumkin)…");
  await retry("Birinchi sinxronlash", async () => {
    const r = await callSync({});
    for (const [k, v] of Object.entries(r)) v.ok ? ok(`${k}: ${v.count}`) : warn(`${k}: ${v.error}`);
  });

  // 11 --------------------------------------------------------------
  step("Ilova sozlamasi");
  const cfgPath = join(ROOT, "web", "config.js");
  let cfg = readFileSync(cfgPath, "utf8");
  cfg = cfg.replace(/API_URL:\s*"[^"]*"/, `API_URL: "${apiBase}/api"`);
  writeFileSync(cfgPath, cfg);
  ok("web/config.js yangilandi");

  // 12 --------------------------------------------------------------
  step("GitHub (ilovani internetga qo'yish)");
  const hasGit = run("git", ["--version"], { capture: true }).ok;
  const hasGh = run("gh", ["--version"], { capture: true }).ok;
  let pushed = false;
  if (hasGit && hasGh && await yes(`GitHub'ga avtomatik yuklaymizmi? github.com/${state.gh_user}/${state.gh_repo} ochiq repozitoriy bo'ladi`, "y")) {
    if (!run("gh", ["auth", "status"], { capture: true }).ok) run("gh", ["auth", "login", "--web", "--git-protocol", "https"]);
    const full = `${state.gh_user}/${state.gh_repo}`;
    if (!existsSync(join(ROOT, ".git"))) { run("git", ["init", "-b", "main"]); }
    run("git", ["add", "-A"]);
    run("git", ["-c", "user.name=Kiddy Toys", "-c", "user.email=noreply@kiddytoys.uz", "commit", "-m", "Kiddy Toys mijozlar ilovasi"], { capture: true });
    const exists = run("gh", ["repo", "view", full], { capture: true }).ok;
    const r = exists ? run("git", ["push", "-u", `https://github.com/${full}.git`, "main"])
      : run("gh", ["repo", "create", full, "--public", "--source", ".", "--push"]);
    if (r.ok) {
      run("gh", ["api", "-X", "POST", `repos/${full}/pages`, "-f", "build_type=workflow"], { capture: true });
      ok(`Yuklandi: https://github.com/${full}`);
      const kz = await ask("Android imzo kaliti papkasi (android-imzo-kaliti.zip ochilgan joy; o'tkazib yuborish uchun Enter)", "");
      const ks = kz && join(kz, "kiddy-toys-release.keystore"), txt = kz && join(kz, "GITHUB_SECRETS.txt");
      if (ks && existsSync(ks) && existsSync(txt)) {
        const t = readFileSync(txt, "utf8");
        const pw = t.match(/ANDROID_KEYSTORE_PASSWORD\s+Qiymati:\s*(\S+)/)?.[1];
        run("gh", ["secret", "set", "ANDROID_KEYSTORE_BASE64", "-R", full], { input: readFileSync(ks).toString("base64"), capture: true });
        if (pw) {
          run("gh", ["secret", "set", "ANDROID_KEYSTORE_PASSWORD", "-R", full, "-b", pw], { capture: true });
          run("gh", ["secret", "set", "ANDROID_KEY_PASSWORD", "-R", full, "-b", pw], { capture: true });
        }
        run("gh", ["secret", "set", "ANDROID_KEY_ALIAS", "-R", full, "-b", "kiddytoys"], { capture: true });
        run("gh", ["workflow", "run", "android.yml", "-R", full], { capture: true });
        ok("Android imzo kaliti qo'yildi, APK yig'ilmoqda");
      }
      run("gh", ["workflow", "run", "pages.yml", "-R", full], { capture: true });
      pushed = true;
    } else warn("GitHub'ga yuklab bo'lmadi — pastdagi qo'lda bajarish yo'riqnomasiga qarang.");
  }
  if (!pushed) {
    info("Qo'lda: github.com → New repository → nomi " + state.gh_repo + " → shu papkaning hammasini yuklang (.github papkasi bilan).");
    info("So'ng Settings → Pages → Source: GitHub Actions. Android uchun: Settings → Secrets → Actions'ga GITHUB_SECRETS.txt dagi 4 qiymat.");
  }

  // ---------------------------------------------------------------
  console.log(c.g("\n  ✔ Tayyor!\n"));
  console.log(`  Mijozlar ilovasi:  ${appUrl}`);
  console.log(`  Admin panel:       ${appUrl}admin/`);
  console.log(`  Android ilova:     https://github.com/${state.gh_user}/${state.gh_repo}/releases/latest/download/kiddy-toys.apk`);
  console.log(`  Telegram bot:      https://t.me/${me.username}`);
  console.log(c.d("\n  Sayt 2–5 daqiqada, Android APK 5–10 daqiqada tayyor bo'ladi."));
  console.log(c.d(`  Tekshirish: botga /start yozib raqamingizni yuboring, so'ng admin panelga ${state.admin_phone} bilan kiring.`));
  rl.close();
}

main().catch((e) => { bad(e?.message || String(e)); rl.close(); process.exit(1); });
